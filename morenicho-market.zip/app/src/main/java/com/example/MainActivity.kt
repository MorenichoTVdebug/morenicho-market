package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.MorenichoBottomNavigation
import com.example.ui.components.MorenichoTopBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MorenichoMarketTheme(darkTheme = true) {
                MorenichoMarketApp()
            }
        }
    }
}

@Composable
fun MorenichoMarketApp(
    viewModel: MarketplaceViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var showRoleSwitchDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { message ->
            snackbarHostState.showSnackbar(
                message = message,
                duration = SnackbarDuration.Short
            )
        }
    }

    BackHandler(enabled = currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    val cartCount = cartItems.sumOf { it.cartItem.quantity }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            if (currentScreen !is Screen.ProductDetail) {
                MorenichoTopBar(
                    currentScreen = currentScreen,
                    currentUser = currentUser,
                    cartCount = cartCount,
                    onNavigateCart = { viewModel.navigateTo(Screen.Cart) },
                    onOpenSearch = { viewModel.navigateTo(Screen.Home) },
                    onSwitchUserClick = { showRoleSwitchDialog = true },
                    onNavigateQr = { viewModel.navigateTo(Screen.QrScanner) },
                    onBackClick = { viewModel.navigateBack() }
                )
            }
        },
        bottomBar = {
            MorenichoBottomNavigation(
                currentScreen = currentScreen,
                onNavigate = { screen -> viewModel.navigateTo(screen) },
                isAdmin = currentUser.role == "ADMIN"
            )
        },
        containerColor = BlackBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = currentScreen) {
                is Screen.Home -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
                is Screen.Categories -> {
                    CategoriesScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.ProductDetail -> {
                    ProductDetailScreen(
                        productId = screen.productId,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.Cart, is Screen.Checkout -> {
                    CartAndCheckoutScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.PublishProduct -> {
                    PublishProductScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.WalletFinance -> {
                    WalletFinanceScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.AdminPanel -> {
                    AdminPanelScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.AffiliateModule -> {
                    AffiliateScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.Profile, is Screen.OrderHistory, is Screen.Favorites, is Screen.SupabaseGuide -> {
                    ProfileAndAuthScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.Auth -> {
                    AuthScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.MyQrCode -> {
                    MyQrCodeScreen(
                        orderId = screen.orderId,
                        initialOperationType = screen.operationType,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.QrScanner -> {
                    QrScannerScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
                is Screen.QrAuditHistory -> {
                    QrAuditHistoryScreen(
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )
                }
            }
        }
    }

    // Role Switch Dialog for Testing and Administration
    if (showRoleSwitchDialog) {
        AlertDialog(
            onDismissRequest = { showRoleSwitchDialog = false },
            title = {
                Text(
                    text = "Cambiar Rol de Usuario",
                    color = WhiteText,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Selecciona un usuario para probar los 4 roles requeridos (Comprador, Vendedor, Recomendador, Administrador):",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    allUsers.forEach { user ->
                        val isSelected = currentUser.id == user.id
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.switchUser(user)
                                    showRoleSwitchDialog = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = user.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = user.email,
                                        color = if (isSelected) Color(0xFFE9D5FF) else TextMuted,
                                        fontSize = 11.sp
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (user.role) {
                                        "ADMIN" -> Color(0xFFEF4444)
                                        "COURIER" -> SuccessGreen
                                        "SELLER" -> PurpleLight
                                        "AFFILIATE" -> OfficialGold
                                        else -> InfoBlue
                                    }
                                ) {
                                    Text(
                                        text = if (user.role == "COURIER") "REPARTIDOR" else user.role,
                                        color = if (user.role == "AFFILIATE") Color.Black else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRoleSwitchDialog = false }) {
                    Text("Cerrar", color = PurpleGlow)
                }
            },
            containerColor = BlackSurface
        )
    }
}
