package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        ProductEntity::class,
        CategoryEntity::class,
        AffiliateProductEntity::class,
        CartItemEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        CommissionEntity::class,
        WalletMovementEntity::class,
        WithdrawalRequestEntity::class,
        AdCampaignEntity::class,
        FavoriteEntity::class,
        NotificationEntity::class,
        QrSecurityTokenEntity::class,
        QrAuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun productDao(): ProductDao
    abstract fun categoryDao(): CategoryDao
    abstract fun userDao(): UserDao
    abstract fun affiliateDao(): AffiliateDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun financeDao(): FinanceDao
    abstract fun adDao(): AdDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun notificationDao(): NotificationDao
    abstract fun qrDao(): QrDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "morenicho_market_db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }
        }

        suspend fun populateInitialData(db: AppDatabase) {
            val categoryDao = db.categoryDao()
            val productDao = db.productDao()
            val userDao = db.userDao()
            val affiliateDao = db.affiliateDao()
            val adDao = db.adDao()
            val financeDao = db.financeDao()

            // 1. Initial Categories
            val categories = listOf(
                CategoryEntity("tech", "Tecnología", "Computer", 0xFF7C3AED),
                CategoryEntity("phones", "Celulares", "Smartphone", 0xFF9333EA),
                CategoryEntity("fashion", "Ropa y Calzado", "Checkroom", 0xFFA855F7),
                CategoryEntity("home", "Hogar y Muebles", "Home", 0xFF6366F1),
                CategoryEntity("vehicles", "Vehículos", "DirectionsCar", 0xFF3B82F6),
                CategoryEntity("sports", "Deportes", "FitnessCenter", 0xFF10B981),
                CategoryEntity("beauty", "Belleza y Salud", "Spa", 0xFFEC4899),
                CategoryEntity("food", "Alimentos Gourmet", "Restaurant", 0xFFF59E0B),
                CategoryEntity("real_estate", "Inmuebles", "Apartment", 0xFF8B5CF6),
                CategoryEntity("services", "Servicios", "Build", 0xFF06B6D4)
            )
            categoryDao.insertCategories(categories)

            // 2. Initial Users (All 4 roles)
            val users = listOf(
                UserEntity(
                    id = "usr_admin",
                    name = "Administrador Morenicho",
                    email = "admin@morenicho.cl",
                    role = "ADMIN",
                    phone = "+56 9 8765 4321",
                    whatsappNumber = "+56987654321",
                    referralCode = "MORENICHO-ADMIN",
                    city = "Santiago",
                    region = "Región Metropolitana"
                ),
                UserEntity(
                    id = "usr_oficial",
                    name = "Tienda Oficial Morenicho",
                    email = "contacto@morenicho.cl",
                    role = "SELLER",
                    phone = "+56 9 9999 1111",
                    whatsappNumber = "+56999991111",
                    referralCode = "TIENDA-OFICIAL",
                    city = "Santiago",
                    region = "Región Metropolitana"
                ),
                UserEntity(
                    id = "usr_seller_1",
                    name = "Patricio Silva (ElectroChile)",
                    email = "patricio.tech@gmail.com",
                    role = "SELLER",
                    phone = "+56 9 7123 4567",
                    whatsappNumber = "+56971234567",
                    referralCode = "TECH-PATO",
                    city = "Providencia",
                    region = "Región Metropolitana"
                ),
                UserEntity(
                    id = "usr_affiliate_1",
                    name = "Camila Rojas M.",
                    email = "camila.afiliados@gmail.com",
                    role = "AFFILIATE",
                    phone = "+56 9 6234 5678",
                    whatsappNumber = "+56962345678",
                    referralCode = "CAMI-CHILE",
                    city = "Viña del Mar",
                    region = "Valparaíso"
                ),
                UserEntity(
                    id = "usr_buyer_1",
                    name = "Enrique Gil V.",
                    email = "enriquegilvillanueva@gmail.com",
                    role = "BUYER",
                    phone = "+56 9 5555 1234",
                    whatsappNumber = "+56955551234",
                    referralCode = "ENRIQUE-G",
                    referredBy = "CAMI-CHILE",
                    city = "Las Condes",
                    region = "Región Metropolitana"
                ),
                UserEntity(
                    id = "usr_courier_1",
                    name = "Carlos Repartidor Express",
                    email = "repartidor@morenicho.cl",
                    role = "COURIER",
                    phone = "+56 9 4444 8888",
                    whatsappNumber = "+56944448888",
                    referralCode = "REPARTO-CHILE",
                    city = "Santiago",
                    region = "Región Metropolitana"
                )
            )
            userDao.insertUsers(users)

            // 3. Initial Products (Official store + Marketplace sellers)
            val products = listOf(
                // Tienda Oficial Morenicho (0% platform commission)
                ProductEntity(
                    id = "prod_oficial_1",
                    title = "Smartwatch Morenicho Elite AMOLED GPS 46mm",
                    description = "Reloj inteligente oficial de Morenicho Market con pantalla AMOLED de alta resolución, GPS integrado, monitoreo cardíaco 24/7, resistencia al agua 5ATM y batería de hasta 14 días. Garantía directa oficial de 12 meses.",
                    price = 49990,
                    originalPrice = 69990,
                    categoryId = "tech",
                    sellerId = "usr_oficial",
                    sellerName = "Tienda Oficial Morenicho",
                    sellerPhone = "+56999991111",
                    isOfficial = true,
                    condition = "NEW",
                    stock = 45,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true
                ),
                ProductEntity(
                    id = "prod_oficial_2",
                    title = "Audífonos Inalámbricos Morenicho Pro ANC Hi-Res",
                    description = "Cancelación activa de ruido híbrida de 40dB, audio de alta resolución con drivers de titanio, estuche de carga rápida inalámbrica y 38 horas de reproducción total. Edición Morenicho Black & Purple.",
                    price = 29990,
                    originalPrice = 42990,
                    categoryId = "tech",
                    sellerId = "usr_oficial",
                    sellerName = "Tienda Oficial Morenicho",
                    sellerPhone = "+56999991111",
                    isOfficial = true,
                    condition = "NEW",
                    stock = 60,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true
                ),
                ProductEntity(
                    id = "prod_oficial_3",
                    title = "Mochila Antirrobo Ejecutiva Morenicho Waterproof",
                    description = "Mochila para notebook de hasta 16 pulgadas, material oxford impermeable repelente al agua, puerto de carga USB exterior, compartimento oculto de seguridad y diseño ergonómico.",
                    price = 34990,
                    originalPrice = 49990,
                    categoryId = "fashion",
                    sellerId = "usr_oficial",
                    sellerName = "Tienda Oficial Morenicho",
                    sellerPhone = "+56999991111",
                    isOfficial = true,
                    condition = "NEW",
                    stock = 30,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),

                // Marketplace external sellers (Eligible for 5% platform + 2% referrer + 93% seller)
                ProductEntity(
                    id = "prod_market_1",
                    title = "iPhone 15 Pro Max 256GB Titanio Natural",
                    description = "iPhone 15 Pro Max en excelente estado, caja original con cable trenzado, 98% condición de batería. Homologado para todas las compañías en Chile (Subtel). Incluye lámina de vidrio instalada.",
                    price = 989900,
                    originalPrice = 1199900,
                    categoryId = "phones",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva (ElectroChile)",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "USED",
                    stock = 2,
                    locationCity = "Providencia",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true
                ),
                ProductEntity(
                    id = "prod_market_2",
                    title = "MacBook Air M2 13.6\" 8GB RAM 256GB SSD Midnight",
                    description = "Impecable computador portátil Apple con procesador M2, teclado en español, cargador original MagSafe 35W dual. Ideal para trabajo profesional y diseño.",
                    price = 849900,
                    originalPrice = 999900,
                    categoryId = "tech",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva (ElectroChile)",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "USED",
                    stock = 3,
                    locationCity = "Las Condes",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true
                ),
                ProductEntity(
                    id = "prod_market_3",
                    title = "Parka Térmica Impermeable Andina 800 Cuin",
                    description = "Chaqueta técnica de pluma para alta montaña y climas fríos de Chile, membrana DryVent transpirable, capucha ajustable compatible con casco.",
                    price = 119990,
                    originalPrice = 159990,
                    categoryId = "fashion",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 12,
                    locationCity = "Las Condes",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),
                ProductEntity(
                    id = "prod_market_4",
                    title = "Café de Grano Especialidad Origen Huila 1Kg",
                    description = "Tostado medio artesanal en Chile, notas a caramelo, chocolate amargo y frutos rojos. Grano 100% arábica recién tostado, válvula desgasificadora.",
                    price = 18990,
                    originalPrice = 24990,
                    categoryId = "food",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 50,
                    locationCity = "Ñuñoa",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),
                ProductEntity(
                    id = "prod_market_5",
                    title = "Bicicleta Montaña Aro 29 Frenos Hidráulicos",
                    description = "Cuadro de aluminio hidroformado ultra liviano, transmisión Shimano 1x11, horquilla con bloqueo al manillar, neumáticos Maxxis Recon Race.",
                    price = 459900,
                    originalPrice = 529900,
                    categoryId = "sports",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 5,
                    locationCity = "Viña del Mar",
                    locationRegion = "Valparaíso",
                    imageUrl = "https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true
                ),
                ProductEntity(
                    id = "prod_market_6",
                    title = "Robot Aspiradora y Trapeadora Láser LDS 3000Pa",
                    description = "Mapeo inteligente multinivel de habitaciones, control mediante App y asistentes de voz, tanque de agua controlado electrónicamente y detección de alfombras.",
                    price = 169990,
                    originalPrice = 229990,
                    categoryId = "home",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 8,
                    locationCity = "La Florida",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),
                ProductEntity(
                    id = "prod_market_7",
                    title = "Camioneta Toyota Hilux 4x4 Diésel 2021",
                    description = "Motor 2.8 D-4D Turbo Diésel, tracción 4x4 con selector electrónico, 65.000 km, mantenciones en concesionario oficial, láminas de seguridad y barra antivuelco.",
                    price = 21500000,
                    originalPrice = null,
                    categoryId = "vehicles",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "USED",
                    stock = 1,
                    locationCity = "Concepción",
                    locationRegion = "Biobío",
                    imageUrl = "https://images.unsplash.com/photo-1559416523-140ddc3d238c?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),
                ProductEntity(
                    id = "prod_market_8",
                    title = "Departamento 2D 2B Metro Tobalaba Providencia",
                    description = "Arriendo departamento recién remodelado, cocina equipada con encimera vitrocerámica, terraza con vista despejada, estacionamiento subterráneo y bodega.",
                    price = 650000,
                    originalPrice = null,
                    categoryId = "real_estate",
                    sellerId = "usr_seller_1",
                    sellerName = "Patricio Silva",
                    sellerPhone = "+56971234567",
                    isOfficial = false,
                    condition = "USED",
                    stock = 1,
                    locationCity = "Providencia",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=600&auto=format&fit=crop&q=80",
                    isFeatured = false
                ),

                // Affiliate Products (AliExpress, Amazon, Hotmart)
                ProductEntity(
                    id = "prod_aff_ali",
                    title = "Cámara de Seguridad Exterior 4K WiFi Solar PTZ 360°",
                    description = "Panel solar autónomo, detección humana mediante IA, visión nocturna a color, audio bidireccional y almacenamiento en nube o tarjeta SD. Envío con AliExpress Choice.",
                    price = 32990,
                    originalPrice = 49990,
                    categoryId = "tech",
                    sellerId = "affiliate_aliexpress",
                    sellerName = "AliExpress Choice Global",
                    sellerPhone = "+56987654321",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 99,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true,
                    isAffiliate = true,
                    affiliatePlatform = "AliExpress",
                    affiliateUrl = "https://s.click.aliexpress.com/e/_morenicho_cam4k"
                ),
                ProductEntity(
                    id = "prod_aff_amz",
                    title = "Kindle Paperwhite 16GB Pantalla 6.8\" Luz Cálida",
                    description = "Lector de libros electrónicos con resistencia al agua IPX8, semanas de duración de batería y pantalla antirreflejos de 300 ppp. Importación directa garantizada.",
                    price = 145990,
                    originalPrice = 169990,
                    categoryId = "tech",
                    sellerId = "affiliate_amazon",
                    sellerName = "Amazon International",
                    sellerPhone = "+56987654321",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 50,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1592496431122-2349e0fbc666?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true,
                    isAffiliate = true,
                    affiliatePlatform = "Amazon",
                    affiliateUrl = "https://www.amazon.com/dp/B08KTZ8249?tag=morenichomkt-20"
                ),
                ProductEntity(
                    id = "prod_aff_hotmart",
                    title = "Masterclass Experto en E-Commerce y Ventas Online Chile",
                    description = "Programa integral en video para crear y escalar tiendas online en Chile, integración de pasarelas de pago Webpay y logística de despacho. Acceso vitalicio inmediato.",
                    price = 39990,
                    originalPrice = 79990,
                    categoryId = "services",
                    sellerId = "affiliate_hotmart",
                    sellerName = "Hotmart Academy",
                    sellerPhone = "+56987654321",
                    isOfficial = false,
                    condition = "NEW",
                    stock = 999,
                    locationCity = "Santiago",
                    locationRegion = "Región Metropolitana",
                    imageUrl = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80",
                    isFeatured = true,
                    isAffiliate = true,
                    affiliatePlatform = "Hotmart",
                    affiliateUrl = "https://go.hotmart.com/MORENICHO_ECOMMERCE_CL"
                )
            )
            productDao.insertProducts(products)

            // 4. Initial Affiliate Products (AliExpress, Amazon, Hotmart)
            val affiliateProducts = listOf(
                AffiliateProductEntity(
                    id = "aff_1",
                    name = "Cámara de Seguridad Exterior 4K WiFi Solar PTZ 360°",
                    description = "Panel solar autónomo, detección humana mediante IA, visión nocturna a color, audio bidireccional y almacenamiento en nube o tarjeta SD.",
                    price = 32990,
                    categoryId = "tech",
                    platformSource = "AliExpress",
                    affiliateUrl = "https://s.click.aliexpress.com/e/_morenicho_cam4k",
                    commissionRate = "8.0% por compra",
                    imageUrl = "https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=600&auto=format&fit=crop&q=80",
                    clickCount = 42
                ),
                AffiliateProductEntity(
                    id = "aff_2",
                    name = "Kindle Paperwhite 16GB Pantalla 6.8\" Luz Cálida",
                    description = "Lector de libros electrónicos con resistencia al agua IPX8, semanas de duración de batería y pantalla antirreflejos de 300 ppp.",
                    price = 145990,
                    categoryId = "tech",
                    platformSource = "Amazon",
                    affiliateUrl = "https://www.amazon.com/dp/B08KTZ8249?tag=morenichomkt-20",
                    commissionRate = "4.5% por compra",
                    imageUrl = "https://images.unsplash.com/photo-1592496431122-2349e0fbc666?w=600&auto=format&fit=crop&q=80",
                    clickCount = 28
                ),
                AffiliateProductEntity(
                    id = "aff_3",
                    name = "Masterclass Experto en E-Commerce y Ventas Online Chile",
                    description = "Programa integral en video para crear y escalar tiendas online en Chile, integración de pasarelas de pago Webpay y logística de despacho.",
                    price = 39990,
                    categoryId = "services",
                    platformSource = "Hotmart",
                    affiliateUrl = "https://go.hotmart.com/MORENICHO_ECOMMERCE_CL",
                    commissionRate = "35.0% por venta confirmada",
                    imageUrl = "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=80",
                    clickCount = 65
                )
            )
            affiliateDao.insertAffiliates(affiliateProducts)

            // 5. Initial Ad Campaigns (Monetag, Adsterra, Local Chilean business)
            val ads = listOf(
                AdCampaignEntity(
                    id = "ad_1",
                    title = "Boutique Café y Pastelería Tradicional Providencia",
                    advertiserName = "Café Francés Santiago",
                    placement = "BANNER_TOP",
                    bannerImageUrl = "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=900&auto=format&fit=crop&q=80",
                    targetUrl = "https://wa.me/56911223344",
                    adNetwork = "NEGOCIO_LOCAL",
                    impressions = 320,
                    clicks = 18,
                    cpmOrFixedCLP = 15000
                ),
                AdCampaignEntity(
                    id = "ad_2",
                    title = "Monetag In-Feed Smart Tag - Descuentos Cyber Tech",
                    advertiserName = "Monetag Ad Network",
                    placement = "IN_FEED",
                    bannerImageUrl = "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=900&auto=format&fit=crop&q=80",
                    targetUrl = "https://monetag.com",
                    adNetwork = "MONETAG",
                    impressions = 840,
                    clicks = 41,
                    cpmOrFixedCLP = 8500
                ),
                AdCampaignEntity(
                    id = "ad_3",
                    title = "Adsterra Banner Nativo - Ofertas de Temporada",
                    advertiserName = "Adsterra Network",
                    placement = "SIDEBAR",
                    bannerImageUrl = "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=900&auto=format&fit=crop&q=80",
                    targetUrl = "https://adsterra.com",
                    adNetwork = "ADSTERRA",
                    impressions = 610,
                    clicks = 29,
                    cpmOrFixedCLP = 6200
                )
            )
            adDao.insertAds(ads)

            // 6. Initial Wallet movements and commissions showing real calculations
            val movements = listOf(
                WalletMovementEntity(
                    id = "mov_1",
                    userId = "usr_admin",
                    concept = "Comisión de plataforma 5% - Pedido ORD-2026-001",
                    source = "COMISION_MARKETPLACE",
                    amount = 49495,
                    currency = "CLP",
                    status = "CONFIRMADO",
                    referenceCode = "ORD-2026-001"
                ),
                WalletMovementEntity(
                    id = "mov_2",
                    userId = "usr_affiliate_1",
                    concept = "Recompensa por recomendador 2% - Pedido ORD-2026-001",
                    source = "COMISION_RECOMENDACION",
                    amount = 19798,
                    currency = "CLP",
                    status = "CONFIRMADO",
                    referenceCode = "REF-CAMI-CHILE"
                ),
                WalletMovementEntity(
                    id = "mov_3",
                    userId = "usr_seller_1",
                    concept = "Liquidación venta 93% - Pedido ORD-2026-001",
                    source = "VENTA_PROPIA",
                    amount = 920607,
                    currency = "CLP",
                    status = "CONFIRMADO",
                    referenceCode = "ORD-2026-001"
                ),
                WalletMovementEntity(
                    id = "mov_4",
                    userId = "usr_admin",
                    concept = "Venta Tienda Oficial Morenicho 100% (0% comisión) - Smartwatch",
                    source = "VENTA_PROPIA",
                    amount = 49990,
                    currency = "CLP",
                    status = "CONFIRMADO",
                    referenceCode = "ORD-2026-002"
                )
            )
            financeDao.insertWalletMovements(movements)

            // Initial withdrawal request for demonstration
            val withdrawal = WithdrawalRequestEntity(
                id = "wdr_1",
                userId = "usr_affiliate_1",
                userName = "Camila Rojas M.",
                method = "TRANSFERENCIA_CHILENA",
                amount = 15000,
                bankName = "Banco Estado (Cuenta RUT)",
                accountType = "Cuenta Vista / RUT",
                rut = "18.765.432-1",
                accountNumber = "18765432",
                status = "APROBADO",
                adminNotes = "Transferencia bancaria realizada con comprobante N° 981240"
            )
            financeDao.insertWithdrawal(withdrawal)

            // 7. Initial Order and QR Delivery/Return Security Tokens
            val orderDao = db.orderDao()
            val qrDao = db.qrDao()

            val initialOrder = OrderEntity(
                id = "ord_seed_1",
                orderNumber = "ORD-CL-901020",
                buyerId = "usr_buyer_1",
                buyerName = "Enrique Gil V.",
                buyerPhone = "+56 9 5555 1234",
                buyerAddress = "Av. Providencia 1234, Depto 502",
                buyerCity = "Providencia",
                buyerRegion = "Región Metropolitana",
                totalAmount = 49990,
                status = "SHIPPED", // En camino para entrega mediante QR
                paymentMethod = "WEBPAY_CHILE",
                referralCodeApplied = "CAMI-CHILE"
            )
            orderDao.insertOrder(initialOrder)

            val initialOrderItem = OrderItemEntity(
                id = "item_seed_1",
                orderId = "ord_seed_1",
                productId = "prod_oficial_1",
                productTitle = "Smartwatch Morenicho Elite AMOLED GPS 46mm",
                productPrice = 49990,
                quantity = 1,
                isOfficial = true,
                sellerId = "usr_oficial"
            )
            orderDao.insertOrderItems(listOf(initialOrderItem))

            // Seed 3 Independent QR Security Tokens for this order (NO PII in tokens)
            val qrTokens = listOf(
                QrSecurityTokenEntity(
                    id = "tok_dlv_1",
                    token = "MN-DLV-8A3F2C19",
                    orderId = "ord_seed_1",
                    orderNumber = "ORD-CL-901020",
                    operationType = "DELIVERY_HANDOFF",
                    otpCode = "492015",
                    authorizedActorRole = "COURIER",
                    targetUserId = "usr_buyer_1",
                    targetUserName = "Enrique Gil V.",
                    status = "ACTIVE"
                ),
                QrSecurityTokenEntity(
                    id = "tok_ret_pk_1",
                    token = "MN-RET-PK-7C1B4E82",
                    orderId = "ord_seed_1",
                    orderNumber = "ORD-CL-901020",
                    operationType = "RETURN_PICKUP",
                    otpCode = "839102",
                    authorizedActorRole = "COURIER",
                    targetUserId = "usr_buyer_1",
                    targetUserName = "Enrique Gil V.",
                    status = "ACTIVE"
                ),
                QrSecurityTokenEntity(
                    id = "tok_ret_rc_1",
                    token = "MN-RET-RC-5D9A3F11",
                    orderId = "ord_seed_1",
                    orderNumber = "ORD-CL-901020",
                    operationType = "RETURN_RECEIVE",
                    otpCode = "120485",
                    authorizedActorRole = "SELLER",
                    targetUserId = "usr_oficial",
                    targetUserName = "Tienda Oficial Morenicho",
                    status = "ACTIVE"
                )
            )
            qrDao.insertTokens(qrTokens)

            val initialAudit = QrAuditLogEntity(
                id = "audit_init_1",
                token = "MN-DLV-8A3F2C19",
                orderId = "ord_seed_1",
                orderNumber = "ORD-CL-901020",
                operationType = "DELIVERY_HANDOFF",
                actorId = "usr_admin",
                actorName = "Sistema Morenicho",
                actorRole = "SYSTEM",
                status = "SUCCESS",
                message = "Código QR seguro de entrega emitido con vencimiento de 48h y código OTP 492015",
                location = "Centro de Distribución Santiago"
            )
            qrDao.insertAuditLog(initialAudit)
        }
    }
}
