package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY createdAt DESC")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    fun getProductById(id: String): Flow<ProductEntity?>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductByIdSync(id: String): ProductEntity?

    @Query("SELECT * FROM products WHERE isOfficial = 1 ORDER BY createdAt DESC")
    fun getOfficialProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE isFeatured = 1 ORDER BY createdAt DESC")
    fun getFeaturedProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE categoryId = :categoryId ORDER BY createdAt DESC")
    fun getProductsByCategory(categoryId: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE sellerId = :sellerId ORDER BY createdAt DESC")
    fun getSellerProducts(sellerId: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: ProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Delete
    suspend fun deleteProduct(product: ProductEntity)

    @Query("UPDATE products SET viewsCount = viewsCount + 1 WHERE id = :id")
    suspend fun incrementViews(id: String)

    @Query("UPDATE products SET stock = :newStock, isSoldOut = :isSoldOut WHERE id = :id")
    suspend fun updateStock(id: String, newStock: Int, isSoldOut: Boolean)
}

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name ASC")
    fun getAllCategories(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<CategoryEntity>)
}

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    fun getUserById(id: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserByIdSync(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE referralCode = :code LIMIT 1")
    suspend fun getUserByReferralCode(code: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<UserEntity>)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET isSuspended = :isSuspended WHERE id = :userId")
    suspend fun updateSuspended(userId: String, isSuspended: Boolean)
}

@Dao
interface AffiliateDao {
    @Query("SELECT * FROM affiliate_products WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getActiveAffiliates(): Flow<List<AffiliateProductEntity>>

    @Query("SELECT * FROM affiliate_products ORDER BY createdAt DESC")
    fun getAllAffiliates(): Flow<List<AffiliateProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAffiliate(item: AffiliateProductEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAffiliates(items: List<AffiliateProductEntity>)

    @Update
    suspend fun updateAffiliate(item: AffiliateProductEntity)

    @Delete
    suspend fun deleteAffiliate(item: AffiliateProductEntity)

    @Query("UPDATE affiliate_products SET clickCount = clickCount + 1 WHERE id = :id")
    suspend fun incrementClicks(id: String)
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items ORDER BY addedAt DESC")
    fun getCartItems(): Flow<List<CartItemEntity>>

    @Query("SELECT * FROM cart_items WHERE productId = :productId LIMIT 1")
    suspend fun getCartItemByProductId(productId: String): CartItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    @Query("UPDATE cart_items SET quantity = :quantity WHERE id = :id")
    suspend fun updateQuantity(id: String, quantity: Int)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    fun getOrderById(orderId: String): Flow<OrderEntity?>

    @Query("SELECT * FROM orders WHERE buyerId = :buyerId ORDER BY createdAt DESC")
    fun getOrdersByBuyer(buyerId: String): Flow<List<OrderEntity>>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    fun getOrderItems(orderId: String): Flow<List<OrderItemEntity>>

    @Query("SELECT * FROM order_items")
    fun getAllOrderItems(): Flow<List<OrderItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)

    @Query("UPDATE orders SET status = :status WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: String)
}

@Dao
interface FinanceDao {
    @Query("SELECT * FROM commissions ORDER BY createdAt DESC")
    fun getAllCommissions(): Flow<List<CommissionEntity>>

    @Query("SELECT * FROM commissions WHERE sellerId = :sellerId ORDER BY createdAt DESC")
    fun getCommissionsBySeller(sellerId: String): Flow<List<CommissionEntity>>

    @Query("SELECT * FROM commissions WHERE referrerId = :referrerId ORDER BY createdAt DESC")
    fun getCommissionsByReferrer(referrerId: String): Flow<List<CommissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommission(commission: CommissionEntity)

    @Query("UPDATE commissions SET status = :status WHERE id = :id")
    suspend fun updateCommissionStatus(id: String, status: String)

    @Query("SELECT * FROM wallet_movements ORDER BY createdAt DESC")
    fun getAllWalletMovements(): Flow<List<WalletMovementEntity>>

    @Query("SELECT * FROM wallet_movements WHERE userId = :userId ORDER BY createdAt DESC")
    fun getWalletMovementsByUser(userId: String): Flow<List<WalletMovementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalletMovement(movement: WalletMovementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalletMovements(movements: List<WalletMovementEntity>)

    @Query("SELECT * FROM withdrawal_requests ORDER BY requestedAt DESC")
    fun getAllWithdrawals(): Flow<List<WithdrawalRequestEntity>>

    @Query("SELECT * FROM withdrawal_requests WHERE userId = :userId ORDER BY requestedAt DESC")
    fun getWithdrawalsByUser(userId: String): Flow<List<WithdrawalRequestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWithdrawal(request: WithdrawalRequestEntity)

    @Query("UPDATE withdrawal_requests SET status = :status, adminNotes = :adminNotes, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateWithdrawalStatus(id: String, status: String, adminNotes: String, updatedAt: Long)
}

@Dao
interface AdDao {
    @Query("SELECT * FROM ad_campaigns ORDER BY id ASC")
    fun getAllAds(): Flow<List<AdCampaignEntity>>

    @Query("SELECT * FROM ad_campaigns WHERE isActive = 1 ORDER BY id ASC")
    fun getActiveAds(): Flow<List<AdCampaignEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAd(ad: AdCampaignEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAds(ads: List<AdCampaignEntity>)

    @Update
    suspend fun updateAd(ad: AdCampaignEntity)

    @Delete
    suspend fun deleteAd(ad: AdCampaignEntity)

    @Query("UPDATE ad_campaigns SET impressions = impressions + 1 WHERE id = :id")
    suspend fun incrementImpressions(id: String)

    @Query("UPDATE ad_campaigns SET clicks = clicks + 1 WHERE id = :id")
    suspend fun incrementClicks(id: String)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites WHERE userId = :userId ORDER BY addedAt DESC")
    fun getFavoritesByUser(userId: String): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE userId = :userId AND productId = :productId")
    suspend fun deleteFavorite(userId: String, productId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE userId = :userId AND productId = :productId)")
    fun isFavorite(userId: String, productId: String): Flow<Boolean>
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun getNotificationsByUser(userId: String): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)
}

@Dao
interface QrDao {
    @Query("SELECT * FROM qr_security_tokens WHERE orderId = :orderId ORDER BY createdAt DESC")
    fun getTokensForOrder(orderId: String): Flow<List<QrSecurityTokenEntity>>

    @Query("SELECT * FROM qr_security_tokens WHERE orderId = :orderId AND operationType = :operationType LIMIT 1")
    fun getTokenForOrderAndType(orderId: String, operationType: String): Flow<QrSecurityTokenEntity?>

    @Query("SELECT * FROM qr_security_tokens WHERE orderId = :orderId AND operationType = :operationType LIMIT 1")
    suspend fun getTokenForOrderAndTypeSync(orderId: String, operationType: String): QrSecurityTokenEntity?

    @Query("SELECT * FROM qr_security_tokens WHERE token = :tokenOrPayload OR otpCode = :tokenOrPayload LIMIT 1")
    suspend fun findTokenByCodeOrOtp(tokenOrPayload: String): QrSecurityTokenEntity?

    @Query("SELECT * FROM qr_security_tokens WHERE targetUserId = :userId ORDER BY createdAt DESC")
    fun getTokensByUser(userId: String): Flow<List<QrSecurityTokenEntity>>

    @Query("SELECT * FROM qr_security_tokens ORDER BY createdAt DESC")
    fun getAllTokens(): Flow<List<QrSecurityTokenEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertToken(token: QrSecurityTokenEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTokens(tokens: List<QrSecurityTokenEntity>)

    @Update
    suspend fun updateToken(token: QrSecurityTokenEntity)

    @Query("SELECT * FROM qr_audit_logs ORDER BY timestamp DESC")
    fun getAllAuditLogs(): Flow<List<QrAuditLogEntity>>

    @Query("SELECT * FROM qr_audit_logs WHERE orderId = :orderId ORDER BY timestamp DESC")
    fun getAuditLogsForOrder(orderId: String): Flow<List<QrAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: QrAuditLogEntity)
}

