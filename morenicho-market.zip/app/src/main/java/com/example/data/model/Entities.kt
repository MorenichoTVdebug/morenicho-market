package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole {
    BUYER,
    SELLER,
    AFFILIATE,
    COURIER,
    ADMIN
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val role: String, // BUYER, SELLER, AFFILIATE, ADMIN
    val phone: String,
    val whatsappNumber: String,
    val referralCode: String,
    val referredBy: String? = null,
    val city: String = "Santiago",
    val region: String = "Metropolitana",
    val avatarUrl: String = "",
    val isSuspended: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val price: Int, // in CLP
    val originalPrice: Int? = null, // for offers discount display
    val categoryId: String,
    val sellerId: String,
    val sellerName: String,
    val sellerPhone: String,
    val isOfficial: Boolean = false, // Tienda Oficial Morenicho
    val condition: String = "NEW", // NEW, USED
    val stock: Int = 10,
    val locationCity: String = "Santiago",
    val locationRegion: String = "Región Metropolitana",
    val imageUrl: String,
    val isFeatured: Boolean = false,
    val isSoldOut: Boolean = false,
    val viewsCount: Int = 0,
    val isAffiliate: Boolean = false,
    val affiliatePlatform: String? = null, // AliExpress, Hotmart, Amazon, Otra Red
    val affiliateUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey val id: String,
    val name: String,
    val iconName: String,
    val colorHex: Long = 0xFF7C3AED
)

@Entity(tableName = "affiliate_products")
data class AffiliateProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val price: Int, // CLP
    val categoryId: String,
    val platformSource: String, // AliExpress, Hotmart, Amazon, Otra Red
    val affiliateUrl: String,
    val commissionRate: String, // e.g. "8.5% por venta"
    val imageUrl: String,
    val clickCount: Int = 0,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val quantity: Int = 1,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val buyerId: String,
    val buyerName: String,
    val buyerPhone: String,
    val buyerAddress: String,
    val buyerCity: String,
    val buyerRegion: String,
    val totalAmount: Int, // in CLP
    val discountAmount: Int = 0,
    val shippingAmount: Int = 0,
    val status: String, // PENDING_PAYMENT, PAID, PROCESSING, SHIPPED, DELIVERED, CANCELLED
    val paymentMethod: String, // WEBPAY_CHILE, MERCADO_PAGO, WHATSAPP_AGREEMENT
    val referralCodeApplied: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "order_items")
data class OrderItemEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val productId: String,
    val productTitle: String,
    val productPrice: Int,
    val quantity: Int,
    val isOfficial: Boolean,
    val sellerId: String
)

@Entity(tableName = "commissions")
data class CommissionEntity(
    @PrimaryKey val id: String,
    val orderId: String,
    val productId: String,
    val sellerId: String,
    val buyerId: String,
    val referrerId: String?,
    val totalBaseAmount: Int,
    val platformPercent: Float, // 5%, 7% or 0%
    val referrerPercent: Float, // 2% or 0%
    val sellerPercent: Float, // 93% or 100%
    val platformAmount: Int,
    val referrerAmount: Int,
    val sellerAmount: Int,
    val status: String, // PENDING, CONFIRMED, REVERSED
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wallet_movements")
data class WalletMovementEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val concept: String,
    val source: String, // VENTA_PROPIA, COMISION_MARKETPLACE, COMISION_RECOMENDACION, PUBLICIDAD, RETIRO
    val amount: Int, // Can be positive or negative
    val currency: String = "CLP",
    val status: String, // ESTIMADO, PENDIENTE, CONFIRMADO, PAGADO
    val referenceCode: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "withdrawal_requests")
data class WithdrawalRequestEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val userName: String,
    val method: String, // TRANSFERENCIA_CHILENA, PAYPAL
    val amount: Int,
    val bankName: String = "",
    val accountType: String = "", // Cuenta Corriente, Cuenta Vista / RUT, Cuenta de Ahorro
    val rut: String = "",
    val accountNumber: String = "",
    val emailPayPal: String = "",
    val status: String = "SOLICITADO", // SOLICITADO, EN_REVISION, APROBADO, PAGADO, RECHAZADO
    val requestedAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val adminNotes: String = ""
)

@Entity(tableName = "ad_campaigns")
data class AdCampaignEntity(
    @PrimaryKey val id: String,
    val title: String,
    val advertiserName: String,
    val placement: String, // BANNER_TOP, IN_FEED, SIDEBAR
    val bannerImageUrl: String,
    val targetUrl: String,
    val adNetwork: String, // MONETAG, ADSTERRA, NEGOCIO_LOCAL
    val impressions: Int = 0,
    val clicks: Int = 0,
    val isActive: Boolean = true,
    val cpmOrFixedCLP: Int = 0
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val productId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val title: String,
    val message: String,
    val type: String, // ORDER, COMMISSION, SYSTEM, PROMO
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

// ==========================================
// QR Delivery & Returns System Entities
// ==========================================

enum class QrOperationType {
    DELIVERY_HANDOFF,   // Entrega: Comprador muestra QR, Repartidor escanea
    RETURN_PICKUP,      // Devolución 1: Repartidor recoge producto de comprador
    RETURN_RECEIVE      // Devolución 2: Vendedor recibe paquete devuelto de repartidor
}

enum class QrTokenStatus {
    ACTIVE,
    USED,
    EXPIRED,
    REVOKED
}

@Entity(tableName = "qr_security_tokens")
data class QrSecurityTokenEntity(
    @PrimaryKey val id: String,
    val token: String, // Opaque secure random token e.g. "MN-SEC-9B3E7A2C" (NO PII)
    val orderId: String,
    val orderNumber: String,
    val operationType: String, // DELIVERY_HANDOFF, RETURN_PICKUP, RETURN_RECEIVE
    val otpCode: String, // 6-digit numeric fallback code e.g. "582914"
    val authorizedActorRole: String, // Role required to validate (e.g. COURIER, SELLER)
    val targetUserId: String, // Owner/beneficiary of code (e.g. Buyer or Seller)
    val targetUserName: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (48 * 60 * 60 * 1000L), // 48h expiration
    val status: String = "ACTIVE", // ACTIVE, USED, EXPIRED, REVOKED
    val usedAt: Long? = null,
    val usedByActorId: String? = null,
    val usedByActorName: String? = null,
    val usedByActorRole: String? = null,
    val proofPhotoUrl: String? = null,
    val notes: String? = null
)

@Entity(tableName = "qr_audit_logs")
data class QrAuditLogEntity(
    @PrimaryKey val id: String,
    val token: String,
    val orderId: String,
    val orderNumber: String,
    val operationType: String,
    val actorId: String,
    val actorName: String,
    val actorRole: String,
    val timestamp: Long = System.currentTimeMillis(),
    val proofPhotoUrl: String = "",
    val status: String, // SUCCESS, REJECTED_EXPIRED, REJECTED_ALREADY_USED, REJECTED_UNAUTHORIZED, REJECTED_NOT_FOUND
    val message: String,
    val location: String = "Santiago, Chile"
)

