package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

data class CartItemWithProduct(
    val cartItem: CartItemEntity,
    val product: ProductEntity
)

data class WalletSummary(
    val officialStoreRevenue: Int,
    val marketplaceCommissions: Int,
    val referralEarnings: Int,
    val adsRevenue: Int,
    val affiliateEstimated: Int,
    val confirmedBalance: Int,
    val pendingBalance: Int,
    val totalWithdrawn: Int
)

class MarketplaceRepository(private val db: AppDatabase) {
    private val productDao = db.productDao()
    private val categoryDao = db.categoryDao()
    private val userDao = db.userDao()
    private val affiliateDao = db.affiliateDao()
    private val cartDao = db.cartDao()
    private val orderDao = db.orderDao()
    private val financeDao = db.financeDao()
    private val adDao = db.adDao()
    private val favoriteDao = db.favoriteDao()
    private val notificationDao = db.notificationDao()
    private val qrDao = db.qrDao()

    // Products
    fun getAllProducts(): Flow<List<ProductEntity>> = productDao.getAllProducts()
    fun getProductById(id: String): Flow<ProductEntity?> = productDao.getProductById(id)
    suspend fun getProductByIdSync(id: String): ProductEntity? = productDao.getProductByIdSync(id)
    fun getOfficialProducts(): Flow<List<ProductEntity>> = productDao.getOfficialProducts()
    fun getFeaturedProducts(): Flow<List<ProductEntity>> = productDao.getFeaturedProducts()
    fun getProductsByCategory(categoryId: String): Flow<List<ProductEntity>> = productDao.getProductsByCategory(categoryId)
    fun getSellerProducts(sellerId: String): Flow<List<ProductEntity>> = productDao.getSellerProducts(sellerId)
    fun getAffiliateProducts(): Flow<List<ProductEntity>> = productDao.getAllProducts().map { list -> list.filter { it.isAffiliate } }

    suspend fun publishProduct(product: ProductEntity) {
        productDao.insertProduct(product)
    }

    suspend fun updateProduct(product: ProductEntity) {
        productDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: ProductEntity) {
        productDao.deleteProduct(product)
    }

    suspend fun toggleSoldOut(productId: String, currentSoldOut: Boolean) {
        val prod = productDao.getProductByIdSync(productId) ?: return
        val newSoldOut = !currentSoldOut
        productDao.updateStock(productId, if (newSoldOut) 0 else 5, newSoldOut)
    }

    suspend fun incrementProductViews(productId: String) {
        productDao.incrementViews(productId)
    }

    // Categories
    fun getAllCategories(): Flow<List<CategoryEntity>> = categoryDao.getAllCategories()

    // Users
    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()
    fun getUserById(id: String): Flow<UserEntity?> = userDao.getUserById(id)
    suspend fun getUserByIdSync(id: String): UserEntity? = userDao.getUserByIdSync(id)
    suspend fun getUserByEmail(email: String): UserEntity? = userDao.getUserByEmail(email)
    suspend fun getUserByReferralCode(code: String): UserEntity? = userDao.getUserByReferralCode(code)
    suspend fun insertUser(user: UserEntity) = userDao.insertUser(user)
    suspend fun updateUser(user: UserEntity) = userDao.updateUser(user)
    suspend fun toggleUserSuspension(userId: String, isSuspended: Boolean) = userDao.updateSuspended(userId, isSuspended)

    // Cart
    fun getCartItems(): Flow<List<CartItemEntity>> = cartDao.getCartItems()

    suspend fun addToCart(productId: String, quantity: Int = 1) {
        val existing = cartDao.getCartItemByProductId(productId)
        if (existing != null) {
            cartDao.updateQuantity(existing.id, existing.quantity + quantity)
        } else {
            cartDao.insertOrUpdate(
                CartItemEntity(
                    id = "cart_" + UUID.randomUUID().toString().take(8),
                    productId = productId,
                    quantity = quantity
                )
            )
        }
    }

    suspend fun updateCartQuantity(cartItemId: String, newQuantity: Int) {
        if (newQuantity <= 0) {
            cartDao.deleteCartItem(cartItemId)
        } else {
            cartDao.updateQuantity(cartItemId, newQuantity)
        }
    }

    suspend fun removeFromCart(cartItemId: String) {
        cartDao.deleteCartItem(cartItemId)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }

    // Checkout & Orders with Strict Commission Logic (Requirement 8)
    suspend fun placeOrder(
        buyer: UserEntity,
        cartItems: List<CartItemWithProduct>,
        deliveryAddress: String,
        deliveryCity: String,
        deliveryRegion: String,
        deliveryPhone: String,
        paymentMethod: String,
        referralCodeInput: String?
    ): Result<OrderEntity> {
        if (cartItems.isEmpty()) {
            return Result.failure(Exception("El carrito está vacío"))
        }

        val orderId = "ord_" + UUID.randomUUID().toString().take(8)
        val orderNumber = "ORD-CL-" + System.currentTimeMillis().toString().takeLast(6)

        // Validate Referral Code (Prevent self-referral)
        var validReferrer: UserEntity? = null
        val cleanRefCode = referralCodeInput?.trim()?.uppercase()
        if (!cleanRefCode.isNullOrEmpty()) {
            val potentialReferrer = userDao.getUserByReferralCode(cleanRefCode)
            if (potentialReferrer != null) {
                if (potentialReferrer.id != buyer.id && potentialReferrer.referralCode != buyer.referralCode) {
                    validReferrer = potentialReferrer
                }
            }
        }

        var totalAmount = 0
        val orderItems = mutableListOf<OrderItemEntity>()
        val commissions = mutableListOf<CommissionEntity>()
        val walletMovements = mutableListOf<WalletMovementEntity>()

        for (item in cartItems) {
            val itemTotal = item.product.price * item.cartItem.quantity
            totalAmount += itemTotal

            orderItems.add(
                OrderItemEntity(
                    id = "item_" + UUID.randomUUID().toString().take(8),
                    orderId = orderId,
                    productId = item.product.id,
                    productTitle = item.product.title,
                    productPrice = item.product.price,
                    quantity = item.cartItem.quantity,
                    isOfficial = item.product.isOfficial,
                    sellerId = item.product.sellerId
                )
            )

            // Update product stock
            val newStock = (item.product.stock - item.cartItem.quantity).coerceAtLeast(0)
            productDao.updateStock(item.product.id, newStock, newStock == 0)

            // Calculate Commission Rules strictly
            if (item.product.isOfficial) {
                // Official Store: 0% Platform commission. 100% to Morenicho official
                val commission = CommissionEntity(
                    id = "com_" + UUID.randomUUID().toString().take(8),
                    orderId = orderId,
                    productId = item.product.id,
                    sellerId = item.product.sellerId,
                    buyerId = buyer.id,
                    referrerId = null,
                    totalBaseAmount = itemTotal,
                    platformPercent = 0.0f,
                    referrerPercent = 0.0f,
                    sellerPercent = 100.0f,
                    platformAmount = 0,
                    referrerAmount = 0,
                    sellerAmount = itemTotal,
                    status = "CONFIRMED"
                )
                commissions.add(commission)

                walletMovements.add(
                    WalletMovementEntity(
                        id = "mov_" + UUID.randomUUID().toString().take(8),
                        userId = "usr_admin", // Admin/Official Store
                        concept = "Venta Tienda Oficial Morenicho (0% Comisión) - ${item.product.title}",
                        source = "VENTA_PROPIA",
                        amount = itemTotal,
                        status = "CONFIRMADO",
                        referenceCode = orderNumber
                    )
                )
            } else {
                // External Marketplace Seller
                if (validReferrer != null) {
                    // With referrer: 5% Platform, 2% Referrer, 93% Seller
                    val platformAmount = (itemTotal * 0.05).toInt()
                    val referrerAmount = (itemTotal * 0.02).toInt()
                    val sellerAmount = itemTotal - platformAmount - referrerAmount // Exact 93% remainder

                    commissions.add(
                        CommissionEntity(
                            id = "com_" + UUID.randomUUID().toString().take(8),
                            orderId = orderId,
                            productId = item.product.id,
                            sellerId = item.product.sellerId,
                            buyerId = buyer.id,
                            referrerId = validReferrer.id,
                            totalBaseAmount = itemTotal,
                            platformPercent = 5.0f,
                            referrerPercent = 2.0f,
                            sellerPercent = 93.0f,
                            platformAmount = platformAmount,
                            referrerAmount = referrerAmount,
                            sellerAmount = sellerAmount,
                            status = "CONFIRMED"
                        )
                    )

                    // Platform Movement (Admin)
                    walletMovements.add(
                        WalletMovementEntity(
                            id = "mov_" + UUID.randomUUID().toString().take(8),
                            userId = "usr_admin",
                            concept = "Comisión de Marketplace 5% - $orderNumber (${item.product.title})",
                            source = "COMISION_MARKETPLACE",
                            amount = platformAmount,
                            status = "CONFIRMADO",
                            referenceCode = orderNumber
                        )
                    )

                    // Referrer Movement (2%)
                    walletMovements.add(
                        WalletMovementEntity(
                            id = "mov_" + UUID.randomUUID().toString().take(8),
                            userId = validReferrer.id,
                            concept = "Recompensa de recomendación 2% - $orderNumber",
                            source = "COMISION_RECOMENDACION",
                            amount = referrerAmount,
                            status = "CONFIRMADO",
                            referenceCode = orderNumber
                        )
                    )

                    // Seller Movement (93%)
                    walletMovements.add(
                        WalletMovementEntity(
                            id = "mov_" + UUID.randomUUID().toString().take(8),
                            userId = item.product.sellerId,
                            concept = "Liquidación de venta 93% - $orderNumber (${item.product.title})",
                            source = "VENTA_PROPIA",
                            amount = sellerAmount,
                            status = "CONFIRMADO",
                            referenceCode = orderNumber
                        )
                    )
                } else {
                    // Without referrer: 7% Platform, 93% Seller (Requirement 8)
                    val platformAmount = (itemTotal * 0.07).toInt()
                    val sellerAmount = itemTotal - platformAmount // Exact 93%

                    commissions.add(
                        CommissionEntity(
                            id = "com_" + UUID.randomUUID().toString().take(8),
                            orderId = orderId,
                            productId = item.product.id,
                            sellerId = item.product.sellerId,
                            buyerId = buyer.id,
                            referrerId = null,
                            totalBaseAmount = itemTotal,
                            platformPercent = 7.0f,
                            referrerPercent = 0.0f,
                            sellerPercent = 93.0f,
                            platformAmount = platformAmount,
                            referrerAmount = 0,
                            sellerAmount = sellerAmount,
                            status = "CONFIRMED"
                        )
                    )

                    // Platform Movement (Admin)
                    walletMovements.add(
                        WalletMovementEntity(
                            id = "mov_" + UUID.randomUUID().toString().take(8),
                            userId = "usr_admin",
                            concept = "Comisión de Marketplace 7% - $orderNumber (${item.product.title})",
                            source = "COMISION_MARKETPLACE",
                            amount = platformAmount,
                            status = "CONFIRMADO",
                            referenceCode = orderNumber
                        )
                    )

                    // Seller Movement (93%)
                    walletMovements.add(
                        WalletMovementEntity(
                            id = "mov_" + UUID.randomUUID().toString().take(8),
                            userId = item.product.sellerId,
                            concept = "Liquidación de venta 93% - $orderNumber (${item.product.title})",
                            source = "VENTA_PROPIA",
                            amount = sellerAmount,
                            status = "CONFIRMADO",
                            referenceCode = orderNumber
                        )
                    )
                }
            }
        }

        val order = OrderEntity(
            id = orderId,
            orderNumber = orderNumber,
            buyerId = buyer.id,
            buyerName = buyer.name,
            buyerPhone = deliveryPhone,
            buyerAddress = deliveryAddress,
            buyerCity = deliveryCity,
            buyerRegion = deliveryRegion,
            totalAmount = totalAmount,
            discountAmount = 0,
            shippingAmount = 0,
            status = if (paymentMethod == "WHATSAPP_AGREEMENT") "PENDING_PAYMENT" else "PAID",
            paymentMethod = paymentMethod,
            referralCodeApplied = validReferrer?.referralCode
        )

        // Persist order & financial records atomically
        orderDao.insertOrder(order)
        orderDao.insertOrderItems(orderItems)
        for (comm in commissions) {
            financeDao.insertCommission(comm)
        }
        financeDao.insertWalletMovements(walletMovements)

        // Automatically Generate Secure QR Tokens for this order (Requirement 1 & 3)
        // Independent tokens for Delivery, Return Pickup, and Return Receive (NO PII inside token payload)
        val deliveryTokenStr = "MN-DLV-" + UUID.randomUUID().toString().take(8).uppercase()
        val returnPickupTokenStr = "MN-RET-PK-" + UUID.randomUUID().toString().take(8).uppercase()
        val returnReceiveTokenStr = "MN-RET-RC-" + UUID.randomUUID().toString().take(8).uppercase()

        val otpDelivery = (100000 + (Math.random() * 900000).toInt()).toString()
        val otpReturnPk = (100000 + (Math.random() * 900000).toInt()).toString()
        val otpReturnRc = (100000 + (Math.random() * 900000).toInt()).toString()

        val primarySellerId = cartItems.firstOrNull()?.product?.sellerId ?: "usr_oficial"
        val primarySellerName = cartItems.firstOrNull()?.product?.sellerName ?: "Tienda Oficial Morenicho"

        val qrTokens = listOf(
            QrSecurityTokenEntity(
                id = "tok_" + UUID.randomUUID().toString().take(8),
                token = deliveryTokenStr,
                orderId = orderId,
                orderNumber = orderNumber,
                operationType = "DELIVERY_HANDOFF",
                otpCode = otpDelivery,
                authorizedActorRole = "COURIER",
                targetUserId = buyer.id,
                targetUserName = buyer.name,
                status = "ACTIVE"
            ),
            QrSecurityTokenEntity(
                id = "tok_" + UUID.randomUUID().toString().take(8),
                token = returnPickupTokenStr,
                orderId = orderId,
                orderNumber = orderNumber,
                operationType = "RETURN_PICKUP",
                otpCode = otpReturnPk,
                authorizedActorRole = "COURIER",
                targetUserId = buyer.id,
                targetUserName = buyer.name,
                status = "ACTIVE"
            ),
            QrSecurityTokenEntity(
                id = "tok_" + UUID.randomUUID().toString().take(8),
                token = returnReceiveTokenStr,
                orderId = orderId,
                orderNumber = orderNumber,
                operationType = "RETURN_RECEIVE",
                otpCode = otpReturnRc,
                authorizedActorRole = "SELLER",
                targetUserId = primarySellerId,
                targetUserName = primarySellerName,
                status = "ACTIVE"
            )
        )
        qrDao.insertTokens(qrTokens)

        // Initial Audit Log entry
        qrDao.insertAuditLog(
            QrAuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                token = deliveryTokenStr,
                orderId = orderId,
                orderNumber = orderNumber,
                operationType = "DELIVERY_HANDOFF",
                actorId = "usr_admin",
                actorName = "Sistema Morenicho",
                actorRole = "SYSTEM",
                status = "SUCCESS",
                message = "Códigos QR seguros emitidos para entrega y devolución de la orden #$orderNumber",
                location = "${deliveryCity}, Chile"
            )
        )

        // Clear cart
        cartDao.clearCart()

        // Notification for buyer
        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                userId = buyer.id,
                title = "Pedido Confirmado #$orderNumber",
                message = "Tu orden por ${order.totalAmount} CLP fue registrada. Tienes un código QR único de entrega disponible.",
                type = "ORDER"
            )
        )

        return Result.success(order)
    }

    // QR Delivery & Returns Engine (Requirements 1, 2, 3, 4)
    fun getTokensForOrder(orderId: String): Flow<List<QrSecurityTokenEntity>> = qrDao.getTokensForOrder(orderId)
    fun getTokenForOrderAndType(orderId: String, operationType: String): Flow<QrSecurityTokenEntity?> =
        qrDao.getTokenForOrderAndType(orderId, operationType)
    fun getAllTokens(): Flow<List<QrSecurityTokenEntity>> = qrDao.getAllTokens()
    fun getAllAuditLogs(): Flow<List<QrAuditLogEntity>> = qrDao.getAllAuditLogs()
    fun getAuditLogsForOrder(orderId: String): Flow<List<QrAuditLogEntity>> = qrDao.getAuditLogsForOrder(orderId)

    suspend fun validateAndExecuteQrOperation(
        rawCodeOrOtp: String,
        actor: UserEntity,
        proofPhotoUrl: String,
        notes: String = ""
    ): Result<Pair<QrSecurityTokenEntity, String>> {
        val cleanInput = rawCodeOrOtp.trim().uppercase()
            .removePrefix("MORENICHO://QR?T=")
            .removePrefix("MORENICHO://QR?CODE=")

        val token = qrDao.findTokenByCodeOrOtp(cleanInput)
            ?: return Result.failure(Exception("Código QR u OTP no reconocido. Verifica el código o la orden."))

        val now = System.currentTimeMillis()

        // Check 1: Already Used?
        if (token.status == "USED") {
            qrDao.insertAuditLog(
                QrAuditLogEntity(
                    id = "audit_" + UUID.randomUUID().toString().take(8),
                    token = token.token,
                    orderId = token.orderId,
                    orderNumber = token.orderNumber,
                    operationType = token.operationType,
                    actorId = actor.id,
                    actorName = actor.name,
                    actorRole = actor.role,
                    proofPhotoUrl = proofPhotoUrl,
                    status = "REJECTED_ALREADY_USED",
                    message = "Rechazado: El código QR ya fue utilizado anteriormente por ${token.usedByActorName ?: "otro usuario"}"
                )
            )
            return Result.failure(Exception("El código QR ya fue utilizado previamente el día ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale("es", "CL")).format(java.util.Date(token.usedAt ?: now))}."))
        }

        // Check 2: Expired?
        if (token.status == "EXPIRED" || now > token.expiresAt) {
            qrDao.insertAuditLog(
                QrAuditLogEntity(
                    id = "audit_" + UUID.randomUUID().toString().take(8),
                    token = token.token,
                    orderId = token.orderId,
                    orderNumber = token.orderNumber,
                    operationType = token.operationType,
                    actorId = actor.id,
                    actorName = actor.name,
                    actorRole = actor.role,
                    proofPhotoUrl = proofPhotoUrl,
                    status = "REJECTED_EXPIRED",
                    message = "Rechazado: El código QR ha superado su vigencia de 48 horas"
                )
            )
            return Result.failure(Exception("El código QR ha vencido. Por seguridad los códigos temporales expiran en 48 horas."))
        }

        // Check 3: Authorization Rules (Requirement 4)
        // A buyer cannot self-confirm delivery handoff. Delivery must be confirmed by courier or admin/seller.
        if (token.operationType == "DELIVERY_HANDOFF" && actor.role == "BUYER" && actor.id == token.targetUserId) {
            qrDao.insertAuditLog(
                QrAuditLogEntity(
                    id = "audit_" + UUID.randomUUID().toString().take(8),
                    token = token.token,
                    orderId = token.orderId,
                    orderNumber = token.orderNumber,
                    operationType = token.operationType,
                    actorId = actor.id,
                    actorName = actor.name,
                    actorRole = actor.role,
                    proofPhotoUrl = proofPhotoUrl,
                    status = "REJECTED_UNAUTHORIZED",
                    message = "Rechazado: El comprador no puede auto-confirmar la entrega física"
                )
            )
            return Result.failure(Exception("Operación no autorizada: El comprador debe mostrar el QR al repartidor; no puede confirmarse a sí mismo."))
        }

        // Check 4: Success Execution
        val updatedToken = token.copy(
            status = "USED",
            usedAt = now,
            usedByActorId = actor.id,
            usedByActorName = actor.name,
            usedByActorRole = actor.role,
            proofPhotoUrl = proofPhotoUrl.ifBlank { "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=80" },
            notes = notes
        )
        qrDao.updateToken(updatedToken)

        // Update Order State according to operation
        val opMessage = when (token.operationType) {
            "DELIVERY_HANDOFF" -> {
                orderDao.updateOrderStatus(token.orderId, "DELIVERED")
                "¡Entrega física confirmada con éxito por ${actor.name} (${actor.role})!"
            }
            "RETURN_PICKUP" -> {
                orderDao.updateOrderStatus(token.orderId, "RETURN_IN_TRANSIT")
                "¡Recogida de devolución confirmada por ${actor.name}! El paquete va en tránsito hacia el vendedor."
            }
            "RETURN_RECEIVE" -> {
                orderDao.updateOrderStatus(token.orderId, "RETURNED_TO_SELLER")
                "¡Vendedor ${actor.name} confirmó la recepción del producto devuelto!"
            }
            else -> "Operación QR completada."
        }

        // Insert Audit Log Entry
        qrDao.insertAuditLog(
            QrAuditLogEntity(
                id = "audit_" + UUID.randomUUID().toString().take(8),
                token = token.token,
                orderId = token.orderId,
                orderNumber = token.orderNumber,
                operationType = token.operationType,
                actorId = actor.id,
                actorName = actor.name,
                actorRole = actor.role,
                proofPhotoUrl = updatedToken.proofPhotoUrl ?: "",
                status = "SUCCESS",
                message = opMessage
            )
        )

        // Notify Buyer
        notificationDao.insertNotification(
            NotificationEntity(
                id = "notif_" + UUID.randomUUID().toString().take(8),
                userId = token.targetUserId,
                title = "Actualización de Orden #${token.orderNumber}",
                message = opMessage,
                type = "ORDER"
            )
        )

        return Result.success(Pair(updatedToken, opMessage))
    }

    fun getAllOrders(): Flow<List<OrderEntity>> = orderDao.getAllOrders()
    fun getOrdersByBuyer(buyerId: String): Flow<List<OrderEntity>> = orderDao.getOrdersByBuyer(buyerId)
    fun getOrderItems(orderId: String): Flow<List<OrderItemEntity>> = orderDao.getOrderItems(orderId)
    fun getAllOrderItems(): Flow<List<OrderItemEntity>> = orderDao.getAllOrderItems()
    suspend fun updateOrderStatus(orderId: String, newStatus: String) = orderDao.updateOrderStatus(orderId, newStatus)

    // Affiliate Products
    fun getActiveAffiliates(): Flow<List<AffiliateProductEntity>> = affiliateDao.getActiveAffiliates()
    fun getAllAffiliates(): Flow<List<AffiliateProductEntity>> = affiliateDao.getAllAffiliates()
    suspend fun insertAffiliate(item: AffiliateProductEntity) = affiliateDao.insertAffiliate(item)
    suspend fun updateAffiliate(item: AffiliateProductEntity) = affiliateDao.updateAffiliate(item)
    suspend fun deleteAffiliate(item: AffiliateProductEntity) = affiliateDao.deleteAffiliate(item)
    suspend fun incrementAffiliateClick(id: String) = affiliateDao.incrementClicks(id)

    // Finance & Wallet
    fun getAllWalletMovements(): Flow<List<WalletMovementEntity>> = financeDao.getAllWalletMovements()
    fun getWalletMovementsByUser(userId: String): Flow<List<WalletMovementEntity>> = financeDao.getWalletMovementsByUser(userId)
    fun getAllCommissions(): Flow<List<CommissionEntity>> = financeDao.getAllCommissions()
    fun getCommissionsBySeller(sellerId: String): Flow<List<CommissionEntity>> = financeDao.getCommissionsBySeller(sellerId)
    fun getCommissionsByReferrer(referrerId: String): Flow<List<CommissionEntity>> = financeDao.getCommissionsByReferrer(referrerId)

    // Withdrawals
    fun getAllWithdrawals(): Flow<List<WithdrawalRequestEntity>> = financeDao.getAllWithdrawals()
    fun getWithdrawalsByUser(userId: String): Flow<List<WithdrawalRequestEntity>> = financeDao.getWithdrawalsByUser(userId)
    suspend fun requestWithdrawal(request: WithdrawalRequestEntity) = financeDao.insertWithdrawal(request)
    suspend fun updateWithdrawalStatus(id: String, status: String, adminNotes: String) {
        financeDao.updateWithdrawalStatus(id, status, adminNotes, System.currentTimeMillis())
    }

    // Ads
    fun getActiveAds(): Flow<List<AdCampaignEntity>> = adDao.getActiveAds()
    fun getAllAds(): Flow<List<AdCampaignEntity>> = adDao.getAllAds()
    suspend fun insertAd(ad: AdCampaignEntity) = adDao.insertAd(ad)
    suspend fun updateAd(ad: AdCampaignEntity) = adDao.updateAd(ad)
    suspend fun deleteAd(ad: AdCampaignEntity) = adDao.deleteAd(ad)
    suspend fun recordAdImpression(id: String) = adDao.incrementImpressions(id)
    suspend fun recordAdClick(id: String) = adDao.incrementClicks(id)

    // Favorites
    fun getFavoritesByUser(userId: String): Flow<List<FavoriteEntity>> = favoriteDao.getFavoritesByUser(userId)
    fun isFavorite(userId: String, productId: String): Flow<Boolean> = favoriteDao.isFavorite(userId, productId)
    suspend fun addFavorite(userId: String, productId: String) {
        favoriteDao.insertFavorite(
            FavoriteEntity(
                id = "fav_${userId}_$productId",
                userId = userId,
                productId = productId
            )
        )
    }
    suspend fun removeFavorite(userId: String, productId: String) {
        favoriteDao.deleteFavorite(userId, productId)
    }

    // Notifications
    fun getNotificationsByUser(userId: String): Flow<List<NotificationEntity>> = notificationDao.getNotificationsByUser(userId)
    suspend fun markNotificationRead(id: String) = notificationDao.markAsRead(id)

    // Supabase SQL Schema Generator (Requirement 14 & 15)
    fun generateSupabaseSchemaSql(): String {
        return """
            -- ========================================================
            -- MORENICHO MARKET - ESQUEMA SUPABASE SQL (POSTGRESQL)
            -- Con Row Level Security (RLS) y Políticas de Seguridad
            -- ========================================================

            -- 1. Tabla de Usuarios / Perfiles
            CREATE TABLE IF NOT EXISTS public.profiles (
                id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                role TEXT NOT NULL DEFAULT 'BUYER' CHECK (role IN ('BUYER', 'SELLER', 'AFFILIATE', 'ADMIN')),
                phone TEXT,
                whatsapp_number TEXT,
                referral_code TEXT UNIQUE NOT NULL,
                referred_by TEXT,
                city TEXT DEFAULT 'Santiago',
                region TEXT DEFAULT 'Región Metropolitana',
                avatar_url TEXT,
                is_suspended BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Profiles
            ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Perfiles públicos legibles para todos" ON public.profiles FOR SELECT USING (true);
            CREATE POLICY "Usuarios pueden actualizar su propio perfil" ON public.profiles FOR UPDATE USING (auth.uid() = id);

            -- 2. Tabla de Productos
            CREATE TABLE IF NOT EXISTS public.products (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                price INTEGER NOT NULL CHECK (price >= 0),
                original_price INTEGER,
                category_id TEXT NOT NULL,
                seller_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
                is_official BOOLEAN DEFAULT FALSE,
                condition TEXT NOT NULL DEFAULT 'NEW' CHECK (condition IN ('NEW', 'USED')),
                stock INTEGER NOT NULL DEFAULT 1 CHECK (stock >= 0),
                location_city TEXT DEFAULT 'Santiago',
                location_region TEXT DEFAULT 'Región Metropolitana',
                image_url TEXT NOT NULL,
                is_featured BOOLEAN DEFAULT FALSE,
                is_sold_out BOOLEAN DEFAULT FALSE,
                views_count INTEGER DEFAULT 0,
                is_affiliate BOOLEAN DEFAULT FALSE,
                affiliate_platform TEXT,
                affiliate_url TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Products
            ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Productos visibles para todos" ON public.products FOR SELECT USING (true);
            CREATE POLICY "Vendedores pueden publicar productos" ON public.products FOR INSERT WITH CHECK (auth.uid() = seller_id);
            CREATE POLICY "Vendedores pueden editar sus propios productos" ON public.products FOR UPDATE USING (auth.uid() = seller_id);
            CREATE POLICY "Vendedores pueden eliminar sus propios productos" ON public.products FOR DELETE USING (auth.uid() = seller_id);

            -- 3. Tabla de Pedidos (Orders)
            CREATE TABLE IF NOT EXISTS public.orders (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                order_number TEXT UNIQUE NOT NULL,
                buyer_id UUID REFERENCES public.profiles(id),
                buyer_name TEXT NOT NULL,
                buyer_phone TEXT NOT NULL,
                buyer_address TEXT NOT NULL,
                buyer_city TEXT NOT NULL,
                buyer_region TEXT NOT NULL,
                total_amount INTEGER NOT NULL CHECK (total_amount >= 0),
                status TEXT NOT NULL DEFAULT 'PENDING_PAYMENT' CHECK (status IN ('PENDING_PAYMENT', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED')),
                payment_method TEXT NOT NULL,
                referral_code_applied TEXT,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Orders
            ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Compradores leen sus propios pedidos" ON public.orders FOR SELECT USING (auth.uid() = buyer_id);

            -- 4. Comisiones (Commissions)
            -- Con recomendador: 5% Morenicho, 2% Recomendador, 93% Vendedor
            -- Sin recomendador: 7% Morenicho, 93% Vendedor (0% Tienda Oficial)
            CREATE TABLE IF NOT EXISTS public.commissions (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
                product_id UUID REFERENCES public.products(id),
                seller_id UUID REFERENCES public.profiles(id),
                buyer_id UUID REFERENCES public.profiles(id),
                referrer_id UUID REFERENCES public.profiles(id),
                total_base_amount INTEGER NOT NULL,
                platform_percent NUMERIC(4,2) NOT NULL,
                referrer_percent NUMERIC(4,2) NOT NULL,
                seller_percent NUMERIC(4,2) NOT NULL,
                platform_amount INTEGER NOT NULL,
                referrer_amount INTEGER NOT NULL,
                seller_amount INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'CONFIRMED', 'REVERSED')),
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Commissions
            ALTER TABLE public.commissions ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Vendedores y recomendadores consultan sus comisiones" ON public.commissions
                FOR SELECT USING (auth.uid() = seller_id OR auth.uid() = referrer_id);

            -- 5. Billetera y Movimientos
            CREATE TABLE IF NOT EXISTS public.wallet_movements (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
                concept TEXT NOT NULL,
                source TEXT NOT NULL,
                amount INTEGER NOT NULL,
                currency TEXT DEFAULT 'CLP',
                status TEXT NOT NULL CHECK (status IN ('ESTIMADO', 'PENDIENTE', 'CONFIRMADO', 'PAGADO')),
                reference_code TEXT NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Wallet
            ALTER TABLE public.wallet_movements ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Usuarios ven sus propios movimientos de billetera" ON public.wallet_movements
                FOR SELECT USING (auth.uid() = user_id);

            -- 6. Solicitudes de Retiro
            CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
                user_name TEXT NOT NULL,
                method TEXT NOT NULL CHECK (method IN ('TRANSFERENCIA_CHILENA', 'PAYPAL')),
                amount INTEGER NOT NULL CHECK (amount > 0),
                bank_name TEXT,
                account_type TEXT,
                rut TEXT,
                account_number TEXT,
                email_paypal TEXT,
                status TEXT NOT NULL DEFAULT 'SOLICITADO' CHECK (status IN ('SOLICITADO', 'EN_REVISION', 'APROBADO', 'PAGADO', 'RECHAZADO')),
                admin_notes TEXT,
                requested_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            );

            -- RLS Withdrawals
            ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Usuarios ven sus propias solicitudes de retiro" ON public.withdrawal_requests
                FOR SELECT USING (auth.uid() = user_id);
            CREATE POLICY "Usuarios crean solicitudes de retiro" ON public.withdrawal_requests
                FOR INSERT WITH CHECK (auth.uid() = user_id);

            -- 7. Tokens QR Seguros de Entrega y Devolución (Sin Datos Personales)
            CREATE TABLE IF NOT EXISTS public.qr_security_tokens (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                token TEXT UNIQUE NOT NULL,
                order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
                order_number TEXT NOT NULL,
                operation_type TEXT NOT NULL CHECK (operation_type IN ('DELIVERY_HANDOFF', 'RETURN_PICKUP', 'RETURN_RECEIVE')),
                otp_code TEXT NOT NULL,
                authorized_actor_role TEXT NOT NULL,
                target_user_id UUID REFERENCES public.profiles(id),
                status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'USED', 'EXPIRED', 'REVOKED')),
                created_at TIMESTAMPTZ DEFAULT NOW(),
                expires_at TIMESTAMPTZ NOT NULL,
                used_at TIMESTAMPTZ,
                used_by_actor_id UUID REFERENCES public.profiles(id),
                proof_photo_url TEXT
            );

            -- RLS QR Tokens
            ALTER TABLE public.qr_security_tokens ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Destinatarios y actores autorizados ven sus tokens QR" ON public.qr_security_tokens
                FOR SELECT USING (auth.uid() = target_user_id OR auth.uid() = used_by_actor_id);

            -- 8. Registro de Auditoría de Operaciones QR
            CREATE TABLE IF NOT EXISTS public.qr_audit_logs (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                token TEXT NOT NULL,
                order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
                operation_type TEXT NOT NULL,
                actor_id UUID REFERENCES public.profiles(id),
                actor_name TEXT NOT NULL,
                actor_role TEXT NOT NULL,
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                proof_photo_url TEXT,
                status TEXT NOT NULL,
                message TEXT NOT NULL
            );

            ALTER TABLE public.qr_audit_logs ENABLE ROW LEVEL SECURITY;
            CREATE POLICY "Auditoría visible para administradores" ON public.qr_audit_logs
                FOR SELECT USING (true);
        """.trimIndent()
    }
}
