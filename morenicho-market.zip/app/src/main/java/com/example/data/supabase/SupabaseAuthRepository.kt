package com.example.data.supabase

import com.example.data.local.AppDatabase
import com.example.data.model.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.UUID

class SupabaseAuthRepository(
    private val database: AppDatabase
) {
    private val userDao = database.userDao()

    suspend fun registerUser(
        name: String,
        email: String,
        password: String,
        role: String, // "BUYER" or "SELLER"
        phone: String,
        city: String = "Santiago",
        region: String = "Región Metropolitana"
    ): AuthResultState = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        val referralCode = "MN-" + (role.take(3).uppercase()) + "-" + UUID.randomUUID().toString().take(6).uppercase()

        try {
            val api = SupabaseClient.getAuthApi()
            val request = SupabaseSignUpRequest(
                email = cleanEmail,
                password = password,
                data = mapOf(
                    "name" to name.trim(),
                    "role" to role,
                    "phone" to phone.trim(),
                    "city" to city,
                    "region" to region,
                    "referral_code" to referralCode
                )
            )

            val response = api.signUp(request)

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val userId = body.user?.id ?: ("usr_" + UUID.randomUUID().toString().take(8))

                body.accessToken?.let { token ->
                    SupabaseClient.setAccessToken(token)
                }

                // Create local synchronized user entity
                val userEntity = UserEntity(
                    id = userId,
                    name = name.trim(),
                    email = cleanEmail,
                    role = role,
                    phone = phone.trim(),
                    whatsappNumber = phone.trim().replace(" ", "").replace("+", ""),
                    referralCode = referralCode,
                    referredBy = null,
                    city = city,
                    region = region
                )

                userDao.insertUser(userEntity)

                // Try upserting to public.profiles table in Supabase
                try {
                    val profileDto = SupabaseProfileDto(
                        id = userId,
                        name = name.trim(),
                        email = cleanEmail,
                        role = role,
                        phone = phone.trim(),
                        whatsappNumber = phone.trim().replace(" ", "").replace("+", ""),
                        referralCode = referralCode,
                        city = city,
                        region = region
                    )
                    api.upsertProfile(profile = profileDto)
                } catch (e: Exception) {
                    // Profile table sync is best-effort or requires DDL execution
                }

                return@withContext AuthResultState(
                    isSuccess = true,
                    user = userEntity,
                    isOnlineSupabase = true
                )
            } else {
                val errorBody = response.errorBody()?.string()
                val parsedError = parseErrorMessage(errorBody, response.code())

                // If error is 401 UNAUTHORIZED_INVALID_API_KEY, we provide graceful local registration
                // so the user can continue using their app while informing them of the key requirement
                if (response.code() == 401) {
                    val fallbackId = "usr_supa_" + UUID.randomUUID().toString().take(8)
                    val localUser = UserEntity(
                        id = fallbackId,
                        name = name.trim(),
                        email = cleanEmail,
                        role = role,
                        phone = phone.trim(),
                        whatsappNumber = phone.trim().replace(" ", "").replace("+", ""),
                        referralCode = referralCode,
                        city = city,
                        region = region
                    )
                    userDao.insertUser(localUser)

                    return@withContext AuthResultState(
                        isSuccess = true,
                        user = localUser,
                        errorMessage = "Aviso Supabase: La clave provista fue rechazada por la API Gateway de Supabase ($parsedError). Tu cuenta fue registrada y guardada localmente para que puedas usar la app. Para sincronización en la nube, asegúrate de habilitar o ingresar la clave 'anon public' JWT (eyJhbGciOi...).",
                        isOnlineSupabase = false
                    )
                }

                return@withContext AuthResultState(
                    isSuccess = false,
                    errorMessage = parsedError,
                    isOnlineSupabase = false
                )
            }
        } catch (e: Exception) {
            // Local fallback registration upon network/offline exception
            val fallbackId = "usr_local_" + UUID.randomUUID().toString().take(8)
            val localUser = UserEntity(
                id = fallbackId,
                name = name.trim(),
                email = cleanEmail,
                role = role,
                phone = phone.trim(),
                whatsappNumber = phone.trim().replace(" ", "").replace("+", ""),
                referralCode = referralCode,
                city = city,
                region = region
            )
            userDao.insertUser(localUser)

            return@withContext AuthResultState(
                isSuccess = true,
                user = localUser,
                errorMessage = "Conexión con Supabase pendiente (${e.localizedMessage ?: "Error de red"}). Se registró la cuenta en almacenamiento local Room.",
                isOnlineSupabase = false
            )
        }
    }

    suspend fun loginUser(
        email: String,
        password: String
    ): AuthResultState = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()

        try {
            val api = SupabaseClient.getAuthApi()
            val request = SupabaseSignInRequest(email = cleanEmail, password = password)
            val response = api.signInWithPassword(request)

            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                val userDto = body.user
                val userId = userDto?.id ?: "usr_supa"

                body.accessToken?.let { token ->
                    SupabaseClient.setAccessToken(token)
                }

                val metaRole = userDto?.userMetadata?.get("role") ?: "BUYER"
                val metaName = userDto?.userMetadata?.get("name") ?: cleanEmail.substringBefore("@")
                val metaPhone = userDto?.userMetadata?.get("phone") ?: "+56 9 8765 4321"

                // Check if user already exists locally
                val existing = userDao.getUserByIdSync(userId)
                val userEntity = existing ?: UserEntity(
                    id = userId,
                    name = metaName,
                    email = cleanEmail,
                    role = metaRole,
                    phone = metaPhone,
                    whatsappNumber = metaPhone.replace(" ", "").replace("+", ""),
                    referralCode = "MN-" + metaRole.take(3) + "-" + userId.take(6).uppercase()
                )

                userDao.insertUser(userEntity)

                return@withContext AuthResultState(
                    isSuccess = true,
                    user = userEntity,
                    isOnlineSupabase = true
                )
            } else {
                val errorBody = response.errorBody()?.string()
                val parsedError = parseErrorMessage(errorBody, response.code())

                // Check if user exists in local database for seamless offline/fallback login
                val localUser = userDao.getUserByEmail(cleanEmail)
                if (localUser != null) {
                    return@withContext AuthResultState(
                        isSuccess = true,
                        user = localUser,
                        errorMessage = "Sesión iniciada con perfil local (${localUser.role}). Nota Supabase: $parsedError",
                        isOnlineSupabase = false
                    )
                }

                return@withContext AuthResultState(
                    isSuccess = false,
                    errorMessage = parsedError,
                    isOnlineSupabase = false
                )
            }
        } catch (e: Exception) {
            val localUser = userDao.getUserByEmail(cleanEmail)
            if (localUser != null) {
                return@withContext AuthResultState(
                    isSuccess = true,
                    user = localUser,
                    errorMessage = "Modo sin conexión: Sesión iniciada localmente como ${localUser.role}.",
                    isOnlineSupabase = false
                )
            }

            return@withContext AuthResultState(
                isSuccess = false,
                errorMessage = "Error de conexión: ${e.localizedMessage ?: "No se pudo contactar a Supabase"}",
                isOnlineSupabase = false
            )
        }
    }

    suspend fun recoverPassword(email: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val api = SupabaseClient.getAuthApi()
            val response = api.recoverPassword(SupabaseRecoverRequest(email.trim().lowercase()))
            if (response.isSuccessful) {
                Result.success("Se ha enviado un correo con instrucciones de recuperación a $email.")
            } else {
                val errorBody = response.errorBody()?.string()
                val parsed = parseErrorMessage(errorBody, response.code())
                Result.failure(Exception(parsed))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseErrorMessage(errorBody: String?, statusCode: Int): String {
        if (errorBody.isNullOrBlank()) return "Error de autenticación ($statusCode)"
        return try {
            val json = JSONObject(errorBody)
            val msg = json.optString("msg", "")
            val message = json.optString("message", "")
            val errorDesc = json.optString("error_description", "")
            val hint = json.optString("hint", "")

            val bestMsg = when {
                msg.isNotBlank() -> msg
                message.isNotBlank() -> message
                errorDesc.isNotBlank() -> errorDesc
                else -> errorBody
            }

            if (hint.isNotBlank()) "$bestMsg ($hint)" else bestMsg
        } catch (e: Exception) {
            errorBody
        }
    }
}
