package com.example.data.supabase

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

object SupabaseClient {

    private var currentAccessToken: String? = null

    fun setAccessToken(token: String?) {
        currentAccessToken = token
    }

    fun getAccessToken(): String? = currentAccessToken

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private fun createOkHttpClient(): OkHttpClient {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        val authInterceptor = Interceptor { chain ->
            val original = chain.request()
            val token = currentAccessToken ?: SupabaseConfig.currentAnonKey

            val requestBuilder = original.newBuilder()
                .header("apikey", SupabaseConfig.currentAnonKey)
                .header("Authorization", "Bearer $token")
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")

            chain.proceed(requestBuilder.build())
        }

        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(loggingInterceptor)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    fun getAuthApi(): SupabaseAuthApi {
        val baseUrl = if (SupabaseConfig.currentUrl.endsWith("/")) {
            SupabaseConfig.currentUrl
        } else {
            "${SupabaseConfig.currentUrl}/"
        }

        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(createOkHttpClient())
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(SupabaseAuthApi::class.java)
    }

    suspend fun pingProject(): Result<Boolean> {
        return try {
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build()

            val request = Request.Builder()
                .url("${SupabaseConfig.currentUrl}/rest/v1/")
                .header("apikey", SupabaseConfig.currentAnonKey)
                .header("Authorization", "Bearer ${SupabaseConfig.currentAnonKey}")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful || response.code == 401) {
                // Server responded and endpoint exists
                Result.success(true)
            } else {
                Result.success(false)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
