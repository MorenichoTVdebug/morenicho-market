package com.example.data.supabase

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object SupabaseConfig {
    const val DEFAULT_URL = "https://kpygbsbkhjtcuvojirke.supabase.co"
    const val DEFAULT_ANON_KEY = "Sb_publishable_a5yDwBHDeEhWm6vMYJZvHg_S-8_QH1b"

    var currentUrl by mutableStateOf(DEFAULT_URL)
    var currentAnonKey by mutableStateOf(DEFAULT_ANON_KEY)

    fun updateCredentials(url: String, anonKey: String) {
        if (url.isNotBlank()) currentUrl = url.trim().removeSuffix("/")
        if (anonKey.isNotBlank()) currentAnonKey = anonKey.trim()
    }

    fun isConfigured(): Boolean {
        return currentUrl.isNotBlank() && currentAnonKey.isNotBlank()
    }
}
