package com.example.data.supabase

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class SupabaseSignUpRequest(
    val email: String,
    val password: String,
    val data: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseSignInRequest(
    val email: String,
    val password: String
)

@JsonClass(generateAdapter = true)
data class SupabaseRecoverRequest(
    val email: String
)

@JsonClass(generateAdapter = true)
data class SupabaseAuthResponse(
    @Json(name = "access_token") val accessToken: String? = null,
    @Json(name = "token_type") val tokenType: String? = null,
    @Json(name = "expires_in") val expiresIn: Long? = null,
    @Json(name = "refresh_token") val refreshToken: String? = null,
    val user: SupabaseUserDto? = null,
    val error: String? = null,
    @Json(name = "error_description") val errorDescription: String? = null,
    @Json(name = "msg") val msg: String? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseUserDto(
    val id: String,
    val email: String? = null,
    @Json(name = "user_metadata") val userMetadata: Map<String, String>? = null,
    @Json(name = "created_at") val createdAt: String? = null
)

@JsonClass(generateAdapter = true)
data class SupabaseProfileDto(
    val id: String,
    val name: String,
    val email: String,
    val role: String, // BUYER or SELLER
    val phone: String,
    @Json(name = "whatsapp_number") val whatsappNumber: String,
    @Json(name = "referral_code") val referralCode: String,
    val city: String = "Santiago",
    val region: String = "Región Metropolitana"
)

data class AuthResultState(
    val isSuccess: Boolean,
    val user: com.example.data.model.UserEntity? = null,
    val errorMessage: String? = null,
    val isOnlineSupabase: Boolean = true
)
