package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ProductEntity
import com.example.data.model.UserEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MorenichoTopBar(
    currentScreen: Screen,
    currentUser: UserEntity,
    cartCount: Int,
    onNavigateCart: () -> Unit,
    onOpenSearch: () -> Unit,
    onSwitchUserClick: () -> Unit,
    onNavigateQr: (() -> Unit)? = null,
    onBackClick: (() -> Unit)? = null
) {
    Surface(
        color = BlackSurface,
        tonalElevation = 6.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBackClick != null && currentScreen !is Screen.Home) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.testTag("topbar_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver",
                                tint = WhiteText
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MORENICHO",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp,
                                    color = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "MARKET",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.5.sp,
                                    color = PurpleGlow
                                )
                            )
                        }
                        Text(
                            text = "Chile • CLP • Compra y Vende Seguro",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Quick Role Switcher Pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when (currentUser.role) {
                            "ADMIN" -> Color(0xFFEF4444).copy(alpha = 0.2f)
                            "SELLER" -> PurpleLight.copy(alpha = 0.2f)
                            "AFFILIATE" -> OfficialGold.copy(alpha = 0.2f)
                            else -> BlackSurfaceVariant
                        },
                        border = BorderStroke(
                            1.dp,
                            when (currentUser.role) {
                                "ADMIN" -> Color(0xFFEF4444)
                                "SELLER" -> PurpleLight
                                "AFFILIATE" -> OfficialGold
                                else -> BorderDark
                            }
                        ),
                        modifier = Modifier
                            .testTag("role_switcher_pill")
                            .clickable { onSwitchUserClick() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = when (currentUser.role) {
                                    "ADMIN" -> Icons.Default.AdminPanelSettings
                                    "SELLER" -> Icons.Default.Storefront
                                    "AFFILIATE" -> Icons.Default.Share
                                    else -> Icons.Default.Person
                                },
                                contentDescription = "Rol",
                                tint = when (currentUser.role) {
                                    "ADMIN" -> Color(0xFFEF4444)
                                    "SELLER" -> PurpleGlow
                                    "AFFILIATE" -> OfficialGold
                                    else -> WhiteText
                                },
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = currentUser.role,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = WhiteText
                                )
                            )
                        }
                    }

                    if (onNavigateQr != null) {
                        IconButton(
                            onClick = onNavigateQr,
                            modifier = Modifier.testTag("topbar_qr_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Escanear QR",
                                tint = PurpleGlow
                            )
                        }
                    }

                    // Cart Icon with Badge
                    IconButton(
                        onClick = onNavigateCart,
                        modifier = Modifier.testTag("topbar_cart_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartCount > 0) {
                                    Badge(
                                        containerColor = PurpleLight,
                                        contentColor = Color.White
                                    ) {
                                        Text("$cartCount")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Carrito",
                                tint = WhiteText
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MorenichoBottomNavigation(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    isAdmin: Boolean = false
) {
    NavigationBar(
        containerColor = BlackSurface,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        NavigationBarItem(
            selected = currentScreen is Screen.Home,
            onClick = { onNavigate(Screen.Home) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is Screen.Home) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Inicio"
                )
            },
            label = { Text("Inicio", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = PurpleGlow,
                indicatorColor = PurplePrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_home")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Categories,
            onClick = { onNavigate(Screen.Categories) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is Screen.Categories) Icons.Filled.Category else Icons.Outlined.Category,
                    contentDescription = "Categorías"
                )
            },
            label = { Text("Categorías", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = PurpleGlow,
                indicatorColor = PurplePrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_categories")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.PublishProduct,
            onClick = { onNavigate(Screen.PublishProduct) },
            icon = {
                Surface(
                    shape = CircleShape,
                    color = PurplePrimary,
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Publicar",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            },
            label = { Text("Publicar", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedTextColor = PurpleGlow,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_publish")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.WalletFinance,
            onClick = { onNavigate(Screen.WalletFinance) },
            icon = {
                Icon(
                    imageVector = if (currentScreen is Screen.WalletFinance) Icons.Filled.AccountBalanceWallet else Icons.Outlined.AccountBalanceWallet,
                    contentDescription = "Billetera"
                )
            },
            label = { Text("Billetera", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = PurpleGlow,
                indicatorColor = PurplePrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_wallet")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Profile || (isAdmin && currentScreen is Screen.AdminPanel),
            onClick = {
                if (isAdmin) onNavigate(Screen.AdminPanel) else onNavigate(Screen.Profile)
            },
            icon = {
                Icon(
                    imageVector = if (isAdmin) Icons.Filled.AdminPanelSettings else Icons.Filled.Person,
                    contentDescription = if (isAdmin) "Admin" else "Perfil"
                )
            },
            label = { Text(if (isAdmin) "Admin" else "Perfil", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                selectedTextColor = PurpleGlow,
                indicatorColor = PurplePrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_profile")
        )
    }
}

private data class AffiliatePlatformVisual(val bgColor: Color, val textColor: Color, val label: String)

@Composable
fun AffiliatePlatformBadge(
    platform: String,
    modifier: Modifier = Modifier
) {
    val visual = when (platform.trim().lowercase()) {
        "aliexpress" -> AffiliatePlatformVisual(Color(0xFFF97316), Color.White, "AliExpress")
        "amazon" -> AffiliatePlatformVisual(Color(0xFFEAB308), Color.Black, "Amazon")
        "hotmart" -> AffiliatePlatformVisual(Color(0xFFEF4444), Color.White, "Hotmart")
        else -> AffiliatePlatformVisual(PurplePrimary, Color.White, platform.trim())
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = visual.bgColor,
        shadowElevation = 2.dp,
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        ) {
            Icon(
                imageVector = Icons.Default.OpenInNew,
                contentDescription = null,
                tint = visual.textColor,
                modifier = Modifier.size(10.dp)
            )
            Text(
                text = visual.label,
                color = visual.textColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.3.sp
            )
        }
    }
}

@Composable
fun ProductCard(
    product: ProductEntity,
    isFavorite: Boolean,
    onProductClick: () -> Unit,
    onAddToCartClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val handleProductClick = {
        if (product.isAffiliate && !product.affiliateUrl.isNullOrBlank()) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(product.affiliateUrl))
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                // Ignore if no handler
            }
        } else {
            onProductClick()
        }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlackCard),
        border = BorderStroke(
            1.dp,
            when {
                product.isOfficial -> OfficialGold.copy(alpha = 0.5f)
                product.isAffiliate -> when (product.affiliatePlatform?.trim()?.lowercase()) {
                    "aliexpress" -> Color(0xFFF97316).copy(alpha = 0.6f)
                    "amazon" -> Color(0xFFEAB308).copy(alpha = 0.6f)
                    "hotmart" -> Color(0xFFEF4444).copy(alpha = 0.6f)
                    else -> PurplePrimary.copy(alpha = 0.5f)
                }
                else -> BorderDark
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
            .clickable { handleProductClick() }
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top badges
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (product.isOfficial) {
                            OfficialBadge()
                        }
                        if (product.isAffiliate) {
                            AffiliatePlatformBadge(product.affiliatePlatform ?: "Afiliado")
                        } else {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.Black.copy(alpha = 0.7f)
                            ) {
                                Text(
                                    text = if (product.condition == "NEW") "Nuevo" else "Usado",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        if (product.originalPrice != null && product.originalPrice > product.price) {
                            val discount = ((product.originalPrice - product.price).toFloat() / product.originalPrice * 100).toInt()
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFEF4444)
                            ) {
                                Text(
                                    text = "-$discount%",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    // Favorite Button
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorito",
                            tint = if (isFavorite) Color(0xFFEF4444) else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (product.isSoldOut || product.stock == 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.65f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFDC2626)
                        ) {
                            Text(
                                text = "AGOTADO",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = WhiteText
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (product.isAffiliate) Icons.Default.Public else Icons.Default.LocationOn,
                        contentDescription = "Ubicación o Red",
                        tint = if (product.isAffiliate) PurpleGlow else TextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (product.isAffiliate) "Afiliado ${product.affiliatePlatform ?: "Externo"}" else "${product.locationCity}, Chile",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (product.isAffiliate) PurpleGlow else TextMuted,
                            fontSize = 11.sp
                        ),
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        if (product.originalPrice != null && product.originalPrice > product.price) {
                            Text(
                                text = CurrencyFormatter.formatShortCLP(product.originalPrice),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    textDecoration = TextDecoration.LineThrough,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Text(
                            text = CurrencyFormatter.formatShortCLP(product.price),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        )
                    }

                    if (product.isAffiliate) {
                        val platformColor = when (product.affiliatePlatform?.trim()?.lowercase()) {
                            "aliexpress" -> Color(0xFFF97316)
                            "amazon" -> Color(0xFFEAB308)
                            "hotmart" -> Color(0xFFEF4444)
                            else -> PurplePrimary
                        }
                        val btnTextColor = if (product.affiliatePlatform?.trim()?.equals("amazon", ignoreCase = true) == true) Color.Black else Color.White

                        Button(
                            onClick = {
                                if (!product.affiliateUrl.isNullOrBlank()) {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(product.affiliateUrl))
                                    try { context.startActivity(intent) } catch (e: Exception) {}
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = platformColor,
                                contentColor = btnTextColor
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(34.dp)
                                .testTag("affiliate_btn_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = "Abrir enlace de afiliado",
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Ver",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else {
                        FilledIconButton(
                            onClick = onAddToCartClick,
                            enabled = !product.isSoldOut && product.stock > 0,
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = PurplePrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("add_to_cart_${product.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddShoppingCart,
                                contentDescription = "Agregar al carrito",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OfficialBadge() {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = OfficialGold,
        shadowElevation = 2.dp
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Verified,
                contentDescription = "Oficial",
                tint = Color.Black,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "TIENDA OFICIAL",
                color = Color.Black,
                fontWeight = FontWeight.Black,
                fontSize = 9.sp,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun AffiliateTransparencyCard() {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
        border = BorderStroke(1.dp, BorderDark),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = "Aviso Transparente",
                tint = InfoBlue,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Aviso transparente: Morenicho Market puede recibir una comisión por compras elegibles realizadas mediante enlaces afiliados (AliExpress, Amazon, Hotmart). Los precios oficiales no varían para el comprador.",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            )
        }
    }
}

@Composable
fun WhatsAppContactButton(
    phoneNumber: String,
    message: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Button(
        onClick = {
            val cleanPhone = phoneNumber.replace("+", "").replace(" ", "").replace("-", "")
            val url = "https://wa.me/$cleanPhone?text=${Uri.encode(message)}"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                // Fallback to browser
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(browserIntent)
            }
        },
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF25D366),
            contentColor = Color.White
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.testTag("whatsapp_contact_button")
    ) {
        Icon(
            imageVector = Icons.Default.Chat,
            contentDescription = "WhatsApp",
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Contactar por WhatsApp",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}
