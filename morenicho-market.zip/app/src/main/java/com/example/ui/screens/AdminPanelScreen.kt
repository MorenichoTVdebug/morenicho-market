package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.OfficialBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val allUsers by viewModel.allUsers.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val allOrders by viewModel.allOrders.collectAsState()
    val allCommissions by viewModel.allCommissions.collectAsState()
    val allWithdrawals by viewModel.allWithdrawals.collectAsState()
    val allAffiliates by viewModel.allAffiliates.collectAsState()
    val allAds by viewModel.allAds.collectAsState()
    val allQrTokens by viewModel.allQrTokens.collectAsState()
    val allAuditLogs by viewModel.allAuditLogs.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Resumen", "Ventas & Comisiones", "Productos", "Retiros", "Auditoría QR", "Afiliados", "Publicidad", "Supabase SQL")

    var showAddAffiliateModal by remember { mutableStateOf(false) }
    var showAddAdModal by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = onBack) {
                                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Panel Administrativo",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    color = WhiteText
                                )
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFEF4444).copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, Color(0xFFEF4444))
                        ) {
                            Text(
                                text = "ACCESO SEGURO",
                                color = Color(0xFFEF4444),
                                fontWeight = FontWeight.Black,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Horizontal Scrollable Tab Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        tabs.forEachIndexed { index, title ->
                            val isSelected = selectedTab == index
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                                modifier = Modifier.clickable { selectedTab = index }
                            ) {
                                Text(
                                    text = title,
                                    color = if (isSelected) Color.White else TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedTab) {
                // Tab 0: Resumen General
                0 -> {
                    item {
                        Text("Métricas Generales de Morenicho Market", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                    }

                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            MetricCard(
                                title = "Usuarios",
                                value = "${allUsers.size}",
                                icon = Icons.Default.People,
                                color = PurpleLight,
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Productos",
                                value = "${allProducts.size}",
                                icon = Icons.Default.Inventory2,
                                color = InfoBlue,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            val totalVol = allOrders.sumOf { it.totalAmount }
                            MetricCard(
                                title = "Ventas Totales",
                                value = CurrencyFormatter.formatShortCLP(totalVol),
                                icon = Icons.Default.Paid,
                                color = SuccessGreen,
                                modifier = Modifier.weight(1f)
                            )
                            val platformComms = allCommissions.sumOf { it.platformAmount }
                            MetricCard(
                                title = "Comisión 5%",
                                value = CurrencyFormatter.formatShortCLP(platformComms),
                                icon = Icons.Default.Percent,
                                color = OfficialGold,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackSurface),
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Reglas del Sistema de Comisiones Morenicho", color = WhiteText, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("• Vendedor externo CON recomendador: 5% Morenicho, 2% recomendador, 93% vendedor.", color = TextMuted, fontSize = 12.sp)
                                Text("• Vendedor externo SIN recomendador: 7% Morenicho, 93% vendedor.", color = TextMuted, fontSize = 12.sp)
                                Text("• Tienda Oficial Morenicho: 0% comisión de plataforma (100% oficial).", color = OfficialGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("• Base de cálculo: 100% transparente sobre la base distribuible, sin autorreferencias.", color = TextMuted, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Tab 1: Ventas & Comisiones
                1 -> {
                    item {
                        Text("Registro de Comisiones y Órdenes", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                    }

                    if (allCommissions.isEmpty()) {
                        item { Text("No hay comisiones registradas aún.", color = TextMuted) }
                    } else {
                        items(allCommissions) { comm ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackCard),
                                border = BorderStroke(1.dp, BorderDark),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Orden: ${comm.orderId}", color = PurpleGlow, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFF065F46)
                                        ) {
                                            Text(comm.status, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text("Base Distribuible: ${CurrencyFormatter.formatCLP(comm.totalBaseAmount)}", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Divider(color = BorderDark)

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Morenicho (${comm.platformPercent}%):", color = TextMuted, fontSize = 11.sp)
                                        Text(CurrencyFormatter.formatCLP(comm.platformAmount), color = PurpleLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Recomendador (${comm.referrerPercent}%):", color = TextMuted, fontSize = 11.sp)
                                        Text(CurrencyFormatter.formatCLP(comm.referrerAmount), color = OfficialGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Vendedor (${comm.sellerPercent}%):", color = TextMuted, fontSize = 11.sp)
                                        Text(CurrencyFormatter.formatCLP(comm.sellerAmount), color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Tab 2: Gestión de Productos
                2 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Moderar Publicaciones (${allProducts.size})", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                            Button(
                                onClick = { onNavigate(Screen.PublishProduct) },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                            ) {
                                Text("Publicar Oficial", fontSize = 12.sp)
                            }
                        }
                    }

                    items(allProducts) { prod ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackCard),
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(prod.title, color = WhiteText, fontWeight = FontWeight.Bold, maxLines = 1)
                                            if (prod.isOfficial) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                OfficialBadge()
                                            }
                                        }
                                        Text("Vendedor: ${prod.sellerName} • Stock: ${prod.stock}", color = TextMuted, fontSize = 11.sp)
                                    }
                                    Text(CurrencyFormatter.formatShortCLP(prod.price), color = SuccessGreen, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = { viewModel.toggleSoldOut(prod.id, prod.isSoldOut) },
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(if (prod.isSoldOut) "Reactivar" else "Marcar Agotado", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = { viewModel.deleteProduct(prod) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Eliminar", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Tab 3: Retiros
                3 -> {
                    item {
                        Text("Solicitudes de Retiro de Fondos", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                    }

                    if (allWithdrawals.isEmpty()) {
                        item { Text("No hay solicitudes de retiro pendientes.", color = TextMuted) }
                    } else {
                        items(allWithdrawals) { wdr ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackSurface),
                                border = BorderStroke(1.dp, BorderDark),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(wdr.userName, color = WhiteText, fontWeight = FontWeight.Bold)
                                        Text(CurrencyFormatter.formatCLP(wdr.amount), color = SuccessGreen, fontWeight = FontWeight.Bold)
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        if (wdr.method == "TRANSFERENCIA_CHILENA")
                                            "${wdr.bankName} (${wdr.accountType}) • RUT: ${wdr.rut} • Cuenta: ${wdr.accountNumber}"
                                        else
                                            "PayPal: ${wdr.emailPayPal}",
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.updateWithdrawalStatus(wdr.id, "PAGADO", "Comprobante de pago confirmado") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF065F46)),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Marcar Pagado", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = { viewModel.updateWithdrawalStatus(wdr.id, "APROBADO", "Aprobado para liquidación") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E40AF)),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Aprobar", fontSize = 11.sp)
                                        }

                                        Button(
                                            onClick = { viewModel.updateWithdrawalStatus(wdr.id, "RECHAZADO", "Datos bancarios incorrectos") },
                                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("Rechazar", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Tab 4: Auditoría QR (Entregas y Devoluciones Seguras)
                4 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "Auditoría QR de Custodia (${allAuditLogs.size})",
                                    style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    "Tokens Activos: ${allQrTokens.count { it.status == "ACTIVE" }}",
                                    color = PurpleGlow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onNavigate(Screen.QrScanner) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Escanear", fontSize = 11.sp)
                                }
                                OutlinedButton(
                                    onClick = { onNavigate(Screen.QrAuditHistory) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = WhiteText),
                                    border = BorderStroke(1.dp, PurpleLight),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text("Historial", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val successfulDeliveries = allAuditLogs.count { it.operationType == QrOperationType.DELIVERY_HANDOFF.name && it.status == "SUCCESS" }
                            val successfulReturns = allAuditLogs.count { (it.operationType == QrOperationType.RETURN_PICKUP.name || it.operationType == QrOperationType.RETURN_RECEIVE.name) && it.status == "SUCCESS" }
                            val rejectedOps = allAuditLogs.count { it.status.startsWith("REJECTED") }

                            MetricCard(
                                title = "Entregas OK",
                                value = "$successfulDeliveries",
                                icon = Icons.Default.CheckCircle,
                                color = SuccessGreen,
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Devoluciones",
                                value = "$successfulReturns",
                                icon = Icons.Default.AssignmentReturn,
                                color = InfoBlue,
                                modifier = Modifier.weight(1f)
                            )
                            MetricCard(
                                title = "Rechazados",
                                value = "$rejectedOps",
                                icon = Icons.Default.GppBad,
                                color = ErrorRed,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Security & Custody Notice Card
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackSurface),
                            border = BorderStroke(1.dp, PurpleDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(Icons.Default.Shield, contentDescription = null, tint = PurpleLight, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Regla de Custodia y Pagos", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        "Los códigos QR validan exclusivamente la transferencia física del paquete. La liberación de pagos al vendedor o reembolsos al comprador requiere verificación contable independiente.",
                                        color = TextMuted,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    if (allAuditLogs.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BlackSurface,
                                border = BorderStroke(1.dp, BorderDark),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Default.FactCheck, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("No hay registros de auditoría QR aún", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Los eventos de escaneo y validación de entrega/devolución aparecerán aquí en tiempo real.", color = TextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    } else {
                        items(allAuditLogs.take(20)) { log ->
                            val isSuccess = log.status == "SUCCESS"
                            val opLabel = when (log.operationType) {
                                QrOperationType.DELIVERY_HANDOFF.name -> "ENTREGA AL COMPRADOR"
                                QrOperationType.RETURN_PICKUP.name -> "RECOGIDA DE DEVOLUCIÓN"
                                QrOperationType.RETURN_RECEIVE.name -> "RECEPCIÓN EN VENDEDOR"
                                else -> log.operationType
                            }
                            val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("es", "CL")).format(Date(log.timestamp))

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackCard),
                                border = BorderStroke(1.dp, if (isSuccess) BorderDark else ErrorRed.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isSuccess) SuccessGreen.copy(alpha = 0.2f) else ErrorRed.copy(alpha = 0.2f),
                                            border = BorderStroke(1.dp, if (isSuccess) SuccessGreen else ErrorRed)
                                        ) {
                                            Text(
                                                text = if (isSuccess) "EXITOSO" else "RECHAZADO",
                                                color = if (isSuccess) SuccessGreen else ErrorRed,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        Text(dateStr, color = TextMuted, fontSize = 10.sp)
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(opLabel, color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Pedido: #${log.orderNumber} • Token: ${log.token.take(12)}...", color = TextMuted, fontSize = 11.sp)
                                    Text("Operador: ${log.actorName} (${log.actorRole})", color = PurpleLight, fontSize = 11.sp, fontWeight = FontWeight.Medium)

                                    if (!isSuccess && log.message.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Motivo: ${log.message}", color = ErrorRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    if (log.proofPhotoUrl.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Evidencia fotográfica adjunta", color = SuccessGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Tab 5: Afiliados (AliExpress, Amazon, Hotmart)
                5 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Productos Afiliados (${allAffiliates.size})", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                            Button(
                                onClick = { showAddAffiliateModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Nuevo Afiliado", fontSize = 12.sp)
                            }
                        }
                    }

                    items(allAffiliates) { aff ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackCard),
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(aff.name, color = WhiteText, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = PurplePrimary
                                        ) {
                                            Text(aff.platformSource, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text("Precio: ${CurrencyFormatter.formatCLP(aff.price)} • Comisión: ${aff.commissionRate}", color = TextMuted, fontSize = 11.sp)
                                    Text("Clics registrados: ${aff.clickCount}", color = PurpleGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                IconButton(onClick = { viewModel.deleteAffiliateProduct(aff) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = ErrorRed)
                                }
                            }
                        }
                    }
                }

                // Tab 6: Publicidad
                6 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Campañas de Publicidad (${allAds.size})", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
                            Button(
                                onClick = { showAddAdModal = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Nuevo Anuncio", fontSize = 12.sp)
                            }
                        }
                    }

                    items(allAds) { ad ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackSurface),
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(ad.title, color = WhiteText, fontWeight = FontWeight.Bold)
                                        Text("Red: ${ad.adNetwork} • Ubicación: ${ad.placement}", color = TextMuted, fontSize = 11.sp)
                                        Text("Impresiones: ${ad.impressions} • Clics: ${ad.clicks}", color = InfoBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    Switch(
                                        checked = ad.isActive,
                                        onCheckedChange = { viewModel.toggleAdActive(ad) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Tab 7: Supabase SQL & Seguridad (Requirement 14)
                7 -> {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                            border = BorderStroke(1.dp, PurpleDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DataObject, contentDescription = null, tint = SuccessGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Esquema Supabase SQL Preparado", color = WhiteText, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Morenicho Market incluye el script DDL completo para crear todas las tablas (profiles, products, orders, commissions, wallet_movements, withdrawal_requests) y políticas de Row Level Security (RLS) en Supabase cuando ingreses tus credenciales.",
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = {
                                        val sql = viewModel.repository.generateSupabaseSchemaSql()
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Supabase Schema SQL", sql)
                                        clipboard.setPrimaryClip(clip)
                                        viewModel.showToast("Esquema Supabase SQL copiado al portapapeles")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Copiar SQL de Supabase al Portapapeles", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackCard),
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("Instrucciones para Conectar Supabase:", color = WhiteText, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("1. Ingresa a tu proyecto en supabase.com y abre el SQL Editor.", color = TextMuted, fontSize = 11.sp)
                                Text("2. Pega el script generado arriba y ejecútalo para habilitar RLS y tablas.", color = TextMuted, fontSize = 11.sp)
                                Text("3. Configura tus variables SUPABASE_URL y SUPABASE_KEY en el panel de secretos.", color = TextMuted, fontSize = 11.sp)
                                Text("4. La app opera actualmente con persistencia local Room sin fingir conexiones falsas.", color = PurpleGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal para Agregar Producto Afiliado (Requirement 6)
    if (showAddAffiliateModal) {
        var affName by remember { mutableStateOf("") }
        var affPrice by remember { mutableStateOf("") }
        var affPlatform by remember { mutableStateOf("AliExpress") }
        var affUrl by remember { mutableStateOf("") }
        var affCommission by remember { mutableStateOf("8.5% por compra") }
        var affImg by remember { mutableStateOf("https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80") }

        AlertDialog(
            onDismissRequest = { showAddAffiliateModal = false },
            title = { Text("Agregar Producto Afiliado", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = affName, onValueChange = { affName = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = affPrice, onValueChange = { affPrice = it.filter { c -> c.isDigit() } }, label = { Text("Precio en CLP") }, modifier = Modifier.fillMaxWidth())

                    Text("Plataforma de Afiliación", color = WhiteText, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("AliExpress", "Amazon", "Hotmart").forEach { plat ->
                            FilterChip(
                                selected = affPlatform == plat,
                                onClick = { affPlatform = plat },
                                label = { Text(plat) }
                            )
                        }
                    }

                    OutlinedTextField(value = affUrl, onValueChange = { affUrl = it }, label = { Text("Enlace de Afiliado") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = affCommission, onValueChange = { affCommission = it }, label = { Text("Comisión Real (Ej: 10%)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = affImg, onValueChange = { affImg = it }, label = { Text("URL Fotografía") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = affPrice.toIntOrNull() ?: 0
                        if (affName.isNotBlank() && affUrl.isNotBlank()) {
                            viewModel.addAffiliateProduct(
                                name = affName,
                                description = "Producto internacional verificado en $affPlatform",
                                price = p,
                                categoryId = "tech",
                                platformSource = affPlatform,
                                affiliateUrl = affUrl,
                                commissionRate = affCommission,
                                imageUrl = affImg
                            )
                            showAddAffiliateModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("Guardar Afiliado")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAffiliateModal = false }) { Text("Cancelar") }
            },
            containerColor = BlackSurface
        )
    }

    // Modal para Agregar Campaña de Publicidad (Requirement 12)
    if (showAddAdModal) {
        var adTitle by remember { mutableStateOf("") }
        var advertiser by remember { mutableStateOf("") }
        var adNet by remember { mutableStateOf("NEGOCIO_LOCAL") }
        var placement by remember { mutableStateOf("IN_FEED") }
        var adImg by remember { mutableStateOf("https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=900&auto=format&fit=crop&q=80") }
        var targetUrl by remember { mutableStateOf("https://wa.me/56987654321") }

        AlertDialog(
            onDismissRequest = { showAddAdModal = false },
            title = { Text("Crear Campaña Publicitaria", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = adTitle, onValueChange = { adTitle = it }, label = { Text("Título de Anuncio") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = advertiser, onValueChange = { advertiser = it }, label = { Text("Nombre del Anunciante") }, modifier = Modifier.fillMaxWidth())

                    Text("Red / Tipo", color = WhiteText, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("MONETAG", "ADSTERRA", "NEGOCIO_LOCAL").forEach { net ->
                            FilterChip(
                                selected = adNet == net,
                                onClick = { adNet = net },
                                label = { Text(net) }
                            )
                        }
                    }

                    OutlinedTextField(value = targetUrl, onValueChange = { targetUrl = it }, label = { Text("URL de Destino / WhatsApp") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = adImg, onValueChange = { adImg = it }, label = { Text("URL Banner") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (adTitle.isNotBlank()) {
                            viewModel.addAdCampaign(
                                title = adTitle,
                                advertiser = advertiser,
                                placement = placement,
                                imageUrl = adImg,
                                targetUrl = targetUrl,
                                network = adNet,
                                fixedPrice = 10000
                            )
                            showAddAdModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("Publicar Anuncio")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAdModal = false }) { Text("Cancelar") }
            },
            containerColor = BlackSurface
        )
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = BlackCard),
        border = BorderStroke(1.dp, BorderDark),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.titleLarge.copy(color = WhiteText, fontWeight = FontWeight.Black))
            Spacer(modifier = Modifier.height(2.dp))
            Text(title, color = TextMuted, fontSize = 11.sp)
        }
    }
}
