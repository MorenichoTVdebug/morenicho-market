package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.supabase.SupabaseConfig
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: MarketplaceViewModel,
    initialMode: String = "REGISTER", // "LOGIN" or "REGISTER"
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var isRegisterMode by remember { mutableStateOf(initialMode == "REGISTER") }
    var selectedRole by remember { mutableStateOf("BUYER") } // "BUYER" or "SELLER"

    // Form inputs
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("+56 9 ") }
    var cityInput by remember { mutableStateOf("Santiago") }
    var regionInput by remember { mutableStateOf("Región Metropolitana") }

    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }

    // Recover password dialog
    var showRecoverDialog by remember { mutableStateOf(false) }
    var recoverEmailInput by remember { mutableStateOf("") }

    // Supabase credentials diagnostic modal
    var showConfigModal by remember { mutableStateOf(false) }
    var customUrlInput by remember { mutableStateOf(SupabaseConfig.currentUrl) }
    var customKeyInput by remember { mutableStateOf(SupabaseConfig.currentAnonKey) }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isRegisterMode) "Registro de Usuario" else "Iniciar Sesión",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    // Supabase connection pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
                        modifier = Modifier.clickable { showConfigModal = true }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color(0xFF10B981), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Supabase Auth",
                                color = Color(0xFF10B981),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Mode Toggle Switcher
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BlackSurface,
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (!isRegisterMode) PurplePrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                isRegisterMode = false
                                feedbackMessage = null
                            }
                    ) {
                        Text(
                            text = "Iniciar Sesión",
                            color = if (!isRegisterMode) Color.White else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .padding(vertical = 10.dp)
                                .wrapContentWidth(Alignment.CenterHorizontally)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isRegisterMode) PurplePrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                isRegisterMode = true
                                feedbackMessage = null
                            }
                    ) {
                        Text(
                            text = "Crear Cuenta",
                            color = if (isRegisterMode) Color.White else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            modifier = Modifier
                                .padding(vertical = 10.dp)
                                .wrapContentWidth(Alignment.CenterHorizontally)
                        )
                    }
                }
            }

            // Cloud connection banner
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                border = BorderStroke(1.dp, PurpleDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = null,
                        tint = PurpleGlow,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Conectado a Producción Supabase",
                            color = WhiteText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "https://kpygbsbkhjtcuvojirke.supabase.co",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                    IconButton(
                        onClick = { showConfigModal = true },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Configuración", tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Feedback Message Banner
            AnimatedVisibility(visible = feedbackMessage != null) {
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isError) ErrorRed.copy(alpha = 0.15f) else SuccessGreen.copy(alpha = 0.15f)
                    ),
                    border = BorderStroke(1.dp, if (isError) ErrorRed else SuccessGreen),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isError) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (isError) ErrorRed else SuccessGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = feedbackMessage ?: "",
                            color = WhiteText,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // ==========================================
            // REGISTER MODE: ROLE SELECTION & REGISTRATION
            // ==========================================
            if (isRegisterMode) {
                Text(
                    text = "Elige tu tipo de cuenta:",
                    color = WhiteText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                // Role selection cards (Buyer vs Seller)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Card Comprador
                    val isBuyer = selectedRole == "BUYER"
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isBuyer) PurplePrimary.copy(alpha = 0.15f) else BlackSurface
                        ),
                        border = BorderStroke(
                            1.5.dp,
                            if (isBuyer) PurplePrimary else BorderDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedRole = "BUYER" }
                            .testTag("role_select_buyer")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (isBuyer) PurplePrimary else BlackSurfaceVariant,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingBag,
                                        contentDescription = null,
                                        tint = if (isBuyer) Color.White else TextMuted
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Comprador",
                                color = if (isBuyer) PurpleLight else WhiteText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Comprar productos con entrega QR segura.",
                                color = TextMuted,
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally)
                            )
                        }
                    }

                    // Card Vendedor
                    val isSeller = selectedRole == "SELLER"
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSeller) OfficialGoldContainer else BlackSurface
                        ),
                        border = BorderStroke(
                            1.5.dp,
                            if (isSeller) OfficialGold else BorderDark
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedRole = "SELLER" }
                            .testTag("role_select_seller")
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (isSeller) OfficialGold else BlackSurfaceVariant,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Storefront,
                                        contentDescription = null,
                                        tint = if (isSeller) Color.Black else TextMuted
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Vendedor",
                                color = if (isSeller) OfficialGold else WhiteText,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Publicar catálogo, stock y recibir 93% en ventas.",
                                color = TextMuted,
                                fontSize = 10.sp,
                                lineHeight = 14.sp,
                                modifier = Modifier.wrapContentWidth(Alignment.CenterHorizontally)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Name Input
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Nombre Completo *") },
                    placeholder = { Text("Ej: Andrés Silva") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PurpleLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_name_input")
                )

                // Email Input
                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    label = { Text("Correo Electrónico *") },
                    placeholder = { Text("nombre@ejemplo.cl") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = PurpleLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_email_input")
                )

                // Password Input
                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    label = { Text("Contraseña (mínimo 6 caracteres) *") },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurpleLight) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Alternar contraseña",
                                tint = TextMuted
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("auth_password_input")
                )

                // Phone Input
                OutlinedTextField(
                    value = phoneInput,
                    onValueChange = { phoneInput = it },
                    label = { Text("Teléfono / WhatsApp *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PurpleLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Location row (City & Region)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = cityInput,
                        onValueChange = { cityInput = it },
                        label = { Text("Ciudad") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = regionInput,
                        onValueChange = { regionInput = it },
                        label = { Text("Región") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Register Submit Button
                Button(
                    onClick = {
                        if (nameInput.isBlank() || emailInput.isBlank() || passwordInput.isBlank()) {
                            feedbackMessage = "Por favor completa todos los campos requeridos (*)."
                            isError = true
                            return@Button
                        }
                        if (passwordInput.length < 6) {
                            feedbackMessage = "La contraseña debe tener al menos 6 caracteres."
                            isError = true
                            return@Button
                        }

                        isLoading = true
                        feedbackMessage = null

                        viewModel.registerWithSupabase(
                            name = nameInput,
                            email = emailInput,
                            password = passwordInput,
                            role = selectedRole,
                            phone = phoneInput,
                            city = cityInput,
                            region = regionInput
                        ) { result ->
                            isLoading = false
                            if (result.isSuccess) {
                                isError = false
                                feedbackMessage = if (result.isOnlineSupabase) {
                                    "¡Cuenta creada con éxito en Supabase Auth! Rol guardado: ${if (selectedRole == "SELLER") "Vendedor" else "Comprador"}."
                                } else {
                                    result.errorMessage ?: "Cuenta guardada exitosamente."
                                }
                                viewModel.showToast("Bienvenido, ${result.user?.name ?: nameInput}")
                            } else {
                                isError = true
                                feedbackMessage = result.errorMessage ?: "Error al registrar la cuenta en Supabase."
                            }
                        }
                    },
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedRole == "SELLER") OfficialGold else PurplePrimary,
                        contentColor = if (selectedRole == "SELLER") Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_register_button")
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                    } else {
                        Icon(imageVector = Icons.Default.AppRegistration, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Registrar como ${if (selectedRole == "SELLER") "Vendedor" else "Comprador"}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                // ==========================================
                // LOGIN MODE
                // ==========================================
                Text(
                    text = "Ingresa con tu cuenta de Morenicho Market:",
                    color = WhiteText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                // Email
                OutlinedTextField(
                    value = emailInput,
                    onValueChange = { emailInput = it },
                    label = { Text("Correo Electrónico *") },
                    placeholder = { Text("nombre@ejemplo.cl") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = PurpleLight) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email_input")
                )

                // Password
                OutlinedTextField(
                    value = passwordInput,
                    onValueChange = { passwordInput = it },
                    label = { Text("Contraseña *") },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = PurpleLight) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "Alternar contraseña",
                                tint = TextMuted
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { showRecoverDialog = true }) {
                        Text("¿Olvidaste tu contraseña?", color = PurpleGlow, fontSize = 12.sp)
                    }
                }

                // Login Submit Button
                Button(
                    onClick = {
                        if (emailInput.isBlank() || passwordInput.isBlank()) {
                            feedbackMessage = "Por favor ingresa tu correo y contraseña."
                            isError = true
                            return@Button
                        }

                        isLoading = true
                        feedbackMessage = null

                        viewModel.loginWithSupabase(
                            email = emailInput,
                            password = passwordInput
                        ) { result ->
                            isLoading = false
                            if (result.isSuccess) {
                                isError = false
                                feedbackMessage = if (result.isOnlineSupabase) {
                                    "¡Sesión iniciada con Supabase Auth!"
                                } else {
                                    result.errorMessage ?: "Sesión iniciada."
                                }
                                viewModel.showToast("Sesión iniciada: ${result.user?.name}")
                                onNavigate(Screen.Profile)
                            } else {
                                isError = true
                                feedbackMessage = result.errorMessage ?: "Error al autenticar con Supabase."
                            }
                        }
                    },
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("submit_login_button")
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                    } else {
                        Icon(imageVector = Icons.Default.Login, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Iniciar Sesión", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fast One-Tap Profile Switcher for quick demo
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Acceso Rápido de Prueba (Demo Roles)",
                            color = WhiteText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    emailInput = "comprador@morenicho.cl"
                                    passwordInput = "comprador123"
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("Comprador", fontSize = 11.sp, color = PurpleLight)
                            }

                            OutlinedButton(
                                onClick = {
                                    emailInput = "vendedor@morenicho.cl"
                                    passwordInput = "vendedor123"
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                            ) {
                                Text("Vendedor", fontSize = 11.sp, color = OfficialGold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Recover Password Dialog
    if (showRecoverDialog) {
        var recoverSuccess by remember { mutableStateOf<String?>(null) }
        var recoverError by remember { mutableStateOf<String?>(null) }
        var isSending by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRecoverDialog = false },
            title = { Text("Recuperar Contraseña", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Ingresa tu correo para recibir un enlace de restablecimiento seguro vía Supabase Auth:",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = recoverEmailInput,
                        onValueChange = { recoverEmailInput = it },
                        label = { Text("Correo Electrónico") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    recoverSuccess?.let {
                        Text(it, color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    recoverError?.let {
                        Text(it, color = ErrorRed, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (recoverEmailInput.isNotBlank()) {
                            isSending = true
                            viewModel.recoverPasswordWithSupabase(recoverEmailInput) { res ->
                                isSending = false
                                res.onSuccess {
                                    recoverSuccess = it
                                    recoverError = null
                                }
                                res.onFailure {
                                    recoverError = it.localizedMessage ?: "Error al enviar recuperación"
                                }
                            }
                        }
                    },
                    enabled = !isSending,
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text(if (isSending) "Enviando..." else "Enviar Correo")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecoverDialog = false }) {
                    Text("Cerrar")
                }
            },
            containerColor = BlackSurface
        )
    }

    // Supabase Diagnostics Modal
    if (showConfigModal) {
        AlertDialog(
            onDismissRequest = { showConfigModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudQueue, contentDescription = null, tint = PurpleGlow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Configuración de Supabase", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Credenciales configuradas en Morenicho Market:",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = customUrlInput,
                        onValueChange = { customUrlInput = it },
                        label = { Text("URL de Supabase") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = customKeyInput,
                        onValueChange = { customKeyInput = it },
                        label = { Text("Clave Pública / Anon Key") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Card(
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant)
                    ) {
                        Text(
                            text = "💡 Sugerencia: Si tu proyecto de Supabase rechaza la clave corta con error UNAUTHORIZED_INVALID_API_KEY, copia la clave JWT 'anon public' (que empieza con eyJhbGciOi...) desde Project Settings > API en app.supabase.com.",
                            color = OfficialGold,
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        SupabaseConfig.updateCredentials(customUrlInput, customKeyInput)
                        viewModel.showToast("Credenciales de Supabase actualizadas")
                        showConfigModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                ) {
                    Text("Guardar Cambios", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfigModal = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }
}
