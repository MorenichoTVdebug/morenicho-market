package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.OrderEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@Composable
fun CartAndCheckoutScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val cartItems by viewModel.cartItems.collectAsState()
    val totalAmount by viewModel.cartTotalAmount.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var address by remember { mutableStateOf("Av. Providencia 1234, Depto 502") }
    var city by remember { mutableStateOf("Providencia") }
    var region by remember { mutableStateOf("Región Metropolitana") }
    var phone by remember { mutableStateOf(currentUser.phone) }
    var referralCode by remember { mutableStateOf(currentUser.referredBy ?: "") }
    var selectedPaymentMethod by remember { mutableStateOf("WHATSAPP_AGREEMENT") }

    var confirmedOrder by remember { mutableStateOf<OrderEntity?>(null) }

    if (confirmedOrder != null) {
        val order = confirmedOrder!!
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = BlackSurface),
                border = BorderStroke(1.dp, PurplePrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Éxito",
                        tint = SuccessGreen,
                        modifier = Modifier.size(64.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "¡Pedido Registrado con Éxito!",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = WhiteText
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Número de Orden: ${order.orderNumber}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = PurpleGlow,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Total a pagar: ${CurrencyFormatter.formatCLP(order.totalAmount)}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = SuccessGreen,
                            fontWeight = FontWeight.Bold
                        )
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Dirección de despacho:\n${order.buyerAddress}, ${order.buyerCity}, ${order.buyerRegion}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextMuted,
                            lineHeight = 16.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // WhatsApp confirmation action
                    Button(
                        onClick = {
                            val msg = "Hola, he generado la orden #${order.orderNumber} en Morenicho Market por un total de ${CurrencyFormatter.formatCLP(order.totalAmount)}. Mi nombre es ${order.buyerName}. ¿Cómo coordinamos el pago y despacho?"
                            val url = "https://wa.me/56987654321?text=${Uri.encode(msg)}"
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            try { context.startActivity(intent) } catch (e: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Chat, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Coordinar por WhatsApp", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val targetOrderId = order.id
                            confirmedOrder = null
                            onNavigate(Screen.MyQrCode(orderId = targetOrderId))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.QrCode, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Ver Código QR de Entrega", fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = {
                            confirmedOrder = null
                            onNavigate(Screen.Home)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Volver al Inicio", color = WhiteText)
                    }
                }
            }
        }
        return
    }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Carrito y Checkout",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }
            }
        },
        bottomBar = {
            if (cartItems.isNotEmpty()) {
                Surface(
                    color = BlackSurface,
                    tonalElevation = 8.dp,
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total a Pagar (CLP):", color = TextMuted, fontSize = 14.sp)
                            Text(
                                text = CurrencyFormatter.formatCLP(totalAmount),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = SuccessGreen
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                viewModel.placeOrder(
                                    address = address,
                                    city = city,
                                    region = region,
                                    phone = phone,
                                    paymentMethod = selectedPaymentMethod,
                                    referralCode = referralCode.ifBlank { null }
                                ) { order ->
                                    confirmedOrder = order
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("checkout_confirm_button")
                        ) {
                            Text("Confirmar Pedido Seguro", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BlackBackground)
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.RemoveShoppingCart,
                        contentDescription = "Carrito Vacío",
                        tint = TextMuted,
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Tu carrito está vacío", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Explora los productos de Morenicho Market", color = TextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { onNavigate(Screen.Home) },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                    ) {
                        Text("Ir al Catálogo")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BlackBackground)
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "Productos en tu Carrito (${cartItems.size})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }

                items(cartItems) { item ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackCard),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = item.product.imageUrl,
                                contentDescription = item.product.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.product.title,
                                    style = MaterialTheme.typography.titleSmall.copy(color = WhiteText),
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = CurrencyFormatter.formatShortCLP(item.product.price),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            viewModel.updateCartQuantity(item.cartItem.id, item.cartItem.quantity - 1)
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Menos", tint = WhiteText)
                                    }
                                    Text(
                                        text = "${item.cartItem.quantity}",
                                        color = WhiteText,
                                        fontWeight = FontWeight.Bold
                                    )
                                    IconButton(
                                        onClick = {
                                            viewModel.updateCartQuantity(item.cartItem.id, item.cartItem.quantity + 1)
                                        },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Add, contentDescription = "Más", tint = WhiteText)
                                    }
                                }
                            }

                            IconButton(
                                onClick = { viewModel.removeFromCart(item.cartItem.id) }
                            ) {
                                Icon(imageVector = Icons.Default.Delete, contentDescription = "Eliminar", tint = ErrorRed)
                            }
                        }
                    }
                }

                // Delivery Info Section
                item {
                    Text(
                        text = "Datos de Entrega en Chile",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurface),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = address,
                                onValueChange = { address = it },
                                label = { Text("Dirección (Calle y Número)") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PurplePrimary,
                                    unfocusedBorderColor = BorderDark,
                                    focusedTextColor = WhiteText,
                                    unfocusedTextColor = WhiteText
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = city,
                                    onValueChange = { city = it },
                                    label = { Text("Comuna / Ciudad") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PurplePrimary,
                                        unfocusedBorderColor = BorderDark,
                                        focusedTextColor = WhiteText,
                                        unfocusedTextColor = WhiteText
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = region,
                                    onValueChange = { region = it },
                                    label = { Text("Región") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PurplePrimary,
                                        unfocusedBorderColor = BorderDark,
                                        focusedTextColor = WhiteText,
                                        unfocusedTextColor = WhiteText
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("Teléfono de Contacto") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PurplePrimary,
                                    unfocusedBorderColor = BorderDark,
                                    focusedTextColor = WhiteText,
                                    unfocusedTextColor = WhiteText
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Recommender Code Section (2% distribution)
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                        border = BorderStroke(1.dp, PurpleDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ConfirmationNumber,
                                    contentDescription = null,
                                    tint = OfficialGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Código de Recomendador (2%)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Si alguien te recomendó Morenicho Market, ingresa su código para asignarle su 2% de recompensa (no afecta tu precio final).",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = referralCode,
                                onValueChange = { referralCode = it },
                                placeholder = { Text("Ej: CAMI-CHILE") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PurplePrimary,
                                    unfocusedBorderColor = BorderDark,
                                    focusedTextColor = WhiteText,
                                    unfocusedTextColor = WhiteText
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Payment Gateway Preparation Notice (Requirement 7)
                item {
                    Text(
                        text = "Método de Pago",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurface),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            // Method 1: WhatsApp coordination
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "WHATSAPP_AGREEMENT",
                                    onClick = { selectedPaymentMethod = "WHATSAPP_AGREEMENT" }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Coordinar y Pago Seguro por WhatsApp", color = WhiteText, fontWeight = FontWeight.Bold)
                                    Text("Acuerda transferencia directa o efectivo contra entrega.", color = TextMuted, fontSize = 11.sp)
                                }
                            }

                            Divider(color = BorderDark)

                            // Method 2: Webpay Plus Transbank
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "WEBPAY_CHILE",
                                    onClick = { selectedPaymentMethod = "WEBPAY_CHILE" }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Webpay Plus (Transbank Chile)", color = WhiteText, fontWeight = FontWeight.Bold)
                                    Text("Tarjetas de Débito (Redcompra) y Crédito. Comisión pasarela: 1.49% + IVA. (Modo integración)", color = TextMuted, fontSize = 11.sp)
                                }
                            }

                            Divider(color = BorderDark)

                            // Method 3: Mercado Pago Chile
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "MERCADO_PAGO",
                                    onClick = { selectedPaymentMethod = "MERCADO_PAGO" }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text("Mercado Pago Chile", color = WhiteText, fontWeight = FontWeight.Bold)
                                    Text("Saldo Mercado Pago y tarjetas. Comisión pasarela: 3.19% + IVA. (Modo integración)", color = TextMuted, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // Security & transparency reminder
                item {
                    Text(
                        text = "🔒 Morenicho Market no simula pagos ficticios. Las ventas solo se consideran pagadas tras la validación segura de la transacción.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(bottom = 20.dp)
                    )
                }
            }
        }
    }
}
