package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun CategoriesScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val categories by viewModel.categories.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    var selectedCatId by remember { mutableStateOf<String?>(null) }

    val categoryProducts = if (selectedCatId == null) {
        emptyList()
    } else {
        allProducts.filter { it.categoryId == selectedCatId }
    }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (selectedCatId != null) {
                        IconButton(onClick = { selectedCatId = null }) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedCatId == null) "Todas las Categorías" else (categories.find { it.id == selectedCatId }?.name ?: "Categoría"),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }
            }
        }
    ) { padding ->
        if (selectedCatId == null) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .background(BlackBackground)
                    .padding(padding)
            ) {
                items(categories) { cat ->
                    val count = allProducts.count { it.categoryId == cat.id }
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackCard),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("cat_tile_${cat.id}")
                            .clickable { selectedCatId = cat.id }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Icon(
                                imageVector = when (cat.id) {
                                    "tech" -> Icons.Default.Computer
                                    "phones" -> Icons.Default.Smartphone
                                    "fashion" -> Icons.Default.Checkroom
                                    "home" -> Icons.Default.Home
                                    "vehicles" -> Icons.Default.DirectionsCar
                                    "sports" -> Icons.Default.FitnessCenter
                                    "beauty" -> Icons.Default.Spa
                                    "food" -> Icons.Default.Restaurant
                                    "real_estate" -> Icons.Default.Apartment
                                    else -> Icons.Default.Build
                                },
                                contentDescription = cat.name,
                                tint = PurpleLight,
                                modifier = Modifier.size(28.dp)
                            )

                            Column {
                                Text(
                                    text = cat.name,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                                Text(
                                    text = "$count productos",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(BlackBackground)
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "${categoryProducts.size} productos encontrados",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }

                if (categoryProducts.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Aún no hay productos en esta categoría.", color = TextMuted)
                        }
                    }
                } else {
                    items(categoryProducts.chunked(2)) { pair ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            for (prod in pair) {
                                Box(modifier = Modifier.weight(1f)) {
                                    ProductCard(
                                        product = prod,
                                        isFavorite = favorites.any { it.id == prod.id },
                                        onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                        onAddToCartClick = { viewModel.addToCart(prod.id) },
                                        onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                                    )
                                }
                            }
                            if (pair.size == 1) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}
