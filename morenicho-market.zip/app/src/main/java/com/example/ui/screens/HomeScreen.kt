package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.AdCampaignEntity
import com.example.data.model.AffiliateProductEntity
import com.example.data.model.CategoryEntity
import com.example.data.model.ProductEntity
import com.example.ui.components.AffiliateTransparencyCard
import com.example.ui.components.OfficialBadge
import com.example.ui.components.ProductCard
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allProducts by viewModel.allProducts.collectAsState()
    val filteredProducts by viewModel.filteredProducts.collectAsState()
    val officialProducts by viewModel.officialProducts.collectAsState()
    val featuredProducts by viewModel.featuredProducts.collectAsState()
    val affiliateProducts by viewModel.affiliateProducts.collectAsState()
    val categories by viewModel.categories.collectAsState()
    val activeAffiliates by viewModel.activeAffiliates.collectAsState()
    val activeAds by viewModel.activeAds.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedCategory by viewModel.selectedCategoryFilter.collectAsState()
    val onlyOfficial by viewModel.onlyOfficialFilter.collectAsState()
    val conditionFilter by viewModel.conditionFilter.collectAsState()
    val maxPriceFilter by viewModel.maxPriceFilter.collectAsState()
    val locationFilter by viewModel.locationFilter.collectAsState()

    var showFilterSheet by remember { mutableStateOf(false) }

    val isSearching = searchQuery.isNotBlank() || selectedCategory != null || onlyOfficial || conditionFilter != "ALL" || maxPriceFilter != null || locationFilter != null

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BlackBackground)
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Search & Filter Header
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.searchQuery.value = it },
                        placeholder = { Text("Buscar en Morenicho Market...", color = TextMuted) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Buscar",
                                tint = PurpleLight
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Limpiar",
                                        tint = TextMuted
                                    )
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText,
                            focusedContainerColor = BlackSurface,
                            unfocusedContainerColor = BlackSurface
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("search_text_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    FilledIconButton(
                        onClick = { showFilterSheet = true },
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = if (isSearching) PurplePrimary else BlackSurfaceVariant,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .size(54.dp)
                            .testTag("filter_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Filtros"
                        )
                    }
                }

                // Active Filter summary pill
                // Active Filter summary pills
                if (isSearching) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${filteredProducts.size} productos encontrados",
                                color = PurpleGlow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            TextButton(
                                onClick = { viewModel.clearFilters() },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("Limpiar todo", color = ErrorRed, fontSize = 12.sp)
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (selectedCategory != null) {
                                val catName = categories.find { it.id == selectedCategory }?.name ?: selectedCategory
                                FilterChip(
                                    selected = true,
                                    onClick = { viewModel.selectedCategoryFilter.value = null },
                                    label = { Text("Categoría: $catName", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurplePrimary, selectedLabelColor = Color.White)
                                )
                            }
                            if (locationFilter != null) {
                                FilterChip(
                                    selected = true,
                                    onClick = { viewModel.locationFilter.value = null },
                                    label = { Text("Ubicación: $locationFilter", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurplePrimary, selectedLabelColor = Color.White)
                                )
                            }
                            if (maxPriceFilter != null) {
                                FilterChip(
                                    selected = true,
                                    onClick = { viewModel.maxPriceFilter.value = null },
                                    label = { Text("Hasta ${CurrencyFormatter.formatShortCLP(maxPriceFilter!!)}", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurplePrimary, selectedLabelColor = Color.White)
                                )
                            }
                            if (conditionFilter != "ALL") {
                                FilterChip(
                                    selected = true,
                                    onClick = { viewModel.conditionFilter.value = "ALL" },
                                    label = { Text(if (conditionFilter == "NEW") "Nuevo" else "Usado", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurplePrimary, selectedLabelColor = Color.White)
                                )
                            }
                            if (onlyOfficial) {
                                FilterChip(
                                    selected = true,
                                    onClick = { viewModel.onlyOfficialFilter.value = false },
                                    label = { Text("Tienda Oficial", fontSize = 11.sp) },
                                    trailingIcon = { Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(12.dp)) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = PurplePrimary, selectedLabelColor = Color.White)
                                )
                            }
                        }
                    }
                }
            }
        }

        // If actively filtering, show the filtered results directly
        if (isSearching) {
            item {
                Text(
                    text = "Resultados de búsqueda",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            if (filteredProducts.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = "Sin resultados",
                            tint = TextMuted,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No se encontraron productos",
                            style = MaterialTheme.typography.titleMedium.copy(color = WhiteText)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Intenta con otras palabras clave o ajusta tus filtros",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                        )
                    }
                }
            } else {
                items(filteredProducts.chunked(2)) { pair ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        for (prod in pair) {
                            Box(modifier = Modifier.weight(1f)) {
                                ProductCard(
                                    product = prod,
                                    isFavorite = favorites.any { it.id == prod.id },
                                    onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                    onAddToCartClick = { viewModel.addToCart(prod.id) },
                                    onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                                )
                            }
                        }
                        if (pair.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            // Standard Full Home Screen with all demanded modules

            // 1. Hero Promo Banner
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFF2E1065),
                                        Color(0xFF581C87),
                                        Color(0xFF0F0A1A)
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = OfficialGold
                                ) {
                                    Text(
                                        text = "CYBER CHILE 2026",
                                        color = Color.Black,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "0% Comisión Tienda Oficial",
                                    color = PurpleGlow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Encuentra lo mejor en tecnología, moda y hogar",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Compra seguro con entrega en todo Chile o retiro directo.",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE9D5FF))
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = {
                                    viewModel.onlyOfficialFilter.value = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.White,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Ver Tienda Oficial", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // QR Delivery & Return System Hub (User Prompt Requirement 5)
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = PurplePrimary.copy(alpha = 0.2f),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.QrCodeScanner,
                                            contentDescription = null,
                                            tint = PurpleGlow,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Entrega y Devolución QR",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = WhiteText
                                        )
                                    )
                                    Text(
                                        text = "Validación segura con código único de 1 solo uso",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = TextMuted,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF065F46)
                            ) {
                                Text(
                                    text = "ACTIVO",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onNavigate(Screen.MyQrCode("ord_seed_1")) },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_my_qr_button")
                            ) {
                                Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Mi Código QR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onNavigate(Screen.QrScanner) },
                                colors = ButtonDefaults.buttonColors(containerColor = BlackSurfaceVariant),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, BorderDark),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("home_scan_qr_button")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = PurpleGlow, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Escanear QR", color = WhiteText, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onNavigate(Screen.QrAuditHistory) },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, BorderDark),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("home_history_qr_button")
                            ) {
                                Icon(Icons.Default.History, contentDescription = "Historial", tint = TextMuted, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // 2. Categories Horizontal Scroller
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Text(
                        text = "Categorías",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(categories) { cat ->
                            val isSelected = selectedCategory == cat.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                                border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                                modifier = Modifier
                                    .testTag("category_chip_${cat.id}")
                                    .clickable {
                                        viewModel.selectedCategoryFilter.value = if (isSelected) null else cat.id
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Icon(
                                        imageVector = when (cat.id) {
                                            "tech" -> Icons.Default.Computer
                                            "phones" -> Icons.Default.Smartphone
                                            "fashion" -> Icons.Default.Checkroom
                                            "home" -> Icons.Default.Home
                                            "vehicles" -> Icons.Default.DirectionsCar
                                            "sports" -> Icons.Default.FitnessCenter
                                            "beauty" -> Icons.Default.Spa
                                            "food" -> Icons.Default.Restaurant
                                            "real_estate" -> Icons.Default.Apartment
                                            else -> Icons.Default.Build
                                        },
                                        contentDescription = cat.name,
                                        tint = if (isSelected) Color.White else PurpleGlow,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = cat.name,
                                        color = if (isSelected) Color.White else WhiteText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. Tienda Oficial Morenicho Showcase
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Tienda Oficial Morenicho",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            OfficialBadge()
                        }
                    }

                    Text(
                        text = "Productos propios con 0% de comisión y garantía directa.",
                        color = TextMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(officialProducts) { prod ->
                            Box(modifier = Modifier.width(200.dp)) {
                                ProductCard(
                                    product = prod,
                                    isFavorite = favorites.any { it.id == prod.id },
                                    onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                    onAddToCartClick = { viewModel.addToCart(prod.id) },
                                    onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                                )
                            }
                        }
                    }
                }
            }

            // 4. In-Feed Advertising Banner (Monetag / Local Business)
            item {
                val bannerAd = activeAds.firstOrNull { it.placement == "BANNER_TOP" || it.placement == "IN_FEED" }
                if (bannerAd != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .clickable {
                                viewModel.recordAdClick(bannerAd.id)
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(bannerAd.targetUrl))
                                try { context.startActivity(intent) } catch (e: Exception) {}
                            }
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                            ) {
                                AsyncImage(
                                    model = bannerAd.bannerImageUrl,
                                    contentDescription = bannerAd.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color.Black.copy(alpha = 0.75f),
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(6.dp)
                                ) {
                                    Text(
                                        text = "PUBLICIDAD • ${bannerAd.adNetwork}",
                                        color = TextMuted,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = bannerAd.title,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = WhiteText
                                        )
                                    )
                                    Text(
                                        text = "Anunciante: ${bannerAd.advertiserName}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                    )
                                }
                                Button(
                                    onClick = {
                                        viewModel.recordAdClick(bannerAd.id)
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(bannerAd.targetUrl))
                                        try { context.startActivity(intent) } catch (e: Exception) {}
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Ver Anuncio", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 5. Ofertas y Productos Destacados
            item {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "Ofertas y Destacados",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        items(featuredProducts) { prod ->
                            Box(modifier = Modifier.width(200.dp)) {
                                ProductCard(
                                    product = prod,
                                    isFavorite = favorites.any { it.id == prod.id },
                                    onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                    onAddToCartClick = { viewModel.addToCart(prod.id) },
                                    onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                                )
                            }
                        }
                    }
                }
            }

            // 6. Recomendaciones de Afiliados (AliExpress, Amazon, Hotmart)
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Stars,
                                    contentDescription = null,
                                    tint = PurpleGlow,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Recomendaciones de Afiliados",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                            }
                            Text(
                                text = "Ofertas seleccionadas en AliExpress, Amazon y Hotmart",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        TextButton(onClick = { onNavigate(Screen.AffiliateModule) }) {
                            Text("Ver todos", color = PurpleGlow, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Badges row indicating supported platforms
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF97316),
                            shadowElevation = 2.dp
                        ) {
                            Text(
                                text = "AliExpress",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFEAB308),
                            shadowElevation = 2.dp
                        ) {
                            Text(
                                text = "Amazon",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFEF4444),
                            shadowElevation = 2.dp
                        ) {
                            Text(
                                text = "Hotmart",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }

                    AffiliateTransparencyCard()

                    val displayedAffiliates = if (affiliateProducts.isNotEmpty()) {
                        affiliateProducts
                    } else {
                        // Fallback conversion from activeAffiliates
                        activeAffiliates.map { aff ->
                            ProductEntity(
                                id = aff.id,
                                title = aff.name,
                                description = aff.description,
                                price = aff.price,
                                categoryId = aff.categoryId,
                                sellerId = "affiliate_seller",
                                sellerName = aff.platformSource,
                                sellerPhone = "+56987654321",
                                imageUrl = aff.imageUrl,
                                isAffiliate = true,
                                affiliatePlatform = aff.platformSource,
                                affiliateUrl = aff.affiliateUrl
                            )
                        }
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        items(displayedAffiliates) { prod ->
                            Box(modifier = Modifier.width(210.dp)) {
                                ProductCard(
                                    product = prod,
                                    isFavorite = favorites.any { it.id == prod.id },
                                    onProductClick = {
                                        if (prod.isAffiliate && !prod.affiliateUrl.isNullOrBlank()) {
                                            viewModel.recordAffiliateClick(prod.id)
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(prod.affiliateUrl))
                                            try { context.startActivity(intent) } catch (e: Exception) {}
                                        } else {
                                            onNavigate(Screen.ProductDetail(prod.id))
                                        }
                                    },
                                    onAddToCartClick = {
                                        // Affiliate products open external link rather than internal cart
                                        if (!prod.affiliateUrl.isNullOrBlank()) {
                                            viewModel.recordAffiliateClick(prod.id)
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(prod.affiliateUrl))
                                            try { context.startActivity(intent) } catch (e: Exception) {}
                                        }
                                    },
                                    onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                                )
                            }
                        }
                    }
                }
            }

            // 7. Últimos Productos Publicados en el Marketplace
            item {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    Text(
                        text = "Últimos Productos Publicados",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            items(allProducts.chunked(2)) { pair ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    for (prod in pair) {
                        Box(modifier = Modifier.weight(1f)) {
                            ProductCard(
                                product = prod,
                                isFavorite = favorites.any { it.id == prod.id },
                                onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                onAddToCartClick = { viewModel.addToCart(prod.id) },
                                onToggleFavorite = { viewModel.toggleFavorite(prod.id) }
                            )
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }

    // Filter Modal Bottom Sheet
    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            containerColor = BlackSurface,
            dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Filtros de Búsqueda",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Official Store toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Solo Tienda Oficial Morenicho", color = WhiteText, fontWeight = FontWeight.SemiBold)
                        Text("Productos garantizados con 0% comisión", color = TextMuted, fontSize = 12.sp)
                    }
                    Switch(
                        checked = onlyOfficial,
                        onCheckedChange = { viewModel.onlyOfficialFilter.value = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PurplePrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Condition: New or Used
                Text("Condición", color = WhiteText, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ALL" to "Todos", "NEW" to "Nuevo", "USED" to "Usado").forEach { (key, label) ->
                        FilterChip(
                            selected = conditionFilter == key,
                            onClick = { viewModel.conditionFilter.value = key },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PurplePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = BlackSurfaceVariant,
                                labelColor = WhiteText
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Category Selection
                Text("Categoría", color = WhiteText, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat.id,
                            onClick = {
                                viewModel.selectedCategoryFilter.value = if (selectedCategory == cat.id) null else cat.id
                            },
                            label = { Text(cat.name) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PurplePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = BlackSurfaceVariant,
                                labelColor = WhiteText
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Price Filter (Requirement 2)
                Text("Precio Máximo (CLP)", color = WhiteText, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                val priceOptions = listOf<Pair<Int?, String>>(
                    null to "Cualquiera",
                    25000 to "Hasta $25.000",
                    50000 to "Hasta $50.000",
                    100000 to "Hasta $100.000",
                    300000 to "Hasta $300.000",
                    500000 to "Hasta $500.000"
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(priceOptions) { (amount, label) ->
                        FilterChip(
                            selected = maxPriceFilter == amount,
                            onClick = { viewModel.maxPriceFilter.value = amount },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PurplePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = BlackSurfaceVariant,
                                labelColor = WhiteText
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Location Filter (Chile) (Requirement 2)
                Text("Ubicación (Chile)", color = WhiteText, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                val locationOptions = listOf<Pair<String?, String>>(
                    null to "Todo Chile",
                    "Santiago" to "Santiago / RM",
                    "Valparaíso" to "Valparaíso",
                    "Concepción" to "Concepción",
                    "Antofagasta" to "Antofagasta",
                    "La Serena" to "La Serena"
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(locationOptions) { (loc, label) ->
                        FilterChip(
                            selected = locationFilter == loc,
                            onClick = { viewModel.locationFilter.value = loc },
                            label = { Text(label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = PurplePrimary,
                                selectedLabelColor = Color.White,
                                containerColor = BlackSurfaceVariant,
                                labelColor = WhiteText
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            viewModel.clearFilters()
                            showFilterSheet = false
                        },
                        border = BorderStroke(1.dp, BorderDark),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Limpiar", color = TextMuted)
                    }

                    Button(
                        onClick = { showFilterSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(2f)
                    ) {
                        Text("Aplicar Filtros", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}
