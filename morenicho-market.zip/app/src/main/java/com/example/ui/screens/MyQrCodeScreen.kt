package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderEntity
import com.example.data.model.QrSecurityTokenEntity
import com.example.ui.components.QrCodeView
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@Composable
fun MyQrCodeScreen(
    orderId: String,
    initialOperationType: String = "DELIVERY_HANDOFF",
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val allOrders by viewModel.allOrders.collectAsState()
    val allTokens by viewModel.allQrTokens.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var selectedOrderId by remember { mutableStateOf(orderId.ifBlank { allOrders.firstOrNull()?.id ?: "ord_seed_1" }) }
    var selectedOpType by remember { mutableStateOf(initialOperationType) }

    val currentOrder = allOrders.find { it.id == selectedOrderId }
    val orderTokens = allTokens.filter { it.orderId == selectedOrderId }
    val activeToken = orderTokens.find { it.operationType == selectedOpType } ?: orderTokens.firstOrNull()

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mi Código QR Seguro",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    IconButton(onClick = { onNavigate(Screen.QrScanner) }) {
                        Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Escanear", tint = PurpleGlow)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Order Selection Row if multiple exist
            if (allOrders.size > 1) {
                item {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Seleccionar Pedido:",
                            color = TextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(allOrders) { ord ->
                                val isSelected = ord.id == selectedOrderId
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                                    border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                                    modifier = Modifier.clickable { selectedOrderId = ord.id }
                                ) {
                                    Text(
                                        text = ord.orderNumber,
                                        color = if (isSelected) Color.White else TextMuted,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Operation Type Tabs (Entrega, Recogida, Devolución - Requirement 1)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "DELIVERY_HANDOFF" to "1. Entrega",
                        "RETURN_PICKUP" to "2. Recogida",
                        "RETURN_RECEIVE" to "3. Devolución"
                    ).forEach { (type, label) ->
                        val isSelected = selectedOpType == type
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                            border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedOpType = type }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color.White else TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Order Context Card
            if (currentOrder != null) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurface),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Orden #${currentOrder.orderNumber}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                                Text(
                                    text = "Destino: ${currentOrder.buyerCity}, Chile",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = CurrencyFormatter.formatShortCLP(currentOrder.totalAmount),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = SuccessGreen,
                                        fontWeight = FontWeight.Black
                                    )
                                )
                                Text(
                                    text = "Estado: ${currentOrder.status}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = PurpleGlow)
                                )
                            }
                        }
                    }
                }
            }

            // The QR Code View
            if (activeToken != null) {
                item {
                    QrCodeView(
                        token = activeToken,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Quick Action Buttons
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("OTP Code", activeToken.otpCode)
                                clipboard.setPrimaryClip(clip)
                                viewModel.showToast("Código OTP ${activeToken.otpCode} copiado")
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = OfficialGold),
                            border = BorderStroke(1.dp, OfficialGold),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copiar OTP", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onNavigate(Screen.QrScanner) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_scanner_button")
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Abrir Escáner", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurface),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.QrCode2, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No se encontró token QR para esta etapa", color = WhiteText, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("El token para esta operación será emitido automáticamente al solicitar la devolución.", color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Instructions Box
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Instrucciones de Seguridad:",
                            color = WhiteText,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "1. Muestra este código en pantalla completa al repartidor al momento de recibir el paquete.\n2. Si el escáner tiene problemas de luz, dicta el código OTP de 6 dígitos.\n3. Una vez escaneado y confirmada la fotografía de entrega, el código queda invalidado automáticamente.",
                            color = TextMuted,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
