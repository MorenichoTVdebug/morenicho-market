package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ProductEntity
import com.example.ui.components.AffiliatePlatformBadge
import com.example.ui.components.AffiliateTransparencyCard
import com.example.ui.components.OfficialBadge
import com.example.ui.components.WhatsAppContactButton
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@Composable
fun ProductDetailScreen(
    productId: String,
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val allProducts by viewModel.allProducts.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val favorites by viewModel.favorites.collectAsState()

    val product = allProducts.find { it.id == productId }

    LaunchedEffect(productId) {
        viewModel.repository.incrementProductViews(productId)
    }

    if (product == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Producto no encontrado", color = WhiteText)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onBack) { Text("Volver") }
            }
        }
        return
    }

    val isFav = favorites.any { it.id == product.id }

    Scaffold(
        bottomBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 8.dp,
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                if (product.isAffiliate) {
                    val platformColor = when (product.affiliatePlatform?.trim()?.lowercase()) {
                        "aliexpress" -> Color(0xFFF97316)
                        "amazon" -> Color(0xFFEAB308)
                        "hotmart" -> Color(0xFFEF4444)
                        else -> PurplePrimary
                    }
                    val btnTextColor = if (product.affiliatePlatform?.trim()?.equals("amazon", ignoreCase = true) == true) Color.Black else Color.White

                    Box(modifier = Modifier.padding(16.dp)) {
                        Button(
                            onClick = {
                                if (!product.affiliateUrl.isNullOrBlank()) {
                                    viewModel.recordAffiliateClick(product.id)
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(product.affiliateUrl))
                                    try { context.startActivity(intent) } catch (e: Exception) {}
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = platformColor,
                                contentColor = btnTextColor
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("detail_affiliate_buy")
                        ) {
                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Comprar en ${product.affiliatePlatform ?: "Sitio Externo"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel.addToCart(product.id)
                            },
                            enabled = !product.isSoldOut && product.stock > 0,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = PurpleLight
                            ),
                            border = BorderStroke(1.dp, PurpleLight),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("detail_add_to_cart")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddShoppingCart,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Al Carrito", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                viewModel.addToCart(product.id)
                                onNavigate(Screen.Cart)
                            },
                            enabled = !product.isSoldOut && product.stock > 0,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PurplePrimary,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("detail_buy_now")
                        ) {
                            Text("Comprar Ahora", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .verticalScroll(rememberScrollState())
                .padding(padding)
        ) {
            // Main Product Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Favorite and Back Buttons overlay
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleFavorite(product.id) },
                        modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorito",
                            tint = if (isFav) Color(0xFFEF4444) else Color.White
                        )
                    }
                }

                if (product.isSoldOut || product.stock == 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.7f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFDC2626)
                        ) {
                            Text(
                                text = "PRODUCTO AGOTADO",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                // Badges Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (product.isOfficial) {
                        OfficialBadge()
                    }
                    if (product.isAffiliate) {
                        AffiliatePlatformBadge(product.affiliatePlatform ?: "Afiliado")
                    } else {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = BlackSurfaceVariant
                        ) {
                            Text(
                                text = if (product.condition == "NEW") "Nuevo" else "Usado",
                                color = WhiteText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (product.isAffiliate) Color(0xFF1E293B) else if (product.stock > 3) Color(0xFF065F46) else Color(0xFF991B1B)
                    ) {
                        Text(
                            text = if (product.isAffiliate) "Enlace Externo Oficial" else "Stock: ${product.stock} un.",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Title
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Price and Discount
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = CurrencyFormatter.formatCLP(product.price),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = SuccessGreen
                        )
                    )
                    if (product.originalPrice != null && product.originalPrice > product.price) {
                        Text(
                            text = CurrencyFormatter.formatShortCLP(product.originalPrice),
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextMuted,
                                textDecoration = TextDecoration.LineThrough
                            )
                        )
                    }
                }

                if (product.isAffiliate) {
                    Spacer(modifier = Modifier.height(12.dp))
                    AffiliateTransparencyCard()
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Location & Seller info card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storefront,
                                contentDescription = null,
                                tint = PurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = product.sellerName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                                Text(
                                    text = "${product.locationCity}, ${product.locationRegion}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        WhatsAppContactButton(
                            phoneNumber = product.sellerPhone,
                            message = "Hola, vi tu publicación en Morenicho Market: '${product.title}' por ${CurrencyFormatter.formatCLP(product.price)}. ¿Está disponible?",
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Share as Recommender Card (2% reward)
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Recomendar",
                            tint = OfficialGold,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "¡Gana 2% recomendando este producto!",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )
                            )
                            Text(
                                text = "Comparte tu código: ${currentUser.referralCode} y recibe comisión en tu billetera cuando compren.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                            )
                        }
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Morenicho Link", "https://morenicho.market/p/${product.id}?ref=${currentUser.referralCode}")
                                clipboard.setPrimaryClip(clip)
                                viewModel.showToast("Enlace de recomendador copiado con tu código ${currentUser.referralCode}")
                            }
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copiar", tint = PurpleGlow)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Commission breakdown transparency box
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = SuccessGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Regla de Distribución Morenicho",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (product.isOfficial) {
                                "• Producto de Tienda Oficial: 0% comisión de plataforma (100% oficial)."
                            } else {
                                "• Con recomendador: 5% plataforma, 2% recomendador, 93% vendedor.\n• Sin recomendador: 7% plataforma, 93% vendedor."
                            },
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Description
                Text(
                    text = "Descripción",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = product.description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFFD1D5DB),
                        lineHeight = 22.sp
                    )
                )

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
