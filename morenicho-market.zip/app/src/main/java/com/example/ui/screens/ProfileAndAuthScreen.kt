package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserEntity
import com.example.ui.components.WhatsAppContactButton
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileAndAuthScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val userOrders by viewModel.userOrders.collectAsState()
    val favorites by viewModel.favorites.collectAsState()
    val sellerProducts by viewModel.currentSellerProducts.collectAsState()
    val sellerSales by viewModel.sellerSales.collectAsState()

    var showAuthModal by remember { mutableStateOf(false) }
    var showRecoverPasswordModal by remember { mutableStateOf(false) }
    var showOrdersModal by remember { mutableStateOf(false) }
    var showFavoritesModal by remember { mutableStateOf(false) }
    var showSellerProductsModal by remember { mutableStateOf(false) }
    var showSellerSalesModal by remember { mutableStateOf(false) }
    var showNotificationsModal by remember { mutableStateOf(false) }
    var showRoleSwitchDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mi Cuenta y Perfil",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    FilledTonalButton(
                        onClick = { showRoleSwitchDialog = true },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = BlackSurfaceVariant,
                            contentColor = PurpleGlow
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cambiar Rol", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Header Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = PurplePrimary,
                                modifier = Modifier.size(60.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = currentUser.name.take(2).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 20.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column {
                                Text(
                                    text = currentUser.name,
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = WhiteText
                                    )
                                )
                                Text(
                                    text = currentUser.email,
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (currentUser.role) {
                                        "ADMIN" -> Color(0xFFEF4444)
                                        "SELLER" -> PurpleLight
                                        "AFFILIATE" -> OfficialGold
                                        else -> InfoBlue
                                    }
                                ) {
                                    Text(
                                        text = "ROL: ${currentUser.role}",
                                        color = if (currentUser.role == "AFFILIATE") Color.Black else Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Divider(color = BorderDark)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Ubicación:", color = TextMuted, fontSize = 11.sp)
                                Text("${currentUser.city}, Chile", color = WhiteText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Teléfono / WhatsApp:", color = TextMuted, fontSize = 11.sp)
                                Text(currentUser.phone, color = WhiteText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }

            // Programa de Recomendadores (Requirement 9)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, OfficialGold.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Celebration, contentDescription = null, tint = OfficialGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Tu Código de Recomendador Personal",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = WhiteText
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Ganas el 2% de cada venta generada con tu código de recomendador. El saldo se acredita automáticamente en tu Billetera.",
                            color = TextMuted,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BlackSurfaceVariant,
                            border = BorderStroke(1.dp, BorderDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Código Único:", color = TextMuted, fontSize = 10.sp)
                                    Text(
                                        text = currentUser.referralCode,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = OfficialGold,
                                            fontWeight = FontWeight.Black,
                                            letterSpacing = 1.sp
                                        )
                                    )
                                }

                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Morenicho Link", "https://morenicho.market/?ref=${currentUser.referralCode}")
                                        clipboard.setPrimaryClip(clip)
                                        viewModel.showToast("¡Enlace copiado con tu código ${currentUser.referralCode}!")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Copiar Enlace", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Quick Navigation Shortcuts
            item {
                Text("Mis Actividades", style = MaterialTheme.typography.titleMedium.copy(color = WhiteText, fontWeight = FontWeight.Bold))
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("Historial de Compras", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("${userOrders.size} pedidos realizados", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = PurpleLight) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { showOrdersModal = true }
                        )

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Mis Favoritos", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("${favorites.size} productos guardados", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.Favorite, contentDescription = null, tint = Color(0xFFEF4444)) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { showFavoritesModal = true }
                        )

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Mis Ganancias & Billetera", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Consultar saldos, movimientos y retiros", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = SuccessGreen) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onNavigate(Screen.WalletFinance) }
                        )

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Mi Código QR de Entrega", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Muestra el código al repartidor para recibir tu pedido", color = PurpleGlow, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.QrCode, contentDescription = null, tint = PurpleLight) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onNavigate(Screen.MyQrCode("ord_seed_1")) }
                        )

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Escanear Código QR", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Cámara móvil para confirmar entrega o recogida", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.CameraAlt, contentDescription = null, tint = OfficialGold) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onNavigate(Screen.QrScanner) }
                        )

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Historial de Auditoría QR", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Registro inmutable de entregas y devoluciones", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.History, contentDescription = null, tint = InfoBlue) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { onNavigate(Screen.QrAuditHistory) }
                        )

                        if (currentUser.role == "SELLER" || currentUser.role == "ADMIN") {
                            Divider(color = BorderDark)

                            ListItem(
                                headlineContent = { Text("Mis Publicaciones de Vendedor", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text("${sellerProducts.size} productos publicados • Gestionar stock", color = OfficialGold, fontSize = 12.sp) },
                                leadingContent = { Icon(Icons.Default.Storefront, contentDescription = null, tint = OfficialGold) },
                                trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable { showSellerProductsModal = true }
                            )

                            Divider(color = BorderDark)

                            ListItem(
                                headlineContent = { Text("Mis Ventas Realizadas (93%)", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                                supportingContent = { Text("${sellerSales.size} ventas liquidadas en billetera", color = SuccessGreen, fontSize = 12.sp) },
                                leadingContent = { Icon(Icons.Default.Paid, contentDescription = null, tint = SuccessGreen) },
                                trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable { showSellerSalesModal = true }
                            )
                        }

                        Divider(color = BorderDark)

                        ListItem(
                            headlineContent = { Text("Notificaciones del Sistema", color = WhiteText, fontWeight = FontWeight.SemiBold) },
                            supportingContent = { Text("Avisos de pedidos, entregas QR y comisiones", color = TextMuted, fontSize = 12.sp) },
                            leadingContent = { Icon(Icons.Default.Notifications, contentDescription = null, tint = PurpleLight) },
                            trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            modifier = Modifier.clickable { showNotificationsModal = true }
                        )

                        if (currentUser.role == "ADMIN") {
                            Divider(color = BorderDark)

                            ListItem(
                                headlineContent = { Text("Panel Administrativo Morenicho", color = WhiteText, fontWeight = FontWeight.Bold) },
                                supportingContent = { Text("Gestión de productos, comisiones, publicidad y retiros", color = Color(0xFFEF4444), fontSize = 12.sp) },
                                leadingContent = { Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color(0xFFEF4444)) },
                                trailingContent = { Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clickable { onNavigate(Screen.AdminPanel) }
                            )
                        }
                    }
                }
            }

            // WhatsApp Support & Security
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Soporte Oficial Morenicho Market", color = WhiteText, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Atención en Chile para consultas sobre compras, ventas o pasarelas de pago.", color = TextMuted, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        WhatsAppContactButton(
                            phoneNumber = "+56987654321",
                            message = "Hola equipo de Morenicho Market, necesito soporte con mi cuenta ${currentUser.email}.",
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Auth Actions (Supabase Auth: Login / Register)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Supabase Auth Oficial", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Registro e inicio de sesión para Compradores y Vendedores conectado a Supabase.",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { onNavigate(Screen.Auth) },
                                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.AppRegistration, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Registrarse", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = { onNavigate(Screen.Auth) },
                                border = BorderStroke(1.dp, PurpleLight),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Login, contentDescription = null, modifier = Modifier.size(16.dp), tint = PurpleLight)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Iniciar Sesión", fontSize = 12.sp, color = WhiteText)
                            }
                        }
                    }
                }
            }
        }
    }

    // Role Switcher Modal (to test all 4 personas easily)
    if (showRoleSwitchDialog) {
        AlertDialog(
            onDismissRequest = { showRoleSwitchDialog = false },
            title = { Text("Seleccionar Usuario de Prueba", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    allUsers.forEach { user ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (currentUser.id == user.id) PurplePrimary else BlackSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.switchUser(user)
                                    showRoleSwitchDialog = false
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(user.name, color = WhiteText, fontWeight = FontWeight.Bold)
                                Text("Rol: ${user.role} • ${user.email}", color = if (currentUser.id == user.id) Color(0xFFE9D5FF) else TextMuted, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showRoleSwitchDialog = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }

    // Password Recovery Modal
    if (showRecoverPasswordModal) {
        var emailInput by remember { mutableStateOf(currentUser.email) }
        AlertDialog(
            onDismissRequest = { showRecoverPasswordModal = false },
            title = { Text("Recuperar Contraseña", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Ingresa tu correo registrado para recibir el enlace seguro de restablecimiento de contraseña.", color = TextMuted, fontSize = 12.sp)
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = { emailInput = it },
                        label = { Text("Correo Electrónico") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.showToast("Instrucciones de recuperación enviadas a $emailInput")
                        showRecoverPasswordModal = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("Enviar Enlace")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRecoverPasswordModal = false }) { Text("Cancelar") }
            },
            containerColor = BlackSurface
        )
    }

    // Order History Modal
    if (showOrdersModal) {
        AlertDialog(
            onDismissRequest = { showOrdersModal = false },
            title = { Text("Historial de Compras (${userOrders.size})", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                if (userOrders.isEmpty()) {
                    Text("Aún no tienes pedidos registrados.", color = TextMuted)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(userOrders) { ord ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(ord.orderNumber, color = PurpleGlow, fontWeight = FontWeight.Bold)
                                        Text(CurrencyFormatter.formatCLP(ord.totalAmount), color = SuccessGreen, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Estado: ${ord.status} • Pago: ${ord.paymentMethod}", color = TextMuted, fontSize = 11.sp)
                                    Text("Despacho: ${ord.buyerAddress}, ${ord.buyerCity}", color = TextMuted, fontSize = 11.sp)

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                showOrdersModal = false
                                                onNavigate(Screen.MyQrCode(ord.id, "DELIVERY_HANDOFF"))
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("QR Entrega", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                showOrdersModal = false
                                                onNavigate(Screen.MyQrCode(ord.id, "RETURN_PICKUP"))
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.AssignmentReturned, contentDescription = null, tint = OfficialGold, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Devolución QR", color = WhiteText, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showOrdersModal = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }

    // Favorites Modal
    if (showFavoritesModal) {
        AlertDialog(
            onDismissRequest = { showFavoritesModal = false },
            title = { Text("Mis Favoritos (${favorites.size})", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                if (favorites.isEmpty()) {
                    Text("No tienes productos en favoritos.", color = TextMuted)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(favorites) { prod ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                                modifier = Modifier.clickable {
                                    showFavoritesModal = false
                                    onNavigate(Screen.ProductDetail(prod.id))
                                }
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(prod.title, color = WhiteText, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Text(CurrencyFormatter.formatCLP(prod.price), color = SuccessGreen, fontSize = 12.sp)
                                    }
                                    IconButton(onClick = { viewModel.toggleFavorite(prod.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = ErrorRed)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFavoritesModal = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }

    // Auth / Registration Modal
    if (showAuthModal) {
        var authMode by remember { mutableStateOf("LOGIN") } // LOGIN or REGISTER
        var nameInput by remember { mutableStateOf("") }
        var emailInput by remember { mutableStateOf("") }
        var phoneInput by remember { mutableStateOf("+56 9 ") }
        var roleSelected by remember { mutableStateOf("BUYER") }

        AlertDialog(
            onDismissRequest = { showAuthModal = false },
            title = {
                Text(
                    if (authMode == "LOGIN") "Iniciar Sesión en Morenicho" else "Crear Cuenta Nueva",
                    color = WhiteText,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (authMode == "REGISTER") {
                        OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Nombre Completo") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = phoneInput, onValueChange = { phoneInput = it }, label = { Text("Teléfono / WhatsApp") }, modifier = Modifier.fillMaxWidth())
                        Text("Rol en la Plataforma", color = WhiteText, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("BUYER" to "Comprador", "SELLER" to "Vendedor", "AFFILIATE" to "Recomendador").forEach { (r, l) ->
                                FilterChip(
                                    selected = roleSelected == r,
                                    onClick = { roleSelected = r },
                                    label = { Text(l) }
                                )
                            }
                        }
                    }
                    OutlinedTextField(value = emailInput, onValueChange = { emailInput = it }, label = { Text("Correo Electrónico") }, modifier = Modifier.fillMaxWidth())

                    TextButton(
                        onClick = { authMode = if (authMode == "LOGIN") "REGISTER" else "LOGIN" }
                    ) {
                        Text(
                            if (authMode == "LOGIN") "¿No tienes cuenta? Regístrate aquí" else "¿Ya tienes cuenta? Inicia sesión",
                            color = PurpleGlow,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (emailInput.isNotBlank()) {
                            viewModel.showToast(if (authMode == "LOGIN") "Sesión iniciada como $emailInput" else "Cuenta registrada exitosamente")
                            showAuthModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text(if (authMode == "LOGIN") "Entrar" else "Crear Cuenta")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAuthModal = false }) { Text("Cancelar") }
            },
            containerColor = BlackSurface
        )
    }

    // Modal: Mis Publicaciones de Vendedor (Requirement 4 & 5)
    if (showSellerProductsModal) {
        AlertDialog(
            onDismissRequest = { showSellerProductsModal = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mis Publicaciones (${sellerProducts.size})", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(
                        onClick = {
                            showSellerProductsModal = false
                            onNavigate(Screen.PublishProduct)
                        }
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Publicar", tint = OfficialGold)
                    }
                }
            },
            text = {
                if (sellerProducts.isEmpty()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No tienes productos publicados actualmente.", color = TextMuted, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                showSellerProductsModal = false
                                onNavigate(Screen.PublishProduct)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OfficialGold, contentColor = Color.Black)
                        ) {
                            Text("Publicar mi primer producto", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 420.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(sellerProducts) { prod ->
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                                border = BorderStroke(1.dp, if (prod.isSoldOut) ErrorRed.copy(alpha = 0.5f) else BorderDark)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(prod.title, color = WhiteText, fontWeight = FontWeight.Bold, maxLines = 1)
                                            Text(
                                                "${CurrencyFormatter.formatCLP(prod.price)} • Stock: ${prod.stock} un.",
                                                color = SuccessGreen,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (prod.isSoldOut) ErrorRed.copy(alpha = 0.2f) else SuccessGreen.copy(alpha = 0.2f),
                                            border = BorderStroke(1.dp, if (prod.isSoldOut) ErrorRed else SuccessGreen)
                                        ) {
                                            Text(
                                                text = if (prod.isSoldOut) "AGOTADO" else "DISPONIBLE",
                                                color = if (prod.isSoldOut) ErrorRed else SuccessGreen,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Divider(color = BorderDark)
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextButton(
                                            onClick = { viewModel.toggleSoldOut(prod.id, prod.isSoldOut) },
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (prod.isSoldOut) "Reactivar Producto" else "Marcar Agotado",
                                                color = if (prod.isSoldOut) SuccessGreen else TextMuted,
                                                fontSize = 11.sp
                                            )
                                        }

                                        IconButton(
                                            onClick = { viewModel.deleteProduct(prod) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Eliminar", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSellerProductsModal = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }

    // Modal: Historial de Ventas (Requirement 3 & 8)
    if (showSellerSalesModal) {
        AlertDialog(
            onDismissRequest = { showSellerSalesModal = false },
            title = { Text("Mis Ventas Realizadas (${sellerSales.size})", color = WhiteText, fontWeight = FontWeight.Bold) },
            text = {
                if (sellerSales.isEmpty()) {
                    Text("No registras ventas aún. Comparte tus publicaciones para generar pedidos.", color = TextMuted)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(sellerSales) { sale ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Venta #${sale.id.take(8).uppercase()}", color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text("Liquidado: 93%", color = SuccessGreen, fontWeight = FontWeight.Black, fontSize = 11.sp)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("Base de venta: ${CurrencyFormatter.formatCLP(sale.totalBaseAmount)}", color = TextMuted, fontSize = 11.sp)
                                    Text("Pago a vendedor (93%): ${CurrencyFormatter.formatCLP(sale.sellerAmount)}", color = OfficialGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Comisión Morenicho: ${CurrencyFormatter.formatCLP(sale.platformAmount)} (${sale.platformPercent}%)", color = TextMuted, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSellerSalesModal = false }) { Text("Cerrar") }
            },
            containerColor = BlackSurface
        )
    }

    // Modal: Notificaciones del Sistema (Requirement 3)
    if (showNotificationsModal) {
        AlertDialog(
            onDismissRequest = { showNotificationsModal = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = PurpleLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Notificaciones Morenicho", color = WhiteText, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                val notificationsList = listOf(
                    Triple(
                        "Bienvenido a Morenicho Market",
                        "Tu cuenta está activa en Chile. Puedes comprar y vender con comisiones transparentes del 93%.",
                        "Hoy"
                    ),
                    Triple(
                        "Autenticación Supabase Conectada",
                        "Producción configurada en https://kpygbsbkhjtcuvojirke.supabase.co.",
                        "En vivo"
                    ),
                    Triple(
                        "Sistema QR de Entrega Activo",
                        "Cada orden genera un token temporal de 48h con clave OTP de respaldo para proteger tu compra.",
                        "Activo"
                    ),
                    Triple(
                        "Billetera y Retiros Bancarios",
                        "Transfiere tus ganancias a cuentas RUT y cuentas corrientes de cualquier banco chileno.",
                        "Disponible"
                    )
                )

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(notificationsList) { (title, desc, time) ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(title, color = WhiteText, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(time, color = PurpleGlow, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNotificationsModal = false }) { Text("Entendido") }
            },
            containerColor = BlackSurface
        )
    }
}

