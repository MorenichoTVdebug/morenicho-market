package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishProductScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val currentUser by viewModel.currentUser.collectAsState()
    val categories by viewModel.categories.collectAsState()

    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var originalPriceText by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf("tech") }
    var condition by remember { mutableStateOf("NEW") } // NEW or USED
    var stockText by remember { mutableStateOf("5") }
    var city by remember { mutableStateOf(currentUser.city) }
    var region by remember { mutableStateOf(currentUser.region) }
    var imageUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80") }
    var isOfficial by remember { mutableStateOf(currentUser.role == "ADMIN" || currentUser.id == "usr_oficial") }

    val presetImages = listOf(
        "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80" to "Reloj Smart",
        "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&auto=format&fit=crop&q=80" to "Audífonos",
        "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=80" to "Notebook",
        "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&auto=format&fit=crop&q=80" to "Celular",
        "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=600&auto=format&fit=crop&q=80" to "Ropa",
        "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=600&auto=format&fit=crop&q=80" to "Café Gourmet",
        "https://images.unsplash.com/photo-1485965120184-e220f721d03e?w=600&auto=format&fit=crop&q=80" to "Bicicleta",
        "https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80" to "Hogar"
    )

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Publicar Producto en Morenicho",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = WhiteText
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .verticalScroll(rememberScrollState())
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Seller Info Notice
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                border = BorderStroke(1.dp, BorderDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Storefront, contentDescription = null, tint = PurpleLight)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Publicando como: ${currentUser.name}",
                            style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = if (currentUser.role == "ADMIN") "Permisos de Administrador activados" else "Vendedor verificado en Morenicho Market Chile",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                        )
                    }
                }
            }

            // Official Store option for Admin
            if (currentUser.role == "ADMIN" || currentUser.id == "usr_oficial") {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = OfficialGoldContainer),
                    border = BorderStroke(1.dp, OfficialGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Tienda Oficial Morenicho", color = OfficialGold, fontWeight = FontWeight.Bold)
                            Text("Comisión de plataforma del 0% para productos propios", color = WhiteText, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isOfficial,
                            onCheckedChange = { isOfficial = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = OfficialGold,
                                checkedTrackColor = Color(0xFF78350F)
                            )
                        )
                    }
                }
            }

            // Title & Description
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Título del Producto *") },
                placeholder = { Text("Ej: Notebook Gamer ASUS ROG Strix 16GB") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurplePrimary,
                    unfocusedBorderColor = BorderDark,
                    focusedTextColor = WhiteText,
                    unfocusedTextColor = WhiteText
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("publish_title_input")
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descripción Detallada *") },
                placeholder = { Text("Describe el estado, accesorios incluidos, especificaciones y garantía...") },
                minLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurplePrimary,
                    unfocusedBorderColor = BorderDark,
                    focusedTextColor = WhiteText,
                    unfocusedTextColor = WhiteText
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Price & Original Price (CLP)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { char -> char.isDigit() } },
                    label = { Text("Precio en CLP *") },
                    placeholder = { Text("Ej: 45990") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("publish_price_input")
                )

                OutlinedTextField(
                    value = originalPriceText,
                    onValueChange = { originalPriceText = it.filter { char -> char.isDigit() } },
                    label = { Text("Precio Original (Opcional)") },
                    placeholder = { Text("Para oferta") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
            }

            // Category & Condition
            Text("Categoría", color = WhiteText, fontWeight = FontWeight.SemiBold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryId == cat.id,
                        onClick = { selectedCategoryId = cat.id },
                        label = { Text(cat.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurplePrimary,
                            selectedLabelColor = Color.White,
                            containerColor = BlackSurfaceVariant,
                            labelColor = WhiteText
                        )
                    )
                }
            }

            Text("Condición", color = WhiteText, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("NEW" to "Nuevo", "USED" to "Usado").forEach { (key, label) ->
                    FilterChip(
                        selected = condition == key,
                        onClick = { condition = key },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PurplePrimary,
                            selectedLabelColor = Color.White,
                            containerColor = BlackSurfaceVariant,
                            labelColor = WhiteText
                        )
                    )
                }
            }

            // Stock & Location
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = stockText,
                    onValueChange = { stockText = it.filter { char -> char.isDigit() } },
                    label = { Text("Stock Disponible") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    label = { Text("Comuna / Ciudad") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PurplePrimary,
                        unfocusedBorderColor = BorderDark,
                        focusedTextColor = WhiteText,
                        unfocusedTextColor = WhiteText
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                )
            }

            // Image selection & URL
            Text("Fotografía del Producto", color = WhiteText, fontWeight = FontWeight.SemiBold)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(BlackSurfaceVariant)
            ) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = "Vista previa",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Text("O escoge una foto de catálogo rápida:", color = TextMuted, fontSize = 12.sp)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presetImages) { (url, label) ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (imageUrl == url) PurplePrimary else BlackSurfaceVariant,
                        border = BorderStroke(1.dp, if (imageUrl == url) PurpleLight else BorderDark),
                        modifier = Modifier
                            .clickable { imageUrl = url }
                            .padding(2.dp)
                    ) {
                        Text(
                            text = label,
                            color = WhiteText,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            OutlinedTextField(
                value = imageUrl,
                onValueChange = { imageUrl = it },
                label = { Text("O ingresa URL de imagen personalizada") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PurplePrimary,
                    unfocusedBorderColor = BorderDark,
                    focusedTextColor = WhiteText,
                    unfocusedTextColor = WhiteText
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    val price = priceText.toIntOrNull() ?: 0
                    val originalPrice = originalPriceText.toIntOrNull()
                    val stock = stockText.toIntOrNull() ?: 1
                    if (title.isBlank()) {
                        viewModel.showToast("Por favor ingresa un título")
                        return@Button
                    }
                    if (price <= 0) {
                        viewModel.showToast("Ingresa un precio válido en CLP")
                        return@Button
                    }

                    viewModel.publishProduct(
                        title = title,
                        description = description,
                        price = price,
                        originalPrice = originalPrice,
                        categoryId = selectedCategoryId,
                        condition = condition,
                        stock = stock,
                        city = city,
                        region = region,
                        imageUrl = imageUrl,
                        isOfficial = isOfficial
                    ) {
                        onNavigate(Screen.Home)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_product_button")
            ) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publicar en Morenicho Market", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
