package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.QrAuditLogEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun QrAuditHistoryScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val allAuditLogs by viewModel.allAuditLogs.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var filterType by remember { mutableStateOf("ALL") } // ALL, DELIVERY_HANDOFF, RETURN_PICKUP, RETURN_RECEIVE, REJECTED

    val filteredLogs = allAuditLogs.filter { log ->
        when (filterType) {
            "DELIVERY_HANDOFF" -> log.operationType == "DELIVERY_HANDOFF"
            "RETURN_PICKUP" -> log.operationType == "RETURN_PICKUP"
            "RETURN_RECEIVE" -> log.operationType == "RETURN_RECEIVE"
            "REJECTED" -> log.status != "SUCCESS"
            else -> true
        }
    }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Historial de Auditoría QR",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    IconButton(onClick = { onNavigate(Screen.QrScanner) }) {
                        Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Escanear", tint = PurpleGlow)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Security Governance Banner
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Auditoría de Custodia Morenicho",
                                style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Registro inmutable de entregas, recogidas y devoluciones. Valida la transferencia física sin autorizar pagos o reembolsos automáticos.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp, lineHeight = 15.sp)
                            )
                        }
                    }
                }
            }

            // Filter Chips Row
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "ALL" to "Todos (${allAuditLogs.size})",
                        "DELIVERY_HANDOFF" to "Entregas",
                        "RETURN_PICKUP" to "Recogidas",
                        "RETURN_RECEIVE" to "Devoluciones",
                        "REJECTED" to "Rechazados"
                    ).forEach { (key, label) ->
                        val isSelected = filterType == key
                        item {
                            FilterChip(
                                selected = isSelected,
                                onClick = { filterType = key },
                                label = { Text(label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurplePrimary,
                                    selectedLabelColor = Color.White,
                                    containerColor = BlackSurface,
                                    labelColor = TextMuted
                                )
                            )
                        }
                    }
                }
            }

            if (filteredLogs.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.History, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No hay registros en esta categoría", color = TextMuted)
                        }
                    }
                }
            } else {
                items(filteredLogs) { log ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackCard),
                        border = BorderStroke(
                            1.dp,
                            if (log.status == "SUCCESS") BorderDark else ErrorRed.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("audit_item_${log.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Header Row: Operation and Status Pill
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when (log.operationType) {
                                            "DELIVERY_HANDOFF" -> Icons.Default.CheckCircle
                                            "RETURN_PICKUP" -> Icons.Default.LocalShipping
                                            "RETURN_RECEIVE" -> Icons.Default.AssignmentReturned
                                            else -> Icons.Default.QrCode
                                        },
                                        contentDescription = null,
                                        tint = when (log.operationType) {
                                            "DELIVERY_HANDOFF" -> SuccessGreen
                                            "RETURN_PICKUP" -> Color(0xFFF59E0B)
                                            "RETURN_RECEIVE" -> InfoBlue
                                            else -> PurpleLight
                                        },
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = when (log.operationType) {
                                            "DELIVERY_HANDOFF" -> "ENTREGA DE PEDIDO"
                                            "RETURN_PICKUP" -> "RECOGIDA DE DEVOLUCIÓN"
                                            "RETURN_RECEIVE" -> "RECEPCIÓN EN VENDEDOR"
                                            else -> log.operationType
                                        },
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            color = WhiteText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (log.status) {
                                        "SUCCESS" -> Color(0xFF065F46)
                                        "REJECTED_ALREADY_USED" -> Color(0xFF7F1D1D)
                                        "REJECTED_EXPIRED" -> Color(0xFF4B5563)
                                        else -> Color(0xFF991B1B)
                                    }
                                ) {
                                    Text(
                                        text = when (log.status) {
                                            "SUCCESS" -> "EXITOSO"
                                            "REJECTED_ALREADY_USED" -> "YA USADO"
                                            "REJECTED_EXPIRED" -> "EXPIRADO"
                                            "REJECTED_UNAUTHORIZED" -> "NO AUTORIZADO"
                                            else -> log.status
                                        },
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Message
                            Text(
                                text = log.message,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = if (log.status == "SUCCESS") Color(0xFFD1D5DB) else Color(0xFFFCA5A5),
                                    fontSize = 12.sp
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Proof photo thumbnail if attached
                            if (log.proofPhotoUrl.isNotBlank()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    AsyncImage(
                                        model = log.proofPhotoUrl,
                                        contentDescription = "Comprobante",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text("Fotografía de Comprobante:", color = TextMuted, fontSize = 10.sp)
                                        Text("Adjunta y verificada por el sistema", color = PurpleGlow, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                            }

                            Divider(color = BorderDark)

                            Spacer(modifier = Modifier.height(8.dp))

                            // Metadata footer
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Orden: #${log.orderNumber}",
                                        color = WhiteText,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "Operador: ${log.actorName} (${log.actorRole})",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("es", "CL")).format(Date(log.timestamp))
                                    Text(
                                        text = dateStr,
                                        color = TextMuted,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Text(
                                        text = log.location,
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
