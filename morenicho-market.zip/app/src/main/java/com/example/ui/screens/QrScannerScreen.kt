package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.model.QrSecurityTokenEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrScannerScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val allTokens by viewModel.allQrTokens.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (!isGranted) {
            viewModel.showToast("Permiso de cámara denegado. Puedes usar la confirmación manual con código OTP.")
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    var manualCodeInput by remember { mutableStateOf("") }
    var selectedOperationAction by remember { mutableStateOf("DELIVERY_HANDOFF") }
    var flashEnabled by remember { mutableStateOf(false) }
    var proofPhotoUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=80") }

    val presetPhotos = listOf(
        "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&auto=format&fit=crop&q=80" to "Paquete en Puerta",
        "https://images.unsplash.com/photo-1526367790999-0150786686a2?w=600&auto=format&fit=crop&q=80" to "Entrega en Mano",
        "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?w=600&auto=format&fit=crop&q=80" to "Paquete con Etiqueta",
        "https://images.unsplash.com/photo-1578575437130-527eed3abbec?w=600&auto=format&fit=crop&q=80" to "Caja de Devolución"
    )

    var scanResultModal by remember { mutableStateOf<Pair<Boolean, String>?>(null) }

    // Animated laser sweep across scanner target
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserOffsetY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 220f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_anim"
    )

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Escanear Código QR",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    Row {
                        IconButton(onClick = { onNavigate(Screen.QrAuditHistory) }) {
                            Icon(imageVector = Icons.Default.History, contentDescription = "Historial", tint = PurpleGlow)
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Scanner Actor Information Banner
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurfaceVariant),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when (currentUser.role) {
                                "COURIER" -> Icons.Default.TwoWheeler
                                "SELLER" -> Icons.Default.Storefront
                                "ADMIN" -> Icons.Default.AdminPanelSettings
                                else -> Icons.Default.Person
                            },
                            contentDescription = null,
                            tint = when (currentUser.role) {
                                "COURIER" -> PurpleLight
                                "ADMIN" -> Color(0xFFEF4444)
                                else -> OfficialGold
                            },
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Operador: ${currentUser.name} (${currentUser.role})",
                                style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Validación segura en servidor con registro de auditoría y geolocalización.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                            )
                        }
                    }
                }
            }

            // Operation Mode Selectors (Prompt requirement 5: Confirmar entrega, Confirmar recogida, Confirmar devolución)
            item {
                Text(
                    text = "Seleccionar Tipo de Operación a Validar:",
                    color = TextMuted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "DELIVERY_HANDOFF" to "Confirmar Entrega",
                        "RETURN_PICKUP" to "Confirmar Recogida",
                        "RETURN_RECEIVE" to "Confirmar Devolución"
                    ).forEach { (opKey, opLabel) ->
                        val isSelected = selectedOperationAction == opKey
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                            border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedOperationAction = opKey }
                        ) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier.padding(vertical = 10.dp)
                            ) {
                                Text(
                                    text = opLabel,
                                    color = if (isSelected) Color.White else TextMuted,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            // Camera Viewfinder Box with Laser Animation
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Black),
                    border = BorderStroke(2.dp, PurplePrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        // Background Viewfinder graphic
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = Color(0xFF261D3D),
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (hasCameraPermission) "Apunta la cámara al código QR" else "Permiso de cámara requerido",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }

                        // Target Box (220dp x 220dp) with corner brackets
                        Box(
                            modifier = Modifier
                                .size(220.dp)
                                .border(BorderStroke(1.5.dp, Color(0xFF7C3AED).copy(alpha = 0.6f)), RoundedCornerShape(12.dp))
                        ) {
                            // Animated Laser Line
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.dp)
                                    .offset(y = laserOffsetY.dp)
                                    .background(
                                        Brush.horizontalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                Color(0xFFC084FC),
                                                Color(0xFF7C3AED),
                                                Color(0xFFC084FC),
                                                Color.Transparent
                                            )
                                        )
                                    )
                            )
                        }

                        // Flashlight and Controls Overlay
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.BottomCenter)
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color.Black.copy(alpha = 0.7f)
                            ) {
                                Text(
                                    text = "ENFOQUE AUTOMÁTICO",
                                    color = PurpleGlow,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            FilledIconButton(
                                onClick = {
                                    flashEnabled = !flashEnabled
                                    viewModel.showToast(if (flashEnabled) "Linterna activada" else "Linterna desactivada")
                                },
                                colors = IconButtonDefaults.filledIconButtonColors(
                                    containerColor = if (flashEnabled) OfficialGold else BlackSurfaceVariant,
                                    contentColor = if (flashEnabled) Color.Black else Color.White
                                ),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = if (flashEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "Flash"
                                )
                            }
                        }
                    }
                }
            }

            // Attached Proof Photo Selector (Requirement 2 & 3: "Adjuntar fotografía de entrega/devolución")
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = PurpleLight)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Fotografía de Comprobante / Paquete (Requerida)",
                                style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(BlackSurfaceVariant)
                        ) {
                            AsyncImage(
                                model = proofPhotoUrl,
                                contentDescription = "Foto comprobante",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Selecciona o captura una fotografía de respaldo:", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(presetPhotos) { (url, label) ->
                                val isSelected = proofPhotoUrl == url
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) PurplePrimary else BlackSurfaceVariant,
                                    border = BorderStroke(1.dp, if (isSelected) PurpleLight else BorderDark),
                                    modifier = Modifier.clickable { proofPhotoUrl = url }
                                ) {
                                    Text(
                                        text = label,
                                        color = WhiteText,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Manual Code / OTP Input Section (Requirement 2: Fallback one-time code)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Confirmación por Código OTP Alternativo",
                            style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Si el código QR no se puede leer, ingresa el código numérico de 6 dígitos o el token de seguridad.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = manualCodeInput,
                            onValueChange = { manualCodeInput = it.uppercase() },
                            placeholder = { Text("Ej: 492015 o MN-DLV-8A3F2C19", color = TextMuted) },
                            leadingIcon = {
                                Icon(Icons.Default.Pin, contentDescription = null, tint = PurpleLight)
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText,
                                focusedContainerColor = BlackSurface,
                                unfocusedContainerColor = BlackSurface
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("otp_input_field")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                if (manualCodeInput.isBlank()) {
                                    viewModel.showToast("Ingresa un código QR u OTP")
                                    return@Button
                                }
                                viewModel.validateQrCodeOrOtp(
                                    rawCodeOrOtp = manualCodeInput,
                                    proofPhotoUrl = proofPhotoUrl,
                                    notes = "Validado mediante código manual OTP"
                                ) { success, msg ->
                                    scanResultModal = Pair(success, msg)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("verify_otp_button")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Verificar y Confirmar Operación", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Quick Scan Simulator Section (Ideal for Browser Emulator testing)
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayCircle, contentDescription = null, tint = OfficialGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Simular Escaneo Directo de Códigos QR Activos",
                                style = MaterialTheme.typography.titleSmall.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Toca cualquiera de los códigos del sistema para probar la lectura instantánea:",
                            color = TextMuted,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        allTokens.take(4).forEach { tok ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BlackSurfaceVariant,
                                border = BorderStroke(1.dp, if (tok.status == "ACTIVE") Color(0xFF065F46) else BorderDark),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.validateQrCodeOrOtp(
                                            rawCodeOrOtp = tok.token,
                                            proofPhotoUrl = proofPhotoUrl,
                                            notes = "Escaneado mediante lector de cámara"
                                        ) { success, msg ->
                                            scanResultModal = Pair(success, msg)
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${tok.operationType} • #${tok.orderNumber}",
                                            color = WhiteText,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "Token: ${tok.token} • OTP: ${tok.otpCode}",
                                            color = PurpleGlow,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (tok.status == "ACTIVE") Color(0xFF065F46) else Color(0xFF991B1B)
                                    ) {
                                        Text(
                                            text = if (tok.status == "ACTIVE") "Escanear" else tok.status,
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Navigation to Audit History (Prompt Requirement 5: "Ver historial")
            item {
                OutlinedButton(
                    onClick = { onNavigate(Screen.QrAuditHistory) },
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, PurpleLight),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PurpleGlow),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("view_history_button")
                ) {
                    Icon(Icons.Default.History, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ver Historial de Auditoría QR", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Scan Result Modal Dialog
    if (scanResultModal != null) {
        val (isSuccess, message) = scanResultModal!!
        AlertDialog(
            onDismissRequest = { scanResultModal = null },
            icon = {
                Icon(
                    imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = null,
                    tint = if (isSuccess) SuccessGreen else ErrorRed,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = if (isSuccess) "Operación Validada con Éxito" else "Error de Validación",
                    color = WhiteText,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = message, color = if (isSuccess) Color(0xFFD1D5DB) else Color(0xFFFCA5A5), fontSize = 13.sp)
                    if (isSuccess) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "🔒 Se registró la fecha, hora, fotografía y usuario responsable en el registro de auditoría de Morenicho Market.",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scanResultModal = null
                        if (isSuccess) onNavigate(Screen.QrAuditHistory)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSuccess) SuccessGreen else PurplePrimary
                    )
                ) {
                    Text(if (isSuccess) "Ver en Historial" else "Entendido")
                }
            },
            dismissButton = {
                if (isSuccess) {
                    TextButton(onClick = { scanResultModal = null }) {
                        Text("Cerrar", color = TextMuted)
                    }
                }
            },
            containerColor = BlackSurface
        )
    }
}
