package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WalletMovementEntity
import com.example.data.model.WithdrawalRequestEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.MarketplaceViewModel
import com.example.ui.viewmodel.Screen
import com.example.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletFinanceScreen(
    viewModel: MarketplaceViewModel,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val currentUser by viewModel.currentUser.collectAsState()
    val movements by viewModel.userMovements.collectAsState()
    val withdrawals by viewModel.userWithdrawals.collectAsState()

    var showWithdrawModal by remember { mutableStateOf(false) }

    // Financial calculations
    val confirmedMovements = movements.filter { it.status == "CONFIRMADO" }
    val pendingMovements = movements.filter { it.status == "PENDIENTE" || it.status == "ESTIMADO" }

    val totalConfirmedEarned = confirmedMovements.filter { it.amount > 0 }.sumOf { it.amount }
    val totalPaidWithdrawals = withdrawals.filter { it.status == "PAGADO" || it.status == "APROBADO" }.sumOf { it.amount }
    val availableBalance = (totalConfirmedEarned - totalPaidWithdrawals).coerceAtLeast(0)
    val pendingBalance = pendingMovements.sumOf { it.amount }

    // Breakdown by source
    val officialStoreRev = confirmedMovements.filter { it.source == "VENTA_PROPIA" && currentUser.role == "ADMIN" }.sumOf { it.amount }
    val marketplaceCommissions = confirmedMovements.filter { it.source == "COMISION_MARKETPLACE" }.sumOf { it.amount }
    val referralEarnings = confirmedMovements.filter { it.source == "COMISION_RECOMENDACION" }.sumOf { it.amount }
    val adsRevenue = confirmedMovements.filter { it.source == "PUBLICIDAD" }.sumOf { it.amount }

    Scaffold(
        topBar = {
            Surface(
                color = BlackSurface,
                tonalElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Volver", tint = WhiteText)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Mis Ganancias & Billetera",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = WhiteText
                            )
                        )
                    }

                    if (currentUser.role == "ADMIN") {
                        TextButton(onClick = { onNavigate(Screen.AdminPanel) }) {
                            Text("Panel Admin", color = PurpleGlow, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(BlackBackground)
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Main Balance Card
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackCard),
                    border = BorderStroke(1.dp, PurpleDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SALDO DISPONIBLE",
                                color = PurpleGlow,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF065F46)
                            ) {
                                Text(
                                    text = "CLP CHILE",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = CurrencyFormatter.formatCLP(availableBalance),
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontWeight = FontWeight.Black,
                                color = WhiteText
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Divider(color = BorderDark)

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Saldo Pendiente:", color = TextMuted, fontSize = 11.sp)
                                Text(
                                    CurrencyFormatter.formatCLP(pendingBalance),
                                    color = OfficialGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Retirado:", color = TextMuted, fontSize = 11.sp)
                                Text(
                                    CurrencyFormatter.formatCLP(totalPaidWithdrawals),
                                    color = InfoBlue,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { showWithdrawModal = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("request_withdrawal_button")
                        ) {
                            Icon(imageVector = Icons.Default.Payments, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Solicitar Retiro de Dinero", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Breakdown by Source (Requirement 10)
            item {
                Text(
                    text = "Desglose de Ingresos",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = BlackSurface),
                    border = BorderStroke(1.dp, BorderDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Storefront, contentDescription = null, tint = OfficialGold, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Ventas Tienda Propia (0% Com.)", color = WhiteText, fontSize = 13.sp)
                            }
                            Text(CurrencyFormatter.formatCLP(officialStoreRev), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }

                        Divider(color = BorderDark)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Percent, contentDescription = null, tint = PurpleLight, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Comisión Marketplace (5%)", color = WhiteText, fontSize = 13.sp)
                            }
                            Text(CurrencyFormatter.formatCLP(marketplaceCommissions), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }

                        Divider(color = BorderDark)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = PurpleGlow, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Recompensas Recomendador (2%)", color = WhiteText, fontSize = 13.sp)
                            }
                            Text(CurrencyFormatter.formatCLP(referralEarnings), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }

                        Divider(color = BorderDark)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Campaign, contentDescription = null, tint = InfoBlue, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Publicidad (Monetag/Local)", color = WhiteText, fontSize = 13.sp)
                            }
                            Text(CurrencyFormatter.formatCLP(adsRevenue), color = SuccessGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Withdrawal Requests Status (Requirement 11)
            item {
                Text(
                    text = "Historial de Solicitudes de Retiro",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )
            }

            if (withdrawals.isEmpty()) {
                item {
                    Text(
                        text = "No tienes solicitudes de retiro activas.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            } else {
                items(withdrawals) { wdr ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackSurface),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = CurrencyFormatter.formatCLP(wdr.amount),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = WhiteText,
                                        fontWeight = FontWeight.Bold
                                    )
                                )

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (wdr.status) {
                                        "PAGADO" -> Color(0xFF065F46)
                                        "APROBADO" -> Color(0xFF1E40AF)
                                        "EN_REVISION" -> Color(0xFF92400E)
                                        "RECHAZADO" -> Color(0xFF991B1B)
                                        else -> Color(0xFF374151)
                                    }
                                ) {
                                    Text(
                                        text = wdr.status,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (wdr.method == "TRANSFERENCIA_CHILENA") {
                                    "Transferencia: ${wdr.bankName} (${wdr.accountType}) • RUT: ${wdr.rut} • N°: ${wdr.accountNumber}"
                                } else {
                                    "PayPal: ${wdr.emailPayPal}"
                                },
                                color = TextMuted,
                                fontSize = 11.sp
                            )

                            if (wdr.adminNotes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Nota Admin: ${wdr.adminNotes}",
                                    color = PurpleGlow,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Wallet Movements History
            item {
                Text(
                    text = "Historial de Movimientos",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WhiteText
                    )
                )
            }

            if (movements.isEmpty()) {
                item {
                    Text(
                        text = "Aún no hay movimientos registrados.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            } else {
                items(movements) { mov ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = BlackCard),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (mov.amount >= 0) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                contentDescription = null,
                                tint = if (mov.amount >= 0) SuccessGreen else ErrorRed,
                                modifier = Modifier.size(24.dp)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = mov.concept,
                                    style = MaterialTheme.typography.titleSmall.copy(color = WhiteText),
                                    maxLines = 2
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Ref: ${mov.referenceCode} • ${mov.status}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                                )
                            }

                            Text(
                                text = (if (mov.amount >= 0) "+" else "") + CurrencyFormatter.formatCLP(mov.amount),
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = if (mov.amount >= 0) SuccessGreen else ErrorRed,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal de Solicitud de Retiro (Requirement 11)
    if (showWithdrawModal) {
        var withdrawMethod by remember { mutableStateOf("TRANSFERENCIA_CHILENA") }
        var withdrawAmountText by remember { mutableStateOf("") }
        var bankName by remember { mutableStateOf("Banco Estado (Cuenta RUT)") }
        var accountType by remember { mutableStateOf("Cuenta Vista / RUT") }
        var rut by remember { mutableStateOf("") }
        var accountNumber by remember { mutableStateOf("") }
        var emailPayPal by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showWithdrawModal = false },
            title = {
                Text(
                    text = "Solicitar Retiro de Fondos",
                    style = MaterialTheme.typography.titleLarge.copy(color = WhiteText, fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Saldo Disponible: ${CurrencyFormatter.formatCLP(availableBalance)}",
                        color = SuccessGreen,
                        fontWeight = FontWeight.Bold
                    )

                    // Method selector
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = withdrawMethod == "TRANSFERENCIA_CHILENA",
                            onClick = { withdrawMethod = "TRANSFERENCIA_CHILENA" }
                        )
                        Text("Transferencia Chilena", color = WhiteText, fontSize = 13.sp)

                        Spacer(modifier = Modifier.width(12.dp))

                        RadioButton(
                            selected = withdrawMethod == "PAYPAL",
                            onClick = { withdrawMethod = "PAYPAL" }
                        )
                        Text("PayPal", color = WhiteText, fontSize = 13.sp)
                    }

                    OutlinedTextField(
                        value = withdrawAmountText,
                        onValueChange = { withdrawAmountText = it.filter { c -> c.isDigit() } },
                        label = { Text("Monto a Retirar en CLP") },
                        placeholder = { Text("Ej: 20000") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = WhiteText,
                            unfocusedTextColor = WhiteText
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (withdrawMethod == "TRANSFERENCIA_CHILENA") {
                        OutlinedTextField(
                            value = bankName,
                            onValueChange = { bankName = it },
                            label = { Text("Banco (Ej: Banco Estado, BCI, Chile)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = rut,
                            onValueChange = { rut = it },
                            label = { Text("RUT del Titular (Ej: 18.765.432-1)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = accountNumber,
                            onValueChange = { accountNumber = it },
                            label = { Text("Número de Cuenta") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        OutlinedTextField(
                            value = emailPayPal,
                            onValueChange = { emailPayPal = it },
                            label = { Text("Correo Electrónico de PayPal") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = WhiteText,
                                unfocusedTextColor = WhiteText
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Text(
                        text = "🔒 No guardamos claves bancarias. La solicitud pasa a revisión y el pago se liquida de forma segura.",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = withdrawAmountText.toIntOrNull() ?: 0
                        if (amount <= 0) {
                            viewModel.showToast("Ingresa un monto válido")
                            return@Button
                        }
                        if (amount > availableBalance) {
                            viewModel.showToast("El monto supera tu saldo disponible")
                            return@Button
                        }

                        viewModel.requestWithdrawal(
                            method = withdrawMethod,
                            amount = amount,
                            bankName = bankName,
                            accountType = accountType,
                            rut = rut,
                            accountNumber = accountNumber,
                            emailPayPal = emailPayPal
                        ) {
                            showWithdrawModal = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary)
                ) {
                    Text("Enviar Solicitud")
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawModal = false }) {
                    Text("Cancelar", color = TextMuted)
                }
            },
            containerColor = BlackSurface
        )
    }
}
