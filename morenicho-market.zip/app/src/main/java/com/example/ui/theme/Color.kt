package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette: Black, White, Vibrant Royal Purple with Gold/Emerald luxury accents
val PurplePrimary = Color(0xFF7C3AED)
val PurpleLight = Color(0xFFA855F7)
val PurpleGlow = Color(0xFFC084FC)
val PurpleDark = Color(0xFF5B21B6)

val BlackBackground = Color(0xFF09060F)
val BlackSurface = Color(0xFF130E20)
val BlackSurfaceVariant = Color(0xFF1D1630)
val BlackCard = Color(0xFF18122B)

val WhiteText = Color(0xFFF9FAFB)
val TextMuted = Color(0xFF9CA3AF)
val BorderDark = Color(0xFF2E244B)

val OfficialGold = Color(0xFFF59E0B)
val OfficialGoldContainer = Color(0xFF332306)
val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
val InfoBlue = Color(0xFF38BDF8)
