package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = PurpleLight,
    onPrimary = Color.White,
    primaryContainer = PurpleDark,
    onPrimaryContainer = PurpleGlow,
    secondary = PurpleGlow,
    onSecondary = Color.Black,
    secondaryContainer = BlackSurfaceVariant,
    onSecondaryContainer = Color.White,
    tertiary = OfficialGold,
    onTertiary = Color.Black,
    tertiaryContainer = OfficialGoldContainer,
    onTertiaryContainer = OfficialGold,
    background = BlackBackground,
    onBackground = WhiteText,
    surface = BlackSurface,
    onSurface = WhiteText,
    surfaceVariant = BlackSurfaceVariant,
    onSurfaceVariant = TextMuted,
    outline = BorderDark,
    outlineVariant = Color(0xFF261D3D)
)

private val LightColorScheme = lightColorScheme(
    primary = PurplePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF3E8FF),
    onPrimaryContainer = PurpleDark,
    secondary = PurpleDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE9FE),
    onSecondaryContainer = PurpleDark,
    tertiary = OfficialGold,
    onTertiary = Color.Black,
    background = Color(0xFFF8F7FC),
    onBackground = Color(0xFF111827),
    surface = Color.White,
    onSurface = Color(0xFF111827),
    surfaceVariant = Color(0xFFF3F0F9),
    onSurfaceVariant = Color(0xFF4B5563),
    outline = Color(0xFFE5E1F0)
)

@Composable
fun MorenichoMarketTheme(
    darkTheme: Boolean = true, // Default to sleek premium dark mode matching brand
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
