package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.example.data.repository.CartItemWithProduct
import com.example.data.repository.MarketplaceRepository
import com.example.data.supabase.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed class Screen {
    object Home : Screen()
    object Categories : Screen()
    data class ProductDetail(val productId: String) : Screen()
    object Cart : Screen()
    object Checkout : Screen()
    object PublishProduct : Screen()
    object WalletFinance : Screen()
    object AdminPanel : Screen()
    object AffiliateModule : Screen()
    object Profile : Screen()
    object Auth : Screen() // Pantalla de Autenticación Supabase
    object OrderHistory : Screen()
    object Favorites : Screen()
    object SupabaseGuide : Screen()
    data class MyQrCode(val orderId: String, val operationType: String = "DELIVERY_HANDOFF") : Screen()
    object QrScanner : Screen()
    object QrAuditHistory : Screen()
}

data class FilterCriteria(
    val query: String = "",
    val categoryId: String? = null,
    val condition: String = "ALL",
    val onlyOfficial: Boolean = false,
    val maxPrice: Int? = null,
    val location: String? = null
)

class MarketplaceViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = MarketplaceRepository(database)

    // Current Screen & Backstack
    private val _screenStack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _screenStack.map { it.lastOrNull() ?: Screen.Home }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Screen.Home)

    fun navigateTo(screen: Screen) {
        _screenStack.update { stack ->
            if (stack.lastOrNull() == screen) stack else stack + screen
        }
    }

    fun navigateBack(): Boolean {
        if (_screenStack.value.size > 1) {
            _screenStack.update { it.dropLast(1) }
            return true
        }
        return false
    }

    // Active User / Session (Switchable between all 4 roles)
    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentUser = MutableStateFlow<UserEntity>(
        UserEntity(
            id = "usr_admin",
            name = "Administrador Morenicho",
            email = "admin@morenicho.cl",
            role = "ADMIN",
            phone = "+56 9 8765 4321",
            whatsappNumber = "+56987654321",
            referralCode = "MORENICHO-ADMIN",
            city = "Santiago",
            region = "Región Metropolitana"
        )
    )
    val currentUser: StateFlow<UserEntity> = _currentUser.asStateFlow()

    val supabaseAuthRepo = SupabaseAuthRepository(database)

    fun switchUser(user: UserEntity) {
        _currentUser.value = user
        showToast("Sesión cambiada a: ${user.name} (${user.role})")
    }

    fun registerWithSupabase(
        name: String,
        email: String,
        password: String,
        role: String,
        phone: String,
        city: String,
        region: String,
        onComplete: (AuthResultState) -> Unit
    ) {
        viewModelScope.launch {
            val result = supabaseAuthRepo.registerUser(name, email, password, role, phone, city, region)
            if (result.isSuccess && result.user != null) {
                _currentUser.value = result.user
            }
            onComplete(result)
        }
    }

    fun loginWithSupabase(
        email: String,
        password: String,
        onComplete: (AuthResultState) -> Unit
    ) {
        viewModelScope.launch {
            val result = supabaseAuthRepo.loginUser(email, password)
            if (result.isSuccess && result.user != null) {
                _currentUser.value = result.user
            }
            onComplete(result)
        }
    }

    fun recoverPasswordWithSupabase(
        email: String,
        onComplete: (Result<String>) -> Unit
    ) {
        viewModelScope.launch {
            val result = supabaseAuthRepo.recoverPassword(email)
            onComplete(result)
        }
    }

    // Products & Categories
    val allProducts: StateFlow<List<ProductEntity>> = repository.getAllProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val categories: StateFlow<List<CategoryEntity>> = repository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val officialProducts: StateFlow<List<ProductEntity>> = repository.getOfficialProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val featuredProducts: StateFlow<List<ProductEntity>> = repository.getFeaturedProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val affiliateProducts: StateFlow<List<ProductEntity>> = repository.getAffiliateProducts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAffiliates: StateFlow<List<AffiliateProductEntity>> = repository.getActiveAffiliates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAffiliates: StateFlow<List<AffiliateProductEntity>> = repository.getAllAffiliates()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAds: StateFlow<List<AdCampaignEntity>> = repository.getActiveAds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAds: StateFlow<List<AdCampaignEntity>> = repository.getAllAds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search and Filter States (Requirement 2: precio, categoría y ubicación)
    val searchQuery = MutableStateFlow("")
    val selectedCategoryFilter = MutableStateFlow<String?>(null)
    val conditionFilter = MutableStateFlow<String>("ALL") // ALL, NEW, USED
    val onlyOfficialFilter = MutableStateFlow(false)
    val maxPriceFilter = MutableStateFlow<Int?>(null)
    val locationFilter = MutableStateFlow<String?>(null)

    private val baseFilters = combine(
        searchQuery,
        selectedCategoryFilter,
        conditionFilter
    ) { q, cat, cond ->
        Triple(q, cat, cond)
    }

    private val extraFilters = combine(
        onlyOfficialFilter,
        maxPriceFilter,
        locationFilter
    ) { off, maxP, loc ->
        Triple(off, maxP, loc)
    }

    private val filterState = combine(
        baseFilters,
        extraFilters
    ) { (q, cat, cond), (off, maxP, loc) ->
        FilterCriteria(q, cat, cond, off, maxP, loc)
    }

    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        allProducts,
        filterState
    ) { products, filter ->
        products.filter { p ->
            val matchQuery = filter.query.isBlank() || p.title.contains(filter.query, ignoreCase = true) || p.description.contains(filter.query, ignoreCase = true)
            val matchCat = filter.categoryId == null || p.categoryId == filter.categoryId
            val matchCond = filter.condition == "ALL" || p.condition == filter.condition
            val matchOfficial = !filter.onlyOfficial || p.isOfficial
            val matchPrice = filter.maxPrice == null || p.price <= filter.maxPrice
            val matchLocation = filter.location == null || p.locationCity.contains(filter.location, ignoreCase = true) || p.locationRegion.contains(filter.location, ignoreCase = true)
            matchQuery && matchCat && matchCond && matchOfficial && matchPrice && matchLocation
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun clearFilters() {
        searchQuery.value = ""
        selectedCategoryFilter.value = null
        conditionFilter.value = "ALL"
        onlyOfficialFilter.value = false
        maxPriceFilter.value = null
        locationFilter.value = null
    }

    // Cart with Products
    val cartItems: StateFlow<List<CartItemWithProduct>> = combine(
        repository.getCartItems(),
        allProducts
    ) { items, products ->
        val productMap = products.associateBy { it.id }
        items.mapNotNull { item ->
            productMap[item.productId]?.let { product ->
                CartItemWithProduct(item, product)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotalAmount: StateFlow<Int> = cartItems.map { items ->
        items.sumOf { it.product.price * it.cartItem.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun addToCart(productId: String) {
        viewModelScope.launch {
            val prod = allProducts.value.find { it.id == productId }
            if (prod?.isAffiliate == true) {
                showToast("Este producto es de afiliación externa (${prod.affiliatePlatform ?: "Externo"})")
                return@launch
            }
            repository.addToCart(productId, 1)
            showToast("Producto añadido al carrito")
        }
    }

    fun updateCartQuantity(cartItemId: String, quantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartItemId, quantity)
        }
    }

    fun removeFromCart(cartItemId: String) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
            showToast("Producto eliminado del carrito")
        }
    }

    // Orders
    val allOrders: StateFlow<List<OrderEntity>> = repository.getAllOrders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userOrders: StateFlow<List<OrderEntity>> = currentUser.flatMapLatest { user ->
        repository.getOrdersByBuyer(user.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun placeOrder(
        address: String,
        city: String,
        region: String,
        phone: String,
        paymentMethod: String,
        referralCode: String?,
        onSuccess: (OrderEntity) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.placeOrder(
                buyer = currentUser.value,
                cartItems = cartItems.value,
                deliveryAddress = address,
                deliveryCity = city,
                deliveryRegion = region,
                deliveryPhone = phone,
                paymentMethod = paymentMethod,
                referralCodeInput = referralCode
            )
            result.onSuccess { order ->
                showToast("¡Pedido #${order.orderNumber} creado exitosamente!")
                onSuccess(order)
            }.onFailure { err ->
                showToast("Error al procesar pedido: ${err.message}")
            }
        }
    }

    // Publishing Products
    fun publishProduct(
        title: String,
        description: String,
        price: Int,
        originalPrice: Int?,
        categoryId: String,
        condition: String,
        stock: Int,
        city: String,
        region: String,
        imageUrl: String,
        isOfficial: Boolean = false,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val user = currentUser.value
            val isOfficialProduct = isOfficial || user.role == "ADMIN" || user.id == "usr_oficial"
            val product = ProductEntity(
                id = "prod_" + UUID.randomUUID().toString().take(8),
                title = title.trim(),
                description = description.trim(),
                price = price,
                originalPrice = originalPrice,
                categoryId = categoryId,
                sellerId = user.id,
                sellerName = if (isOfficialProduct) "Tienda Oficial Morenicho" else user.name,
                sellerPhone = user.phone,
                isOfficial = isOfficialProduct,
                condition = condition,
                stock = stock,
                locationCity = city,
                locationRegion = region,
                imageUrl = if (imageUrl.isNotBlank()) imageUrl else "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=600&auto=format&fit=crop&q=80",
                isFeatured = isOfficialProduct
            )
            repository.publishProduct(product)
            showToast("¡Publicación realizada con éxito!")
            onSuccess()
        }
    }

    fun toggleSoldOut(productId: String, currentSoldOut: Boolean) {
        viewModelScope.launch {
            repository.toggleSoldOut(productId, currentSoldOut)
            showToast(if (!currentSoldOut) "Producto marcado como agotado" else "Producto reactivado")
        }
    }

    fun deleteProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.deleteProduct(product)
            showToast("Producto eliminado")
        }
    }

    // Seller Catalog & Sales
    val currentSellerProducts: StateFlow<List<ProductEntity>> = currentUser.flatMapLatest { user ->
        repository.getSellerProducts(user.id)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sellerSales: StateFlow<List<CommissionEntity>> = currentUser.flatMapLatest { user ->
        repository.getAllCommissions().map { list -> list.filter { it.sellerId == user.id } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Finance & Wallet
    val allCommissions: StateFlow<List<CommissionEntity>> = repository.getAllCommissions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userMovements: StateFlow<List<WalletMovementEntity>> = currentUser.flatMapLatest { user ->
        if (user.role == "ADMIN") {
            repository.getAllWalletMovements()
        } else {
            repository.getWalletMovementsByUser(user.id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWithdrawals: StateFlow<List<WithdrawalRequestEntity>> = repository.getAllWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userWithdrawals: StateFlow<List<WithdrawalRequestEntity>> = currentUser.flatMapLatest { user ->
        if (user.role == "ADMIN") {
            repository.getAllWithdrawals()
        } else {
            repository.getWithdrawalsByUser(user.id)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun requestWithdrawal(
        method: String,
        amount: Int,
        bankName: String,
        accountType: String,
        rut: String,
        accountNumber: String,
        emailPayPal: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val user = currentUser.value
            val request = WithdrawalRequestEntity(
                id = "wdr_" + UUID.randomUUID().toString().take(8),
                userId = user.id,
                userName = user.name,
                method = method,
                amount = amount,
                bankName = bankName,
                accountType = accountType,
                rut = rut,
                accountNumber = accountNumber,
                emailPayPal = emailPayPal,
                status = "SOLICITADO"
            )
            repository.requestWithdrawal(request)
            showToast("Solicitud de retiro enviada por $amount CLP")
            onSuccess()
        }
    }

    fun updateWithdrawalStatus(id: String, status: String, notes: String) {
        viewModelScope.launch {
            repository.updateWithdrawalStatus(id, status, notes)
            showToast("Estado de retiro actualizado a: $status")
        }
    }

    // Affiliate Actions
    fun recordAffiliateClick(id: String) {
        viewModelScope.launch {
            repository.incrementAffiliateClick(id)
        }
    }

    fun addAffiliateProduct(
        name: String,
        description: String,
        price: Int,
        categoryId: String,
        platformSource: String,
        affiliateUrl: String,
        commissionRate: String,
        imageUrl: String
    ) {
        viewModelScope.launch {
            val item = AffiliateProductEntity(
                id = "aff_" + UUID.randomUUID().toString().take(8),
                name = name,
                description = description,
                price = price,
                categoryId = categoryId,
                platformSource = platformSource,
                affiliateUrl = affiliateUrl,
                commissionRate = commissionRate,
                imageUrl = if (imageUrl.isNotBlank()) imageUrl else "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80"
            )
            repository.insertAffiliate(item)
            showToast("Producto afiliado agregado")
        }
    }

    fun deleteAffiliateProduct(item: AffiliateProductEntity) {
        viewModelScope.launch {
            repository.deleteAffiliate(item)
            showToast("Producto afiliado eliminado")
        }
    }

    // Ads Management
    fun addAdCampaign(
        title: String,
        advertiser: String,
        placement: String,
        imageUrl: String,
        targetUrl: String,
        network: String,
        fixedPrice: Int
    ) {
        viewModelScope.launch {
            val ad = AdCampaignEntity(
                id = "ad_" + UUID.randomUUID().toString().take(8),
                title = title,
                advertiserName = advertiser,
                placement = placement,
                bannerImageUrl = imageUrl,
                targetUrl = targetUrl,
                adNetwork = network,
                cpmOrFixedCLP = fixedPrice
            )
            repository.insertAd(ad)
            showToast("Anuncio publicitario creado")
        }
    }

    fun toggleAdActive(ad: AdCampaignEntity) {
        viewModelScope.launch {
            repository.updateAd(ad.copy(isActive = !ad.isActive))
            showToast("Estado del anuncio actualizado")
        }
    }

    fun recordAdClick(id: String) {
        viewModelScope.launch {
            repository.recordAdClick(id)
        }
    }

    // Favorites
    val favorites: StateFlow<List<ProductEntity>> = currentUser.flatMapLatest { user ->
        repository.getFavoritesByUser(user.id)
    }.combine(allProducts) { favEntities, prods ->
        val prodMap = prods.associateBy { it.id }
        favEntities.mapNotNull { prodMap[it.productId] }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun toggleFavorite(productId: String) {
        viewModelScope.launch {
            val user = currentUser.value
            val isFav = favorites.value.any { it.id == productId }
            if (isFav) {
                repository.removeFavorite(user.id, productId)
                showToast("Eliminado de favoritos")
            } else {
                repository.addFavorite(user.id, productId)
                showToast("Agregado a favoritos ❤️")
            }
        }
    }

    // QR Delivery & Returns System (Requirements 1, 2, 3, 4, 5)
    val allQrTokens: StateFlow<List<QrSecurityTokenEntity>> = repository.getAllTokens()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAuditLogs: StateFlow<List<QrAuditLogEntity>> = repository.getAllAuditLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun getTokensForOrder(orderId: String): Flow<List<QrSecurityTokenEntity>> =
        repository.getTokensForOrder(orderId)

    fun getTokenForOrderAndType(orderId: String, operationType: String): Flow<QrSecurityTokenEntity?> =
        repository.getTokenForOrderAndType(orderId, operationType)

    fun validateQrCodeOrOtp(
        rawCodeOrOtp: String,
        proofPhotoUrl: String,
        notes: String = "",
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch {
            val actor = currentUser.value
            val result = repository.validateAndExecuteQrOperation(
                rawCodeOrOtp = rawCodeOrOtp,
                actor = actor,
                proofPhotoUrl = proofPhotoUrl,
                notes = notes
            )
            result.onSuccess { (_, message) ->
                showToast(message)
                onResult(true, message)
            }.onFailure { err ->
                val errorMsg = err.message ?: "Error al validar código QR"
                showToast(errorMsg)
                onResult(false, errorMsg)
            }
        }
    }

    // Toast & Snackbar feedback
    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    fun showToast(msg: String) {
        viewModelScope.launch {
            _toastMessage.emit(msg)
        }
    }
}
