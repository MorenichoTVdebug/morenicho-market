package com.example.util

import java.text.NumberFormat
import java.util.Locale

object CurrencyFormatter {
    private val chileLocale = Locale("es", "CL")
    private val numberFormat = NumberFormat.getNumberInstance(chileLocale)

    /**
     * Formats an integer amount as Chilean Pesos (e.g., "$ 19.990 CLP")
     */
    fun formatCLP(amount: Int): String {
        return "$ ${numberFormat.format(amount)} CLP"
    }

    /**
     * Formats a short version (e.g., "$ 19.990")
     */
    fun formatShortCLP(amount: Int): String {
        return "$ ${numberFormat.format(amount)}"
    }
}
