package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.CurrencyFormatter
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Morenicho Market", appName)
    }

    @Test
    fun `verify commission calculation rules`() {
        val baseAmount = 100000 // 100.000 CLP

        // 1. With Referrer (5% platform, 2% referrer, 93% seller)
        val platformAmount = (baseAmount * 0.05).toInt()
        val referrerAmount = (baseAmount * 0.02).toInt()
        val sellerAmount = baseAmount - platformAmount - referrerAmount

        assertEquals(5000, platformAmount)
        assertEquals(2000, referrerAmount)
        assertEquals(93000, sellerAmount)
        assertEquals(baseAmount, platformAmount + referrerAmount + sellerAmount)

        // 2. Without Referrer (7% platform, 93% seller)
        val platformNoRef = (baseAmount * 0.07).toInt()
        val sellerNoRef = baseAmount - platformNoRef
        assertEquals(7000, platformNoRef)
        assertEquals(93000, sellerNoRef)
        assertEquals(baseAmount, platformNoRef + sellerNoRef)

        // 3. Official Store (0% platform commission, 100% official)
        val officialCommission = 0
        val officialRevenue = baseAmount
        assertEquals(0, officialCommission)
        assertEquals(100000, officialRevenue)
    }

    @Test
    fun `verify CLP currency formatter`() {
        val formatted = CurrencyFormatter.formatShortCLP(19990)
        // Checks that CLP formatting starts with $ and contains 19
        assert(formatted.startsWith("$"))
        assert(formatted.contains("19"))
    }

    @Test
    fun `verify Supabase production configuration`() {
        val url = com.example.data.supabase.SupabaseConfig.currentUrl
        val key = com.example.data.supabase.SupabaseConfig.currentAnonKey

        assertEquals("https://kpygbsbkhjtcuvojirke.supabase.co", url)
        assertEquals("Sb_publishable_a5yDwBHDeEhWm6vMYJZvHg_S-8_QH1b", key)
        assert(com.example.data.supabase.SupabaseConfig.isConfigured())
    }

    @Test
    fun `verify Supabase DDL contains affiliate columns`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = androidx.room.Room.inMemoryDatabaseBuilder(context, com.example.data.local.AppDatabase::class.java).build()
        val repo = com.example.data.repository.MarketplaceRepository(db)
        val sql = repo.generateSupabaseSchemaSql()

        assert(sql.contains("is_affiliate BOOLEAN DEFAULT FALSE"))
        assert(sql.contains("affiliate_platform TEXT"))
        assert(sql.contains("affiliate_url TEXT"))
        db.close()
    }
}
