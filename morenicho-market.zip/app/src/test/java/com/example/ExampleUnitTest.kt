package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun `verify ProductEntity affiliate support`() {
    val aliProduct = com.example.data.model.ProductEntity(
      id = "test_ali",
      title = "Smart Camera AliExpress",
      description = "Outdoor camera 4K",
      price = 32990,
      categoryId = "tech",
      sellerId = "affiliate_seller",
      sellerName = "AliExpress Global",
      sellerPhone = "+56911112222",
      imageUrl = "https://example.com/cam.jpg",
      isAffiliate = true,
      affiliatePlatform = "AliExpress",
      affiliateUrl = "https://s.click.aliexpress.com/e/test"
    )

    assertTrue(aliProduct.isAffiliate)
    assertEquals("AliExpress", aliProduct.affiliatePlatform)
    assertEquals("https://s.click.aliexpress.com/e/test", aliProduct.affiliateUrl)
  }
}
